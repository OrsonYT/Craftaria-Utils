package fr.craftaria.utils.cooking;

import fr.craftaria.utils.CraftariaUtilsClient;
import fr.craftaria.utils.config.ModConfig;
import java.util.ArrayDeque;
import java.util.Queue;
import net.minecraft.class_1713;
import net.minecraft.class_2561;
import net.minecraft.class_2868;
import net.minecraft.class_310;
import net.minecraft.class_746;

public final class CookingQueue {
    private static final Queue<Integer> QUEUE = new ArrayDeque<>();
    private static class_746 owner;
    private static int ticksLeft;
    private static int workingHotbarSlot = -1;
    private static int originalSelectedSlot = -1;
    private static int sourceSlot = -1;
    private static boolean active;
    private static boolean stopping;
    private static class_2561 startError;

    private CookingQueue() {}

    public static boolean start(Iterable<Integer> playerInventoryIndices) {
        class_310 client = class_310.method_1551();
        startError = null;
        if (active) return reject("craftaria_utils.cooking.busy");
        if (client.field_1724 == null || client.method_1562() == null) return false;

        int emptySlot = -1;
        for (int index = 0; index < 9; index++) {
            if (client.field_1724.method_31548().method_5438(index).method_7960()) { emptySlot = index; break; }
        }
        if (emptySlot == -1) return reject("craftaria_utils.cooking.hotbar_full");

        QUEUE.clear();
        for (int index : playerInventoryIndices) {
            if (index >= 0 && index < 36 && !client.field_1724.method_31548().method_5438(index).method_7960()
                    && !QUEUE.contains(index)) QUEUE.add(index);
        }
        if (QUEUE.isEmpty()) return false;
        owner = client.field_1724;
        workingHotbarSlot = emptySlot;
        originalSelectedSlot = owner.method_31548().method_67532();
        sourceSlot = -1;
        ticksLeft = 0;
        stopping = false;
        active = true;
        return true;
    }

    private static boolean reject(String key) {
        startError = class_2561.method_43471(key);
        return false;
    }

    public static class_2561 getStartError() { return startError; }
    public static boolean isActive() { return active; }

    /** Stop after putting the current stack back; never abandon a stack mid-swap. */
    public static void cancel() { stopping = true; QUEUE.clear(); }

    public static void tick(class_310 client) {
        if (!active) return;
        if (client.field_1724 != owner || client.field_1761 == null || client.method_1562() == null) {
            reset();
            return;
        }
        if (client.field_1724.field_7512 != client.field_1724.field_7498) {
            // Defer inventory clicks until the player's own inventory is available again.
            cancel();
            return;
        }
        if (ticksLeft > 0) { ticksLeft--; return; }

        if (sourceSlot != -1) {
            // The source was emptied by the first swap. Return the cooked stack to that exact slot.
            if (!owner.method_31548().method_5438(sourceSlot).method_7960()) {
                owner.method_7353(class_2561.method_43471("craftaria_utils.cooking.inventory_changed"), false);
                finish(client, false);
                return;
            }
            swap(client, sourceSlot);
            sourceSlot = -1;
        }

        if (stopping || QUEUE.isEmpty()) { finish(client, !stopping); return; }
        if (!owner.method_31548().method_5438(workingHotbarSlot).method_7960()) {
            owner.method_7353(class_2561.method_43471("craftaria_utils.cooking.inventory_changed"), false);
            finish(client, false);
            return;
        }

        Integer next;
        do { next = QUEUE.poll(); }
        while (next != null && owner.method_31548().method_5438(next).method_7960());
        if (next == null) { finish(client, true); return; }

        sourceSlot = next;
        swap(client, sourceSlot);
        selectHotbar(client, workingHotbarSlot);
        CraftariaUtilsClient.sendCommand(client, "four");
        // Let the server update the held stack before returning it to its source slot.
        ticksLeft = Math.clamp(ModConfig.get().cookingDelayTicks, 2, 100) - 1;
    }

    private static void swap(class_310 client, int inventoryIndex) {
        int screenSlot = inventoryIndex < 9 ? 36 + inventoryIndex : inventoryIndex;
        client.field_1761.method_2906(owner.field_7498.field_7763, screenSlot,
                workingHotbarSlot, class_1713.field_7791, owner);
    }

    private static void selectHotbar(class_310 client, int slot) {
        owner.method_31548().method_61496(slot);
        client.method_1562().method_52787(new class_2868(slot));
    }

    private static void finish(class_310 client, boolean completed) {
        selectHotbar(client, originalSelectedSlot);
        if (completed) owner.method_7353(class_2561.method_43471("craftaria_utils.cooking.done"), false);
        reset();
    }

    private static void reset() {
        active = false;
        stopping = false;
        owner = null;
        sourceSlot = -1;
        workingHotbarSlot = -1;
        originalSelectedSlot = -1;
        QUEUE.clear();
    }
}
