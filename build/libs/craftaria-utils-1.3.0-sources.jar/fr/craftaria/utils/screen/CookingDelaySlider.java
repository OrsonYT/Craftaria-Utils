package fr.craftaria.utils.screen;

import fr.craftaria.utils.config.ModConfig;
import java.util.Locale;
import net.minecraft.class_2561;
import net.minecraft.class_357;

public final class CookingDelaySlider extends class_357 {
    public CookingDelaySlider(int x, int y, int width) {
        super(x, y, width, 20, class_2561.method_43473(), (ModConfig.get().cookingDelayTicks - 2) / 98.0);
        method_25346();
    }

    @Override protected void method_25346() {
        method_25355(class_2561.method_43469("craftaria_utils.cooking.delay",
                String.format(Locale.getDefault(), "%.1f", ModConfig.get().cookingDelayTicks / 20.0)));
    }

    @Override protected void method_25344() {
        // Fifty values, one for each tenth of a second from 0.1 to 5.0.
        ModConfig.get().cookingDelayTicks = 2 + (int)Math.round(field_22753 * 49) * 2;
        ModConfig.save();
        method_25346();
    }
}
