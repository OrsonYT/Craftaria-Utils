package fr.craftaria.utils.screen;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import net.minecraft.class_10799;
import net.minecraft.class_12239;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_642;
import net.minecraft.class_644;

/** Vanilla status protocol, with DNS resolution off the render thread. */
public final class ServerStatusPanel {
    private static final ExecutorService EXECUTOR = Executors.newSingleThreadExecutor(task -> {
        Thread thread = new Thread(task, "Craftaria server status");
        thread.setDaemon(true);
        return thread;
    });
    private class_644 pinger;
    private class_642 server;
    private boolean closed = true;
    private long startedAt;
    private long nextRefresh;

    public void open() {
        closed = false;
        refresh();
    }

    private void refresh() {
        if (pinger != null) pinger.method_3004();
        class_644 current = new class_644();
        class_642 info = new class_642("Craftaria", CraftariaTitleScreen.SERVER, class_642.class_8678.field_45611);
        info.method_55824(class_642.class_9083.field_47881);
        info.field_3758 = -1;
        pinger = current;
        server = info;
        startedAt = System.nanoTime();
        nextRefresh = startedAt + 30_000_000_000L;
        EXECUTOR.execute(() -> {
            try {
                current.method_3003(info, () -> { }, () -> class_310.method_1551().execute(() -> {
                    if (!closed && pinger == current) info.method_55824(class_642.class_9083.field_47884);
                }), class_12239.method_75867(true));
            } catch (Exception exception) {
                class_310.method_1551().execute(() -> {
                    if (!closed && pinger == current) info.method_55824(class_642.class_9083.field_47882);
                });
            } finally {
                class_310.method_1551().execute(() -> {
                    if (closed || pinger != current) current.method_3004();
                });
            }
        });
    }

    public void tick() {
        if (closed) return;
        pinger.method_3000();
        long now = System.nanoTime();
        if (server.method_55825() == class_642.class_9083.field_47881 && now - startedAt > 10_000_000_000L) {
            pinger.method_3004();
            server.method_55824(class_642.class_9083.field_47882);
        }
        if (now >= nextRefresh) refresh();
    }

    public void close() {
        closed = true;
        if (pinger != null) pinger.method_3004();
    }

    public void render(class_332 context, int screenWidth, int screenHeight) {
        if (server == null) return;
        var font = class_310.method_1551().field_1772;
        // Match the size, right margin and muted text of the credits below.
        float scale = Math.clamp(Math.min(screenWidth / 960f, screenHeight / 540f), 0.5f, 0.7f);
        context.method_51448().pushMatrix();
        context.method_51448().scale(scale, scale);
        int right = (int)((screenWidth - 6) / scale), top = (int)(8 / scale);
        boolean pending = server.method_55825() == class_642.class_9083.field_47881;
        boolean online = server.method_55825() == class_642.class_9083.field_47884;
        class_2561 players = online && server.field_41861 != null
                ? class_2561.method_43469("craftaria_utils.server.players", server.field_41861.comp_1280(), server.field_41861.comp_1279())
                : class_2561.method_43471(pending ? "craftaria_utils.server.checking" : online
                    ? "craftaria_utils.server.players_unknown" : "craftaria_utils.server.offline");
        class_2561 latency = class_2561.method_43470(online ? Math.max(0, server.field_3758) + " ms" : pending ? "…" : "—");
        context.method_27535(font, players, right-font.method_27525(players), top, 0xFFCDC7BA);
        int color = server.field_3758 < 150 ? 0xFF69E27C : server.field_3758 < 300 ? 0xFFB6DB66
                : server.field_3758 < 600 ? 0xFFFFD16A : server.field_3758 < 1000 ? 0xFFFFA45A : 0xFFFF6F6F;
        int barsX = right-10, barsY = top+10;
        if (online) {
            int bars = server.field_3758 < 150 ? 5 : server.field_3758 < 300 ? 4 : server.field_3758 < 600 ? 3 : server.field_3758 < 1000 ? 2 : 1;
            for (int i = 0; i < 5; i++) {
                int h = 2 + i*6/4;
                context.method_25294(barsX+i*2, barsY+8-h, barsX+i*2+1, barsY+8, i < bars ? color : 0xFF545862);
            }
        } else {
            int frame = (int)((System.nanoTime()-startedAt)/100_000_000L % 8);
            if (frame > 4) frame = 8-frame;
            class_2960 sprite = class_2960.method_60656(pending ? "server_list/pinging_"+(frame+1) : "server_list/unreachable");
            context.method_52706(class_10799.field_56883, sprite, barsX, barsY, 10, 8);
        }
        context.method_27535(font, latency, barsX-5-font.method_27525(latency), top+10,
                online || pending ? 0xFFCDC7BA : 0xFFD39E96);
        context.method_51448().popMatrix();
    }
}
