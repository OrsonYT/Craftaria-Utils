package fr.craftaria.utils.screen;

import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_6382;
import org.lwjgl.glfw.GLFW;

/** Text-only menu action with a pixel shadow and a visible keyboard focus marker. */
public final class MenuTextButton extends class_339 {
    private final Runnable action;
    private final float textScale;

    public MenuTextButton(int x, int y, int width, int height, class_2561 label, float textScale, Runnable action) {
        super(x, y, width, height, label);
        this.textScale = textScale;
        this.action = action;
    }

    @Override protected void method_48579(class_332 context, int mouseX, int mouseY, float delta) {
        drawLabel(context, method_25369(), method_46426(), method_46427(), textScale, method_49606() || method_25370(), field_22763);
    }

    public static void drawLabel(class_332 context, class_2561 label, int x, int y, float scale, boolean highlighted, boolean active) {
        var renderer = class_310.method_1551().field_1772;
        context.method_51448().pushMatrix();
        context.method_51448().translate(x, y);
        context.method_51448().scale(scale, scale);
        if (highlighted && active) context.method_51433(renderer, ">", -12, 0, 0xFFFFCC65, true);
        context.method_51439(renderer, label, 1, 2, 0xFF292421, false);
        context.method_51439(renderer, label, 0, 0, highlighted && active ? 0xFFFFDA83 : 0xFFF7F4EA, false);
        context.method_51448().popMatrix();
    }

    @Override public void method_25348(class_11909 click, boolean doubled) { action.run(); }
    @Override public boolean method_25404(class_11908 input) {
        if (field_22763 && method_25370() && (input.comp_4795() == GLFW.GLFW_KEY_ENTER || input.comp_4795() == GLFW.GLFW_KEY_KP_ENTER || input.comp_4795() == GLFW.GLFW_KEY_SPACE)) {
            method_25354(class_310.method_1551().method_1483());
            action.run();
            return true;
        }
        return false;
    }
    @Override protected void method_47399(class_6382 builder) { method_37021(builder); }
}
