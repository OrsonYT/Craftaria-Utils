package fr.craftaria.utils.screen;

import fr.craftaria.utils.cooking.CookingQueue;
import java.util.Set;
import java.util.TreeSet;
import net.minecraft.class_10799;
import net.minecraft.class_11909;
import net.minecraft.class_1713;
import net.minecraft.class_1723;
import net.minecraft.class_1735;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_465;
import net.minecraft.class_490;

/** Uses the player's real inventory slots, but clicks only change the local selection. */
public final class CookingScreen extends class_465<class_1723> {
    private static final class_2960 TEXTURE = class_2960.method_60656("textures/gui/container/inventory.png");
    private final class_437 parent;
    private final Set<Integer> selected = new TreeSet<>();
    private class_4185 cookButton;
    private class_2561 startError;
    private int mouseX, mouseY;

    public CookingScreen(class_437 parent) {
        super(class_310.method_1551().field_1724.field_7498,
                class_310.method_1551().field_1724.method_31548(), class_2561.method_43471("craftaria_utils.cooking.title"));
        this.parent = parent;
    }

    @Override protected void method_25426() {
        super.method_25426();
        cookButton = method_37063(class_4185.method_46430(startLabel(), button -> {
            if (CookingQueue.start(selected)) field_22787.method_1507(null);
            else startError = CookingQueue.getStartError();
        }).method_46434(field_2776, field_2800 + field_2779 + 6, 110, 20).method_46431());
        cookButton.field_22763 = !selected.isEmpty();
        method_37063(class_4185.method_46430(class_2561.method_43471("gui.cancel"), button -> method_25419())
                .method_46434(field_2776 + 114, field_2800 + field_2779 + 6, 62, 20).method_46431());
    }

    private class_2561 startLabel() { return class_2561.method_43469("craftaria_utils.cooking.start", selected.size()); }

    @Override public boolean method_25402(class_11909 click, boolean doubled) {
        for (class_1735 slot : field_2797.field_7761) {
            if (click.comp_4798() >= field_2776 + slot.field_7873 && click.comp_4798() < field_2776 + slot.field_7873 + 16
                    && click.comp_4799() >= field_2800 + slot.field_7872 && click.comp_4799() < field_2800 + slot.field_7872 + 16) {
                if (click.method_74245() == 0 && slot.field_7871 == field_22787.field_1724.method_31548()
                        && slot.method_34266() < 36 && slot.method_7681()) {
                    if (!selected.add(slot.method_34266())) selected.remove(slot.method_34266());
                    cookButton.method_25355(startLabel());
                    cookButton.field_22763 = !selected.isEmpty();
                }
                return true;
            }
        }
        return super.method_25402(click, doubled);
    }

    @Override protected void method_2383(class_1735 slot, int slotId, int button, class_1713 actionType) {
        // Selection never sends inventory clicks, swaps, drops, or crafting actions to the server.
    }

    @Override protected void method_2385(class_332 context, class_1735 slot, int mouseX, int mouseY) {
        super.method_2385(context, slot, mouseX, mouseY);
        if (slot.field_7871 == field_22787.field_1724.method_31548() && selected.contains(slot.method_34266())) {
            context.method_25294(slot.field_7873, slot.field_7872, slot.field_7873 + 16, slot.field_7872 + 16, 0x8033DD55);
        }
    }

    @Override protected void method_2389(class_332 context, float delta, int mouseX, int mouseY) {
        context.method_25290(class_10799.field_56883, TEXTURE, field_2776, field_2800, 0, 0, field_2792, field_2779, 256, 256);
        class_490.method_2486(context, field_2776 + 26, field_2800 + 8, field_2776 + 75, field_2800 + 78, 30, 0.0625F,
                (float)this.mouseX, (float)this.mouseY, field_22787.field_1724);
    }

    @Override public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        this.mouseX = mouseX;
        this.mouseY = mouseY;
        super.method_25394(context, mouseX, mouseY, delta);
        context.method_27534(field_22793, startError != null ? startError
                        : class_2561.method_43469("craftaria_utils.cooking.hint", selected.size()),
                field_22789 / 2, field_2800 - 14, startError != null ? 0xFFFF7777 : 0xFFFFFFFF);
        method_2380(context, mouseX, mouseY);
    }

    @Override protected void method_57734(class_332 context) { }
    @Override public void method_25419() { field_22787.method_1507(parent); }
}
