package fr.craftaria.utils.mixin;

import fr.craftaria.utils.cooking.CookingQueue;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_329;
import net.minecraft.class_332;
import net.minecraft.class_9779;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_329.class)
public abstract class InGameHudMixin {
    @Inject(method = "render", at = @At("TAIL"))
    private void craftariaUtils$renderCookingProgress(class_332 context, class_9779 tickCounter, CallbackInfo ci) {
        class_310 client = class_310.method_1551();
        if (!CookingQueue.isActive() || client.field_1724 == null || client.field_1755 != null) return;

        int total = CookingQueue.getTotalCount();
        int current = Math.min(CookingQueue.getCompletedCount() + 1, total);
        int width = 164;
        int height = 38;
        int x = (context.method_51421() - width) / 2;
        int y = context.method_51443() / 2 + 26;

        context.method_25294(x, y, x + width, y + height, 0xCC101015);
        context.method_25294(x, y, x + width, y + 1, 0xFFFFB94A);
        context.method_25294(x, y + height - 1, x + width, y + height, 0xFFFFB94A);
        context.method_25294(x, y + 1, x + 1, y + height - 1, 0xFFFFB94A);
        context.method_25294(x + width - 1, y + 1, x + width, y + height - 1, 0xFFFFB94A);

        int bob = (client.field_1724.field_6012 / 5) % 2;
        context.method_51427(class_1802.field_8732.method_7854(), x + 7, y + 7 + bob);
        context.method_27535(client.field_1772,
                class_2561.method_43469("craftaria_utils.cooking.progress", current, total),
                x + 29, y + 6, 0xFFFFFFFF);

        int barX = x + 29;
        int barY = y + 23;
        int barWidth = width - 38;
        context.method_25294(barX, barY, barX + barWidth, barY + 5, 0xFF45454B);
        int progressWidth = Math.round(barWidth * CookingQueue.getProgress());
        if (progressWidth > 0) context.method_25294(barX, barY, barX + progressWidth, barY + 5, 0xFFFFB94A);
    }
}
