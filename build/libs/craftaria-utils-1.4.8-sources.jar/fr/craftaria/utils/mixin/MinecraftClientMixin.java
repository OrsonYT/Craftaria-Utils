package fr.craftaria.utils.mixin;

import fr.craftaria.utils.screen.CraftariaTitleScreen;
import fr.craftaria.utils.screen.MenuNavigation;
import net.minecraft.class_310;
import net.minecraft.class_437;
import net.minecraft.class_442;
import net.minecraft.class_500;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(class_310.class)
public abstract class MinecraftClientMixin {
    @ModifyVariable(method = "setScreen", at = @At("HEAD"), argsOnly = true)
    private class_437 craftariaUtils$titleScreen(class_437 screen) {
        if (!MenuNavigation.isVanillaMenuSelected() && screen != null
                && (screen.getClass() == class_442.class || screen instanceof class_500)) {
            return new CraftariaTitleScreen();
        }
        return screen;
    }
}
