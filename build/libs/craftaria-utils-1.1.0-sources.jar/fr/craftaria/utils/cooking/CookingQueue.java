package fr.craftaria.utils.cooking;

import fr.craftaria.utils.CraftariaUtilsClient;
import fr.craftaria.utils.config.ModConfig;
import java.util.ArrayDeque;
import java.util.Queue;
import net.minecraft.class_1713;
import net.minecraft.class_2561;
import net.minecraft.class_310;

public final class CookingQueue {
    private static final Queue<Integer> QUEUE = new ArrayDeque<>();
    private static int ticksLeft;
    private static boolean active;
    private CookingQueue() {}
    public static void start(Iterable<Integer> playerInventoryIndices) {
        QUEUE.clear();
        int heldSlot = class_310.method_1551().field_1724.method_31548().method_67532();
        boolean includeHeld = false;
        for (int index : playerInventoryIndices) {
            if (index == heldSlot) includeHeld = true;
            else QUEUE.add(index);
        }
        // The active hotbar slot is used to hold each stack. Process its contents first.
        if (includeHeld) {
            var remaining = new ArrayDeque<>(QUEUE);
            QUEUE.clear();
            QUEUE.add(heldSlot);
            QUEUE.addAll(remaining);
        }
        active = !QUEUE.isEmpty();
        ticksLeft = 0;
    }
    public static boolean isActive() { return active; }
    public static void cancel() { active = false; QUEUE.clear(); }
    public static void tick(class_310 client) {
        if (!active) return;
        if (client.field_1724 == null || client.field_1761 == null || client.method_1562() == null) { cancel(); return; }
        if (client.field_1724.field_7512 != client.field_1724.field_7498) { cancel(); return; }
        if (ticksLeft > 0) { ticksLeft--; return; }
        Integer inventoryIndex = QUEUE.poll();
        if (inventoryIndex == null) {
            active = false;
            client.field_1705.method_1743().method_1812(class_2561.method_43471("craftaria_utils.cooking.done"));
            return;
        }
        int syncId = client.field_1724.field_7512.field_7763;
        int slotId = inventoryIndex < 9 ? 36 + inventoryIndex : inventoryIndex;
        int hotbar = client.field_1724.method_31548().method_67532();
        client.field_1761.method_2906(syncId, slotId, hotbar, class_1713.field_7791, client.field_1724);
        CraftariaUtilsClient.sendCommand(client, "four");
        ticksLeft = Math.clamp(ModConfig.get().cookingDelayTicks, 2, 100) - 1;
    }
}
