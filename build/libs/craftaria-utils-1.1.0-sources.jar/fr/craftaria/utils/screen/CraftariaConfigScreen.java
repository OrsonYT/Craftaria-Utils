package fr.craftaria.utils.screen;

import fr.craftaria.utils.CraftariaUtilsClient;
import fr.craftaria.utils.config.ModConfig;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public final class CraftariaConfigScreen extends CraftariaScreen {
    private final class_437 parent;
    private class_342 passwordField;
    private class_4185 repairButton;
    public CraftariaConfigScreen(class_437 parent) { super(class_2561.method_43471("craftaria_utils.title")); this.parent = parent; }

    @Override protected void method_25426() {
        repairButton = method_37063(class_4185.method_46430(repairLabel(), b -> {
            ModConfig.get().autoRepair = !ModConfig.get().autoRepair;
            b.method_25355(repairLabel()); ModConfig.save();
        }).method_46434(field_22789 / 2 - 100, 52, 200, 20).method_46431());
        method_37063(class_4185.method_46430(class_2561.method_43469("craftaria_utils.binds", key(CraftariaUtilsClient.fourKey), key(CraftariaUtilsClient.loginKey), key(CraftariaUtilsClient.cookingKey)), b -> class_310.method_1551().method_1507(new net.minecraft.class_458(this, class_310.method_1551().field_1690))).method_46434(field_22789 / 2 - 150, 78, 300, 20).method_46431());
        passwordField = new class_342(field_22793, field_22789 / 2 - 100, 116, 200, 20, class_2561.method_43471("craftaria_utils.login.password"));
        passwordField.method_1852(ModConfig.get().password);
        passwordField.method_1880(128);
        passwordField.method_73210((value, cursor) -> class_2561.method_43470("•".repeat(value.length())).method_30937());
        method_37063(passwordField);
        method_37063(class_4185.method_46430(class_2561.method_43471("craftaria_utils.save"), b -> saveAndClose()).method_46434(field_22789 / 2 - 100, 146, 98, 20).method_46431());
        method_37063(class_4185.method_46430(class_2561.method_43471("gui.done"), b -> { save(); method_25419(); }).method_46434(field_22789 / 2 + 2, 146, 98, 20).method_46431());
        method_37063(class_4185.method_46430(class_2561.method_43471("craftaria_utils.open_cooking"), b -> class_310.method_1551().method_1507(new CookingScreen(this))).method_46434(field_22789 / 2 - 100, 176, 200, 20).method_46431());
        method_37063(new CookingDelaySlider(field_22789 / 2 - 100, 206, 200));
    }
    private class_2561 repairLabel() { return class_2561.method_43469("craftaria_utils.repair", class_2561.method_43471(ModConfig.get().autoRepair ? "options.on" : "options.off")); }
    private String key(net.minecraft.class_304 binding) { return binding.method_16007().getString(); }
    private void save() { ModConfig.get().password = passwordField.method_1882(); ModConfig.save(); }
    private void saveAndClose() { save(); method_25419(); }
    @Override public void method_25419() { class_310.method_1551().method_1507(parent); }
    @Override public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        method_25420(context, mouseX, mouseY, delta);
        context.method_27534(field_22793, field_22785, field_22789 / 2, 25, 0xFFFFFF);
        context.method_27534(field_22793, class_2561.method_43471("craftaria_utils.password_hint"), field_22789 / 2, 103, 0xA0A0A0);
        context.method_27534(field_22793, class_2561.method_43471("craftaria_utils.password_storage"), field_22789 / 2, 235, 0x909090);
        super.method_25394(context, mouseX, mouseY, delta);
    }
}
