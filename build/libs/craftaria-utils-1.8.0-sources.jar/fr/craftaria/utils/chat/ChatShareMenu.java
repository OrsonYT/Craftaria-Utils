package fr.craftaria.utils.chat;

import java.util.List;
import java.util.function.Consumer;
import net.minecraft.class_1109;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3417;

/** Inserts server chat tags into the draft; never sends a chat message. */
public final class ChatShareMenu {
    private record Entry(String token, String label, class_1792 icon) { }
    private static final List<Entry> ENTRIES = List.of(
            new Entry("#inv", "inventory", class_1802.field_8106),
            new Entry("#item", "item", class_1802.field_8377),
            new Entry("#ec", "enderchest", class_1802.field_8466),
            new Entry("#bal", "balance", class_1802.field_8687),
            new Entry("#sk", "skills", class_1802.field_8287),
            new Entry("#guild", "guild", class_1802.field_8539),
            new Entry("#gbank", "guild_bank", class_1802.field_8494));
    private static final int BUTTON_SIZE = 20;
    private static final int ROW_HEIGHT = 22;
    private final Consumer<String> insert;
    private int x, buttonY, popupY, popupWidth;
    private final int popupHeight = 22+ENTRIES.size()*ROW_HEIGHT;
    private boolean open;

    public ChatShareMenu(Consumer<String> insert) { this.insert = insert; }
    public boolean isOpen() { return open; }
    public void close() { open = false; }

    public void layout(int screenWidth, int fieldY) {
        x = 4;
        buttonY = Math.max(4, fieldY-26);
        popupWidth = Math.min(242, screenWidth-8);
        popupY = Math.max(2, buttonY-popupHeight-4);
    }

    public void render(class_332 context, int mouseX, int mouseY) {
        var client = class_310.method_1551();
        var font = client.field_1772;
        context.method_71048();
        boolean buttonHovered = inside(mouseX, mouseY, x, buttonY, BUTTON_SIZE, BUTTON_SIZE);
        context.method_25294(x, buttonY, x+BUTTON_SIZE, buttonY+BUTTON_SIZE, 0xDC101720);
        border(context, x, buttonY, BUTTON_SIZE, BUTTON_SIZE, buttonHovered || open ? 0xFFFFD383 : 0xFF756B57);
        context.method_51427(class_1802.field_8674.method_7854(), x+2, buttonY+2);
        if (!open) {
            if (buttonHovered) context.method_51438(font, class_2561.method_43471("craftaria_utils.chat.share"), mouseX, mouseY);
            return;
        }
        context.method_25294(x, popupY, x+popupWidth, popupY+popupHeight, 0xF2101720);
        border(context, x, popupY, popupWidth, popupHeight, 0xFFCFAD6D);
        context.method_27535(font, class_2561.method_43471("craftaria_utils.chat.share"), x+7, popupY+6, 0xFFFFD383);
        context.method_25294(x+5, popupY+18, x+popupWidth-5, popupY+19, 0xFF514D45);
        class_2561 tooltip = null;
        for (int i=0; i<ENTRIES.size(); i++) {
            Entry entry = ENTRIES.get(i);
            int y = popupY+20+i*ROW_HEIGHT;
            boolean hovered = inside(mouseX, mouseY, x+2, y, popupWidth-4, ROW_HEIGHT);
            if (hovered) {
                context.method_25294(x+2, y, x+popupWidth-2, y+ROW_HEIGHT, 0xFF29313A);
                tooltip = class_2561.method_43471("craftaria_utils.chat."+entry.label()+".description");
            }
            class_1799 icon = entry.icon().method_7854();
            if (entry.token().equals("#item") && client.field_1724 != null && !client.field_1724.method_6047().method_7960())
                icon = client.field_1724.method_6047();
            context.method_51427(icon, x+6, y+3);
            context.method_27535(font, class_2561.method_43471("craftaria_utils.chat."+entry.label()), x+28, y+7, 0xFFF0E9DA);
            context.method_25303(font, entry.token(), x+popupWidth-8-font.method_1727(entry.token()), y+7, 0xFFB8B4AA);
        }
        if (tooltip != null) context.method_51438(font, tooltip, mouseX, mouseY);
    }

    /** Return true to keep clicks on the popup from activating chat links underneath. */
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (inside(mouseX, mouseY, x, buttonY, BUTTON_SIZE, BUTTON_SIZE)) {
            if (button == 0) { open = !open; clickSound(); }
            return true;
        }
        if (!open) return false;
        if (inside(mouseX, mouseY, x, popupY, popupWidth, popupHeight)) {
            if (button == 0 && mouseY >= popupY+20) {
                int index = (int)(mouseY-popupY-20)/ROW_HEIGHT;
                if (index >= 0 && index < ENTRIES.size()) {
                    insert.accept(ENTRIES.get(index).token());
                    open = false;
                    clickSound();
                }
            }
            return true;
        }
        open = false;
        return false;
    }

    public boolean covers(double mouseX, double mouseY) {
        return open && inside(mouseX, mouseY, x, popupY, popupWidth, popupHeight);
    }
    private static boolean inside(double mouseX, double mouseY, int x, int y, int width, int height) {
        return mouseX >= x && mouseX < x+width && mouseY >= y && mouseY < y+height;
    }
    private static void clickSound() {
        class_310.method_1551().method_1483().method_4873(class_1109.method_47978(class_3417.field_15015, 1f));
    }
    private static void border(class_332 context, int x, int y, int width, int height, int color) {
        context.method_25294(x,y,x+width,y+1,color);
        context.method_25294(x,y+height-1,x+width,y+height,color);
        context.method_25294(x,y+1,x+1,y+height-1,color);
        context.method_25294(x+width-1,y+1,x+width,y+height-1,color);
    }
}
