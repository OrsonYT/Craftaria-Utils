package fr.craftaria.utils.chat;

import java.util.List;
import java.util.function.Consumer;
import net.minecraft.class_1109;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3417;

public final class ChatTeleportMenu {
    private record Entry(String command, String label, class_1792 icon) { }
    private static final List<Entry> ENTRIES = List.of(
            new Entry("tpa", "tpa", class_1802.field_8575),
            new Entry("tpahere", "tpahere", class_1802.field_8634),
            new Entry("rtp", "rtp", class_1802.field_8251),
            new Entry("warp", "warp", class_1802.field_8449),
            new Entry("home", "home", class_1802.field_8789),
            new Entry("spawn", "spawn", class_1802.field_23141),
            new Entry("casino", "casino", class_1802.field_8687),
            new Entry("crate", "crate", class_1802.field_8106));
    private static final int ROW_HEIGHT = 22;
    private final Consumer<String> action;
    private final int x = 28;
    private final int popupHeight = 22+ENTRIES.size()*ROW_HEIGHT;
    private int buttonY, popupY, popupWidth, buttonWidth;
    private boolean open;

    public ChatTeleportMenu(Consumer<String> action) { this.action = action; }
    public boolean isOpen() { return open; }
    public void close() { open = false; }
    public void layout(int screenWidth, int fieldY) {
        buttonY = Math.max(4, fieldY-26);
        buttonWidth = Math.min(112, screenWidth-x-4);
        popupWidth = Math.min(268, screenWidth-x-4);
        popupY = Math.max(2, buttonY-popupHeight-4);
    }
    public void render(class_332 context, int mouseX, int mouseY) {
        var font = class_310.method_1551().field_1772;
        context.method_71048();
        boolean hovered = inside(mouseX,mouseY,x,buttonY,buttonWidth,20);
        context.method_25294(x,buttonY,x+buttonWidth,buttonY+20,0xDC101720);
        border(context,x,buttonY,buttonWidth,20,hovered||open ? 0xFFFFD383 : 0xFF756B57);
        context.method_51427(class_1802.field_8634.method_7854(),x+2,buttonY+2);
        context.method_25303(font,font.method_27523(class_2561.method_43471("craftaria_utils.teleport.title").getString(),buttonWidth-26),x+23,buttonY+6,0xFFF0E9DA);
        if (!open) return;
        context.method_25294(x,popupY,x+popupWidth,popupY+popupHeight,0xF2101720);
        border(context,x,popupY,popupWidth,popupHeight,0xFFCFAD6D);
        context.method_27535(font,class_2561.method_43471("craftaria_utils.teleport.title"),x+7,popupY+6,0xFFFFD383);
        context.method_25294(x+5,popupY+18,x+popupWidth-5,popupY+19,0xFF514D45);
        class_2561 tooltip = null;
        for (int i=0;i<ENTRIES.size();i++) {
            Entry entry = ENTRIES.get(i);
            int y=popupY+20+i*ROW_HEIGHT;
            if (inside(mouseX,mouseY,x+2,y,popupWidth-4,ROW_HEIGHT)) {
                context.method_25294(x+2,y,x+popupWidth-2,y+ROW_HEIGHT,0xFF29313A);
                tooltip = class_2561.method_43471("craftaria_utils.teleport."+entry.label()+".description");
            }
            context.method_51427(entry.icon().method_7854(),x+6,y+3);
            context.method_27535(font,class_2561.method_43471("craftaria_utils.teleport."+entry.label()),x+28,y+7,0xFFF0E9DA);
            String command="/"+entry.command();
            context.method_25303(font,command,x+popupWidth-8-font.method_1727(command),y+7,0xFFB8B4AA);
        }
        if (tooltip!=null) context.method_51438(font,tooltip,mouseX,mouseY);
    }
    public boolean mouseClicked(double mouseX,double mouseY,int button) {
        if (inside(mouseX,mouseY,x,buttonY,buttonWidth,20)) {
            if (button==0) { open=!open; clickSound(); }
            return true;
        }
        if (!open) return false;
        if (inside(mouseX,mouseY,x,popupY,popupWidth,popupHeight)) {
            if (button==0 && mouseY>=popupY+20) {
                int index=(int)(mouseY-popupY-20)/ROW_HEIGHT;
                if (index>=0 && index<ENTRIES.size()) {
                    open=false;
                    clickSound();
                    action.accept(ENTRIES.get(index).command());
                }
            }
            return true;
        }
        open=false;
        return false;
    }
    public boolean covers(double mouseX,double mouseY) { return open && inside(mouseX,mouseY,x,popupY,popupWidth,popupHeight); }
    private static boolean inside(double mouseX,double mouseY,int x,int y,int width,int height) {
        return mouseX>=x && mouseX<x+width && mouseY>=y && mouseY<y+height;
    }
    private static void clickSound() { class_310.method_1551().method_1483().method_4873(class_1109.method_47978(class_3417.field_15015,1f)); }
    private static void border(class_332 context,int x,int y,int width,int height,int color) {
        context.method_25294(x,y,x+width,y+1,color); context.method_25294(x,y+height-1,x+width,y+height,color);
        context.method_25294(x,y+1,x+1,y+height-1,color); context.method_25294(x+width-1,y+1,x+width,y+height-1,color);
    }
}
