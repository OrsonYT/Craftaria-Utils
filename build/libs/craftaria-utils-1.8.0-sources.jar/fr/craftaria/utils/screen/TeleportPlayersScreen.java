package fr.craftaria.utils.screen;

import fr.craftaria.utils.CraftariaUtilsClient;
import fr.craftaria.utils.wallpaper.WallpaperManager;
import java.util.*;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_437;
import net.minecraft.class_442;
import net.minecraft.class_640;

/** Uses the server's live player list and Minecraft's skin cache. */
public final class TeleportPlayersScreen extends CraftariaScreen {
    public enum Mode {
        TPA("tpa"), TPAHERE("tpahere");
        public final String command;
        Mode(String command) { this.command=command; }
    }
    private final class_437 parent;
    private Mode mode;
    private class_342 search;
    private String query="";
    private List<class_640> players=List.of();
    private final List<PlayerRequestButton> buttons=new ArrayList<>();
    private List<String> roster=List.of();
    private SettingsButton previous,next;
    private int left,contentWidth,page,pageSize=1,pageCount=1,filteredCount,ticks;
    private boolean sent;
    private boolean error;

    public TeleportPlayersScreen(class_437 parent,Mode mode) {
        super(class_2561.method_43471("craftaria_utils.teleport.title"));
        this.parent=parent; this.mode=mode;
    }
    @Override protected void method_25426() {
        contentWidth=Math.min(720,field_22789-28); left=(field_22789-contentWidth)/2;
        int half=(contentWidth-8)/2;
        method_37063(new SettingsButton(left,41,half,() -> modeLabel(Mode.TPA),() -> { mode=Mode.TPA; refreshRows(); }));
        method_37063(new SettingsButton(left+half+8,41,half,() -> modeLabel(Mode.TPAHERE),() -> { mode=Mode.TPAHERE; refreshRows(); }));
        search=new class_342(field_22793,left,73,contentWidth,22,class_2561.method_43471("craftaria_utils.teleport.search"));
        search.method_1880(64);
        search.method_47404(class_2561.method_43471("craftaria_utils.teleport.search"));
        search.method_1852(query);
        search.method_1863(value -> { query=value; page=0; error=false; refreshRows(); });
        method_37063(search);
        method_37063(new SettingsButton(left,field_22790-28,60,() -> class_2561.method_43471("gui.back"),this::method_25419));
        previous=method_37063(new SettingsButton(field_22789/2-84,field_22790-28,28,() -> class_2561.method_43470("<"),() -> { page--; refreshRows(); }));
        next=method_37063(new SettingsButton(field_22789/2+56,field_22790-28,28,() -> class_2561.method_43470(">"),() -> { page++; refreshRows(); }));
        buttons.clear();
        updatePlayers();
        method_48265(search);
    }
    private class_2561 modeLabel(Mode selected) {
        return class_2561.method_43470(mode==selected?"> ":"").method_10852(class_2561.method_43471("craftaria_utils.teleport."+selected.command));
    }
    private void updatePlayers() {
        if (field_22787.method_1562()==null) players=List.of();
        else players=field_22787.method_1562().method_2880().stream()
                .filter(entry -> field_22787.field_1724==null || !entry.method_2966().id().equals(field_22787.field_1724.method_5667()))
                .sorted(Comparator.comparing(entry -> entry.method_2966().name(),String.CASE_INSENSITIVE_ORDER)).toList();
        roster=players.stream().map(entry -> entry.method_2966().id()+":"+entry.method_2966().name()).toList();
        refreshRows();
    }
    private void refreshRows() {
        for (var button:buttons) method_37066(button);
        buttons.clear();
        String filter=query.strip().toLowerCase(Locale.ROOT);
        List<class_640> filtered=players.stream().filter(entry -> entry.method_2966().name().toLowerCase(Locale.ROOT).contains(filter)).toList();
        filteredCount=filtered.size();
        int columns=contentWidth>=440?2:1;
        int rows=Math.max(1,(field_22790-146)/34);
        pageSize=columns*rows;
        pageCount=Math.max(1,(filtered.size()+pageSize-1)/pageSize);
        page=Math.clamp(page,0,pageCount-1);
        previous.field_22763=page>0; next.field_22763=page+1<pageCount;
        previous.field_22764=next.field_22764=pageCount>1;
        int tileWidth=(contentWidth-8*(columns-1))/columns;
        for (int i=0;i<pageSize && page*pageSize+i<filtered.size();i++) {
            class_640 entry=filtered.get(page*pageSize+i);
            String name=entry.method_2966().name();
            var button=method_37063(new PlayerRequestButton(left+(i%columns)*(tileWidth+8),112+(i/columns)*34,tileWidth,entry,
                    class_2561.method_43469("craftaria_utils.teleport.request_hint","/"+mode.command+" "+name),() -> request(entry)));
            buttons.add(button);
        }
    }
    private void request(class_640 target) {
        if (sent) return;
        if (field_22787.method_1562()==null || field_22787.method_1562().method_2871(target.method_2966().id())==null) {
            error=true; updatePlayers(); return;
        }
        String name=target.method_2966().name();
        if (name.isBlank() || name.chars().anyMatch(Character::isWhitespace)) { error=true; return; }
        sent=true;
        CraftariaUtilsClient.sendCommand(field_22787,mode.command+" "+name);
        method_25419();
    }
    @Override public void method_25393() {
        if (++ticks%20!=0) return;
        if (field_22787.method_1562()==null) { method_25419(); return; }
        List<String> current=field_22787.method_1562().method_2880().stream()
                .filter(entry -> field_22787.field_1724==null || !entry.method_2966().id().equals(field_22787.field_1724.method_5667()))
                .sorted(Comparator.comparing(entry -> entry.method_2966().name(),String.CASE_INSENSITIVE_ORDER))
                .map(entry -> entry.method_2966().id()+":"+entry.method_2966().name()).toList();
        if (!current.equals(roster)) updatePlayers();
    }
    @Override public boolean method_25401(double mouseX,double mouseY,double horizontal,double vertical) {
        if (mouseY>=105 && mouseY<field_22790-36 && vertical!=0) {
            page+=vertical>0?-1:1; refreshRows(); return true;
        }
        return super.method_25401(mouseX,mouseY,horizontal,vertical);
    }
    @Override public void method_25420(class_332 context,int mouseX,int mouseY,float delta) { }
    @Override public void method_25394(class_332 context,int mouseX,int mouseY,float delta) {
        WallpaperManager.draw(context,field_22789,field_22790);
        context.method_25294(0,0,field_22789,field_22790,0xBF0A1017);
        MenuTextButton.drawLabel(context,field_22785,left,12,1.5f,false,true);
        context.method_27535(field_22793,class_2561.method_43471(error?"craftaria_utils.teleport.player_left":"craftaria_utils.teleport.consent"),left,31,error?0xFFFF8888:0xFFB8B4AA);
        context.method_27535(field_22793,class_2561.method_43469("craftaria_utils.teleport.player_count",filteredCount),left,100,0xFFB8B4AA);
        if (filteredCount==0) context.method_27534(field_22793,class_2561.method_43471("craftaria_utils.teleport.no_players"),field_22789/2,field_22790/2+22,0xFFC5C1B8);
        context.method_27534(field_22793,class_2561.method_43470((page+1)+" / "+pageCount),field_22789/2,field_22790-21,0xFFF0E9DA);
        super.method_25394(context,mouseX,mouseY,delta);
    }
    @Override public void method_25419() { field_22787.method_1507(field_22787.field_1724!=null && field_22787.method_1562()!=null ? parent : new class_442()); }
}
