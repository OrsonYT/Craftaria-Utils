package fr.craftaria.utils.screen;

import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_6382;
import net.minecraft.class_640;
import net.minecraft.class_7532;
import net.minecraft.class_7919;
import org.lwjgl.glfw.GLFW;

public final class PlayerRequestButton extends class_339 {
    private final class_640 player;
    private final Runnable action;
    public PlayerRequestButton(int x,int y,int width,class_640 player,class_2561 tooltip,Runnable action) {
        super(x,y,width,28,class_2561.method_43470(player.method_2966().name()));
        this.player=player;
        this.action=action;
        method_47400(class_7919.method_47407(tooltip));
    }
    @Override protected void method_48579(class_332 context,int mouseX,int mouseY,float delta) {
        int x=method_46426(),y=method_46427(),right=x+method_25368();
        boolean hover=method_49606()||method_25370();
        context.method_25294(x,y,right,y+method_25364(),hover?0xDE29313A:0xB0101720);
        context.method_25294(x,y+method_25364()-1,right,y+method_25364(),hover?0xFFFFD383:0x806E6554);
        class_7532.method_52722(context,player.method_52810(),x+4,y+4,20);
        var font=class_310.method_1551().field_1772;
        context.method_25303(font,font.method_27523(method_25369().getString(),method_25368()-50),x+31,y+10,0xFFF0E9DA);
        context.method_25303(font,">",right-12,y+10,hover?0xFFFFD383:0xFF99968F);
    }
    @Override public void method_25348(class_11909 click,boolean doubled) { action.run(); }
    @Override public boolean method_25404(class_11908 input) {
        if (field_22763 && method_25370() && (input.comp_4795()==GLFW.GLFW_KEY_ENTER || input.comp_4795()==GLFW.GLFW_KEY_SPACE || input.comp_4795()==GLFW.GLFW_KEY_KP_ENTER)) {
            method_25354(class_310.method_1551().method_1483()); action.run(); return true;
        }
        return false;
    }
    @Override protected void method_47399(class_6382 builder) { method_37021(builder); }
}
