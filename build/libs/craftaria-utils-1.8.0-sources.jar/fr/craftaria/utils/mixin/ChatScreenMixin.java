package fr.craftaria.utils.mixin;

import fr.craftaria.utils.chat.ChatShareMenu;
import fr.craftaria.utils.chat.ChatTeleportMenu;
import fr.craftaria.utils.CraftariaUtilsClient;
import fr.craftaria.utils.screen.TeleportPlayersScreen;
import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_408;
import net.minecraft.class_437;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_408.class)
public abstract class ChatScreenMixin extends class_437 {
    @Shadow protected class_342 chatField;
    @Shadow protected String originalChatText;
    @Unique private ChatShareMenu craftariaUtils$shareMenu;
    @Unique private ChatTeleportMenu craftariaUtils$teleportMenu;

    protected ChatScreenMixin(class_2561 title) { super(title); }

    @Inject(method = "init", at = @At("TAIL"))
    private void craftariaUtils$initShareMenu(CallbackInfo ci) {
        craftariaUtils$shareMenu = new ChatShareMenu(token -> {
            int cursor = chatField.method_1881();
            String draft = chatField.method_1882();
            String prefix = cursor > 0 && !Character.isWhitespace(draft.charAt(cursor-1)) ? " " : "";
            String insertion = prefix+token;
            int available = 256-(draft.length()-chatField.method_1866().length());
            if (insertion.length()>available) {
                field_22787.field_1705.method_1758(class_2561.method_43471("craftaria_utils.chat.full"), false);
                return;
            }
            chatField.method_1867(insertion+(available>insertion.length() ? " " : ""));
            originalChatText = chatField.method_1882();
            method_25395(chatField);
            chatField.method_25365(true);
        });
        craftariaUtils$shareMenu.layout(field_22789, chatField.method_46427());
        craftariaUtils$teleportMenu = new ChatTeleportMenu(command -> {
            craftariaUtils$shareMenu.close();
            originalChatText = chatField.method_1882();
            if (command.equals("tpa") || command.equals("tpahere")) {
                field_22787.method_1507(new TeleportPlayersScreen((class_437)(Object)this,
                        command.equals("tpa") ? TeleportPlayersScreen.Mode.TPA : TeleportPlayersScreen.Mode.TPAHERE));
            } else {
                CraftariaUtilsClient.sendCommand(field_22787, command);
                field_22787.method_1507(null);
            }
        });
        craftariaUtils$teleportMenu.layout(field_22789, chatField.method_46427());
    }

    @Inject(method = "render", at = @At("TAIL"))
    private void craftariaUtils$renderShareMenu(class_332 context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        if (craftariaUtils$shareMenu != null) {
            craftariaUtils$shareMenu.layout(field_22789, chatField.method_46427());
            craftariaUtils$shareMenu.render(context, mouseX, mouseY);
        }
        if (craftariaUtils$teleportMenu != null) {
            craftariaUtils$teleportMenu.layout(field_22789, chatField.method_46427());
            craftariaUtils$teleportMenu.render(context, mouseX, mouseY);
        }
    }

    @Inject(method = "mouseClicked", at = @At("HEAD"), cancellable = true)
    private void craftariaUtils$clickShareMenu(class_11909 click, boolean doubled, CallbackInfoReturnable<Boolean> cir) {
        if (craftariaUtils$teleportMenu != null && craftariaUtils$teleportMenu.mouseClicked(click.comp_4798(), click.comp_4799(), click.method_74245())) {
            if (craftariaUtils$shareMenu != null) craftariaUtils$shareMenu.close();
            cir.setReturnValue(true);
            return;
        }
        if (craftariaUtils$shareMenu != null && craftariaUtils$shareMenu.mouseClicked(click.comp_4798(), click.comp_4799(), click.method_74245())) {
            if (craftariaUtils$teleportMenu != null) craftariaUtils$teleportMenu.close();
            cir.setReturnValue(true);
        }
    }

    @Inject(method = "keyPressed", at = @At("HEAD"), cancellable = true)
    private void craftariaUtils$closeShareMenu(class_11908 input, CallbackInfoReturnable<Boolean> cir) {
        boolean menuOpen = (craftariaUtils$shareMenu != null && craftariaUtils$shareMenu.isOpen())
                || (craftariaUtils$teleportMenu != null && craftariaUtils$teleportMenu.isOpen());
        if (menuOpen && input.comp_4795()==GLFW.GLFW_KEY_ESCAPE) {
            if (craftariaUtils$shareMenu != null) craftariaUtils$shareMenu.close();
            if (craftariaUtils$teleportMenu != null) craftariaUtils$teleportMenu.close();
            cir.setReturnValue(true);
        }
    }

    @Inject(method = "mouseScrolled", at = @At("HEAD"), cancellable = true)
    private void craftariaUtils$shareMenuScroll(double mouseX, double mouseY, double horizontal, double vertical,
                                              CallbackInfoReturnable<Boolean> cir) {
        if ((craftariaUtils$shareMenu != null && craftariaUtils$shareMenu.covers(mouseX, mouseY))
                || (craftariaUtils$teleportMenu != null && craftariaUtils$teleportMenu.covers(mouseX, mouseY))) cir.setReturnValue(true);
    }
}
