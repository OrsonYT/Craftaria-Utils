package fr.craftaria.utils.chat;

import java.util.List;
import java.util.function.Consumer;
import java.util.function.Supplier;
import net.minecraft.class_1109;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3417;

/** Scrollable command popup shared by the teleportation and general buttons. */
public class ChatActionMenu {
    public record Action(String id, class_2561 label, class_1799 icon, class_2561 description, String hint) {
        public static Action command(String command, String key, class_1792 icon) {
            return new Action(command,class_2561.method_43471(key),icon.method_7854(),class_2561.method_43471(key+".description"),"/"+command);
        }
    }
    private static final int ROW_HEIGHT=22;
    private final int buttonX,buttonWidth;
    private final class_2561 title;
    private final class_1792 buttonIcon;
    private final Supplier<List<Action>> source;
    private final Consumer<String> action;
    private int buttonY,popupX,popupY,popupWidth,popupHeight,visibleRows,offset;
    private List<Action> entries=List.of();
    private boolean open;
    public ChatActionMenu(int x,int width,class_2561 title,class_1792 icon,Supplier<List<Action>> source,Consumer<String> action) {
        buttonX=x; buttonWidth=width; this.title=title; buttonIcon=icon; this.source=source; this.action=action;
    }
    public boolean isOpen() { return open; }
    public void close() { open=false; }
    public void layout(int screenWidth,int fieldY) {
        entries=source.get();
        buttonY=Math.max(4,fieldY-26);
        popupWidth=Math.min(296,screenWidth-8);
        popupX=Math.max(4,Math.min(buttonX,screenWidth-popupWidth-4));
        visibleRows=Math.max(1,Math.min(entries.size(),(buttonY-24)/ROW_HEIGHT));
        offset=Math.clamp(offset,0,Math.max(0,entries.size()-visibleRows));
        popupHeight=22+visibleRows*ROW_HEIGHT;
        popupY=Math.max(2,buttonY-popupHeight-4);
    }
    public void render(class_332 context,int mouseX,int mouseY) {
        var font=class_310.method_1551().field_1772;
        context.method_71048();
        boolean hover=inside(mouseX,mouseY,buttonX,buttonY,buttonWidth,20);
        context.method_25294(buttonX,buttonY,buttonX+buttonWidth,buttonY+20,0xDC101720);
        border(context,buttonX,buttonY,buttonWidth,20,hover||open?0xFFFFD383:0xFF756B57);
        context.method_51427(buttonIcon.method_7854(),buttonX+2,buttonY+2);
        context.method_25303(font,font.method_27523(title.getString(),buttonWidth-26),buttonX+23,buttonY+6,0xFFF0E9DA);
        if (!open) return;
        context.method_25294(popupX,popupY,popupX+popupWidth,popupY+popupHeight,0xF2101720);
        border(context,popupX,popupY,popupWidth,popupHeight,0xFFCFAD6D);
        context.method_27535(font,title,popupX+7,popupY+6,0xFFFFD383);
        if (entries.size()>visibleRows) {
            String range=(offset+1)+"-"+(offset+visibleRows)+" / "+entries.size();
            context.method_25303(font,range,popupX+popupWidth-8-font.method_1727(range),popupY+6,0xFFB8B4AA);
        }
        context.method_25294(popupX+5,popupY+18,popupX+popupWidth-5,popupY+19,0xFF514D45);
        class_2561 tooltip=null;
        for (int i=0;i<visibleRows && offset+i<entries.size();i++) {
            Action entry=entries.get(offset+i);
            int y=popupY+20+i*ROW_HEIGHT;
            if (inside(mouseX,mouseY,popupX+2,y,popupWidth-4,ROW_HEIGHT)) {
                context.method_25294(popupX+2,y,popupX+popupWidth-2,y+ROW_HEIGHT,0xFF29313A);
                tooltip=entry.description().method_27661().method_27693("\n"+entry.hint());
            }
            context.method_51427(entry.icon(),popupX+6,y+3);
            String hint=font.method_27523(entry.hint(),96);
            int labelWidth=popupWidth-44-font.method_1727(hint);
            context.method_25303(font,font.method_27523(entry.label().getString(),labelWidth),popupX+28,y+7,0xFFF0E9DA);
            context.method_25303(font,hint,popupX+popupWidth-9-font.method_1727(hint),y+7,0xFFB8B4AA);
        }
        if (entries.size()>visibleRows) {
            int track=visibleRows*ROW_HEIGHT;
            int thumb=Math.max(8,track*visibleRows/entries.size());
            int y=popupY+20+(track-thumb)*offset/(entries.size()-visibleRows);
            context.method_25294(popupX+popupWidth-3,y,popupX+popupWidth-2,y+thumb,0xFFCFAD6D);
        }
        if (tooltip!=null) context.method_51438(font,tooltip,mouseX,mouseY);
    }
    public boolean mouseClicked(double mouseX,double mouseY,int button) {
        if (inside(mouseX,mouseY,buttonX,buttonY,buttonWidth,20)) {
            if (button==0) { open=!open; clickSound(); }
            return true;
        }
        if (!open) return false;
        if (covers(mouseX,mouseY)) {
            if (button==0 && mouseY>=popupY+20) {
                int row=(int)(mouseY-popupY-20)/ROW_HEIGHT;
                if (row<visibleRows && offset+row<entries.size()) {
                    open=false; clickSound(); action.accept(entries.get(offset+row).id());
                }
            }
            return true;
        }
        open=false; return false;
    }
    public boolean mouseScrolled(double mouseX,double mouseY,double amount) {
        if (!covers(mouseX,mouseY)) return false;
        if (amount!=0) offset=Math.clamp(offset+(amount>0?-1:1),0,Math.max(0,entries.size()-visibleRows));
        return true;
    }
    public boolean covers(double mouseX,double mouseY) { return open && inside(mouseX,mouseY,popupX,popupY,popupWidth,popupHeight); }
    private static boolean inside(double mx,double my,int x,int y,int w,int h) { return mx>=x && mx<x+w && my>=y && my<y+h; }
    private static void clickSound() { class_310.method_1551().method_1483().method_4873(class_1109.method_47978(class_3417.field_15015,1f)); }
    private static void border(class_332 c,int x,int y,int w,int h,int color) {
        c.method_25294(x,y,x+w,y+1,color); c.method_25294(x,y+h-1,x+w,y+h,color);
        c.method_25294(x,y+1,x+1,y+h-1,color); c.method_25294(x+w-1,y+1,x+w,y+h-1,color);
    }
}
