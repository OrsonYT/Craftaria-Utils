package fr.craftaria.utils;

import com.mojang.authlib.GameProfile;
import java.util.Locale;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import net.minecraft.class_310;
import net.minecraft.class_8685;

/** Resolves and caches Mojang skin textures for usernames in the connection tracker. */
public final class TrackedPlayerSkins {
    private static final ConcurrentMap<String, class_8685> SKINS = new ConcurrentHashMap<>();
    private static final ConcurrentMap<String, Boolean> PENDING = new ConcurrentHashMap<>();

    private TrackedPlayerSkins() { }

    public static class_8685 get(String name) { return SKINS.get(key(name)); }

    public static void request(String name) {
        if (name == null || name.isBlank()) return;
        String key = key(name);
        if (SKINS.containsKey(key) || PENDING.putIfAbsent(key, true) != null) return;
        class_310 client = class_310.method_1551();
        var online = client.method_1562() == null ? null : client.method_1562().method_2874(name);
        if (online != null) {
            SKINS.put(key, online.method_52810());
            PENDING.remove(key);
            return;
        }
        java.util.concurrent.CompletableFuture.supplyAsync(() -> {
            try { return client.method_73361().comp_839().findProfileByName(name).orElse(null); }
            catch (Exception ignored) { return null; }
        }).thenCompose(profile -> {
            if (profile == null) return java.util.concurrent.CompletableFuture.completedFuture(null);
            return client.method_1582().method_52863(new GameProfile(profile.id(), profile.name()));
        }).whenComplete((textures, error) -> client.execute(() -> {
            PENDING.remove(key);
            if (error == null && textures != null) textures.ifPresent(value -> SKINS.put(key, value));
        }));
    }

    private static String key(String name) { return name.toLowerCase(Locale.ROOT); }
}
