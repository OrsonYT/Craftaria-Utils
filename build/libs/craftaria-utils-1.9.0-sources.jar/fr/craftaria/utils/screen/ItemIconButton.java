package fr.craftaria.utils.screen;

import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_6382;
import net.minecraft.class_7919;
import org.lwjgl.glfw.GLFW;

public final class ItemIconButton extends class_339 {
    private final class_1799 icon;
    private final boolean selected;
    private final Runnable action;
    public ItemIconButton(int x,int y,class_1799 icon,boolean selected,class_2561 tooltip,Runnable action) {
        super(x,y,24,24,tooltip); this.icon=icon; this.selected=selected; this.action=action;
        method_47400(class_7919.method_47407(tooltip));
    }
    @Override protected void method_48579(class_332 c,int mouseX,int mouseY,float delta) {
        int x=method_46426(),y=method_46427();
        c.method_25294(x,y,x+24,y+24,0xC0101720);
        int color=selected?0xFFFFD383:method_49606()||method_25370()?0xFFE4D3AC:0xFF514D45;
        c.method_25294(x,y,x+24,y+1,color); c.method_25294(x,y+23,x+24,y+24,color);
        c.method_25294(x,y+1,x+1,y+23,color); c.method_25294(x+23,y+1,x+24,y+23,color);
        c.method_51427(icon,x+4,y+4);
    }
    @Override public void method_25348(class_11909 click,boolean doubled) { action.run(); }
    @Override public boolean method_25404(class_11908 input) {
        if (field_22763 && method_25370() && (input.comp_4795()==GLFW.GLFW_KEY_ENTER || input.comp_4795()==GLFW.GLFW_KEY_SPACE || input.comp_4795()==GLFW.GLFW_KEY_KP_ENTER)) {
            method_25354(class_310.method_1551().method_1483()); action.run(); return true;
        }
        return false;
    }
    @Override protected void method_47399(class_6382 builder) { method_37021(builder); }
}
