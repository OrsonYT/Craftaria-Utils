package fr.craftaria.utils.screen;

import fr.craftaria.utils.wallpaper.WallpaperManager;
import java.util.*;
import java.util.function.Consumer;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_437;
import net.minecraft.class_7923;

public final class ItemIconPickerScreen extends CraftariaScreen {
    private final class_437 parent;
    private final String selected;
    private final Consumer<String> choose;
    private final List<ItemIconButton> icons=new ArrayList<>();
    private final List<class_1792> allItems;
    private SettingsButton previous,next;
    private String query="";
    private int left,contentWidth,page,pageCount=1,count;
    public ItemIconPickerScreen(class_437 parent,String selected,Consumer<String> choose) {
        super(class_2561.method_43471("craftaria_utils.quick_homes.choose_icon"));
        this.parent=parent; this.selected=selected; this.choose=choose;
        allItems=class_7923.field_41178.method_10220().filter(item -> item!=class_1802.field_8162)
                .sorted(Comparator.comparing(item -> class_7923.field_41178.method_10221(item).toString())).toList();
    }
    @Override protected void method_25426() {
        contentWidth=Math.min(780,field_22789-28); left=(field_22789-contentWidth)/2;
        var search=method_37063(new class_342(field_22793,left,42,contentWidth,22,class_2561.method_43471("craftaria_utils.quick_homes.search_icon")));
        search.method_47404(class_2561.method_43471("craftaria_utils.quick_homes.search_icon"));
        search.method_1852(query);
        search.method_1863(value -> { query=value; page=0; refreshIcons(); });
        method_37063(new SettingsButton(left,field_22790-28,60,() -> class_2561.method_43471("gui.back"),this::method_25419));
        previous=method_37063(new SettingsButton(field_22789/2-84,field_22790-28,28,() -> class_2561.method_43470("<"),() -> { page--; refreshIcons(); }));
        next=method_37063(new SettingsButton(field_22789/2+56,field_22790-28,28,() -> class_2561.method_43470(">"),() -> { page++; refreshIcons(); }));
        icons.clear(); refreshIcons(); method_48265(search);
    }
    private void refreshIcons() {
        for (var icon:icons) method_37066(icon);
        icons.clear();
        String filter=query.strip().toLowerCase(Locale.ROOT);
        List<class_1792> filtered=allItems.stream().filter(item -> class_7923.field_41178.method_10221(item).toString().contains(filter)
                || item.method_63680().getString().toLowerCase(Locale.ROOT).contains(filter)).toList();
        count=filtered.size();
        int columns=Math.max(1,contentWidth/28),rows=Math.max(1,(field_22790-114)/28),size=columns*rows;
        pageCount=Math.max(1,(count+size-1)/size); page=Math.clamp(page,0,pageCount-1);
        previous.field_22763=page>0; next.field_22763=page+1<pageCount;
        for (int i=0;i<size && page*size+i<count;i++) {
            class_1792 item=filtered.get(page*size+i);
            String id=class_7923.field_41178.method_10221(item).toString();
            class_2561 tooltip=item.method_63680().method_27661().method_27693("\n"+id);
            icons.add(method_37063(new ItemIconButton(left+(i%columns)*28,76+(i/columns)*28,item.method_7854(),id.equals(selected),tooltip,() -> {
                choose.accept(id); field_22787.method_1507(parent);
            })));
        }
    }
    @Override public boolean method_25401(double x,double y,double horizontal,double vertical) {
        if (y>=70 && y<field_22790-36 && vertical!=0) { page+=vertical>0?-1:1; refreshIcons(); return true; }
        return super.method_25401(x,y,horizontal,vertical);
    }
    @Override public void method_25420(class_332 c,int x,int y,float delta) { }
    @Override public void method_25394(class_332 c,int x,int y,float delta) {
        WallpaperManager.draw(c,field_22789,field_22790); c.method_25294(0,0,field_22789,field_22790,0xBF0A1017);
        MenuTextButton.drawLabel(c,field_22785,left,13,1.4f,false,true);
        if (count==0) c.method_27534(field_22793,class_2561.method_43471("craftaria_utils.quick_homes.no_items"),field_22789/2,field_22790/2,0xFFC5C1B8);
        c.method_27534(field_22793,class_2561.method_43470((page+1)+" / "+pageCount),field_22789/2,field_22790-21,0xFFF0E9DA);
        super.method_25394(c,x,y,delta);
    }
    @Override public void method_25419() { field_22787.method_1507(parent); }
}
