package fr.craftaria.utils.screen;

import net.minecraft.class_10799;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_412;
import net.minecraft.class_429;
import net.minecraft.class_437;
import net.minecraft.class_442;
import net.minecraft.class_639;
import net.minecraft.class_642;

public final class CraftariaTitleScreen extends class_437 {
    public static final String SERVER = "play.craftaria.fr";
    private static final class_2960 BACKGROUND = class_2960.method_60655("craftaria_utils", "fondbase.png");
    private static final class_2960 LOGO = class_2960.method_60655("craftaria_utils", "icon-transparent.png");
    private boolean connecting;
    private final ServerStatusPanel serverStatus = new ServerStatusPanel();
    private MenuTextButton connectButton;

    public CraftariaTitleScreen() {
        super(class_2561.method_43470("Craftaria Utils"));
        MenuNavigation.selectCustom();
    }
    public float layoutScale() { return Math.min(field_22789 / 960f, field_22790 / 540f); }
    public int left() { return Math.round(64 * layoutScale()); }

    @Override protected void method_25426() {
        connecting = false;
        serverStatus.open();
        float s = layoutScale();
        int left = left();
        connectButton = method_37063(new MenuTextButton(left, Math.round(185*s), Math.round(570*s), Math.round(48*s),
                class_2561.method_43471("craftaria_utils.menu.connect"), 3.2f*s, this::connect));
        method_37063(new MenuTextButton(left, Math.round(285*s), Math.round(500*s), Math.round(32*s),
                class_2561.method_43471("craftaria_utils.menu.vanilla"), 2.1f*s, () -> field_22787.method_1507(new VanillaTitleScreen())));
        method_37063(new MenuTextButton(left, Math.round(333*s), Math.round(320*s), Math.round(32*s),
                class_2561.method_43471("menu.options"), 2.1f*s, () -> field_22787.method_1507(new class_429(this, field_22787.field_1690))));
        method_37063(new MenuTextButton(left, Math.round(381*s), Math.round(320*s), Math.round(32*s),
                class_2561.method_43471("menu.quit"), 2.1f*s, () -> field_22787.method_1592()));
    }

    private void connect() {
        if (connecting) return;
        connecting = true;
        connectButton.method_25355(class_2561.method_43471("craftaria_utils.menu.connecting"));
        connectButton.field_22763 = false;
        class_412.method_36877(this, field_22787, class_639.method_2950(SERVER),
                new class_642("Craftaria", SERVER, class_642.class_8678.field_45611), false, null);
    }

    public void renderScene(class_332 context, int width, int height) {
        float cover = Math.max(width / 2560f, height / 1600f);
        int w = (int)Math.ceil(2560*cover), h = (int)Math.ceil(1600*cover);
        context.method_25302(class_10799.field_56883, BACKGROUND, (width-w)/2, (height-h)/2,
                0, 0, w, h, 2560, 1600, 2560, 1600);
        for (int x = 0; x < width * .65f; x += 2) {
            int alpha = Math.round(72 * (1 - x / (width * .65f)));
            context.method_25294(x, 0, x+2, height, alpha << 24);
        }
        float s = Math.min(width/960f, height/540f);
        int size = Math.round(74*s), left = Math.round(36*s), top = Math.round(26*s);
        context.method_25302(class_10799.field_56883, LOGO, left, top, 0, 0, size, size, 1254, 1254, 1254, 1254);
        serverStatus.render(context, width, height);
        String[] credits = {
                "Craftaria Utils by OrsonBlockTV",
                "Minecraft 1.21.11 — Thanks to Fabric for the loader",
                "Copyright Mojang AB. Do not distribute!"
        };
        float creditScale = Math.clamp(s, 0.5f, 0.7f);
        context.method_51448().pushMatrix();
        context.method_51448().scale(creditScale, creditScale);
        for (int i = 0; i < credits.length; i++) {
            int creditX = (int)((width - 6) / creditScale) - field_22793.method_1727(credits[i]);
            int creditY = (int)((height - 6) / creditScale) - (credits.length - i) * 10;
            context.method_27535(field_22793, class_2561.method_43470(credits[i]), creditX, creditY, 0xFFCDC7BA);
        }
        context.method_51448().popMatrix();
    }

    public void renderConnecting(class_332 context, int width, int height, class_2561 status) {
        renderScene(context, width, height);
        float s = Math.min(width/960f, height/540f);
        MenuTextButton.drawLabel(context, class_2561.method_43471("craftaria_utils.menu.connecting"), Math.round(64*s), Math.round(185*s), 3.2f*s, false, false);
        context.method_27535(field_22793, status, Math.round(64*s), Math.round(246*s), 0xFFE2D9C4);
    }

    @Override public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        renderScene(context, field_22789, field_22790);
        super.method_25394(context, mouseX, mouseY, delta);
    }
    @Override public void method_25420(class_332 context, int mouseX, int mouseY, float delta) { }
    @Override public void method_25393() { serverStatus.tick(); }
    @Override public void method_25432() { serverStatus.close(); }
    @Override public boolean method_25422() { return false; }

    /** Explicit escape hatch: its subclass identity prevents automatic menu replacement. */
    public static final class VanillaTitleScreen extends class_442 {
        public VanillaTitleScreen() { MenuNavigation.selectVanilla(); }
    }
}
