package fr.craftaria.utils;

import fr.craftaria.utils.config.ModConfig;
import fr.craftaria.utils.cooking.CookingQueue;
import fr.craftaria.utils.screen.CraftariaConfigScreen;
import fr.craftaria.utils.screen.CookingScreen;
import fr.craftaria.utils.screen.LoginConfirmScreen;
import fr.craftaria.utils.wallpaper.WallpaperManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_2561;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import net.minecraft.class_7923;
import org.lwjgl.glfw.GLFW;

public final class CraftariaUtilsClient implements ClientModInitializer {
    public static class_304 fourKey, loginKey, cookingKey;
    private static int previousDamage = -1;
    private static String previousItem = "";
    private static boolean repairSent;

    @Override public void onInitializeClient() {
        ModConfig.load();
        ConnectionTracker.initialize();
        WallpaperManager.initializeDirectory();
        fourKey = register("key.craftaria_utils.four");
        loginKey = register("key.craftaria_utils.login");
        cookingKey = register("key.craftaria_utils.cooking");
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (fourKey.method_1436()) sendCommand(client, "four");
            while (loginKey.method_1436()) {
                if (!ModConfig.get().password.isBlank()) client.method_1507(new LoginConfirmScreen(client.field_1755));
                else client.field_1705.method_1743().method_1812(class_2561.method_43471("craftaria_utils.login.no_password"));
            }
            while (cookingKey.method_1436()) client.method_1507(new CookingScreen(client.field_1755));
            CookingQueue.tick(client);
            checkRepair(client);
        });
    }
    private static class_304 register(String translationKey) {
        return KeyBindingHelper.registerKeyBinding(new class_304(translationKey, class_3675.class_307.field_1668, GLFW.GLFW_KEY_UNKNOWN, "key.categories.craftaria_utils"));
    }
    public static void sendCommand(class_310 client, String command) {
        if (client.field_1724 != null && client.method_1562() != null) client.method_1562().method_45730(command);
    }
    private static void checkRepair(class_310 client) {
        if (!ModConfig.get().autoRepair || client.field_1724 == null || client.method_1562() == null) return;
        var stack = client.field_1724.method_6047();
        if (!stack.method_7963() || stack.method_7960()) { previousDamage = -1; previousItem = ""; repairSent = false; return; }
        String itemId = class_7923.field_41178.method_10221(stack.method_7909()).toString();
        int damage = stack.method_7919();
        if (!itemId.equals(previousItem) || damage < previousDamage) repairSent = false;
        int remainingPercent = (stack.method_7936() - damage) * 100 / stack.method_7936();
        if (!repairSent && damage > 0 && remainingPercent <= ModConfig.get().repairThresholdPercent) {
            sendCommand(client, "repair");
            repairSent = true;
        }
        previousDamage = damage; previousItem = itemId;
    }
}
