package fr.craftaria.utils;

import fr.craftaria.utils.config.ModConfig;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3417;
import net.minecraft.class_640;
import net.minecraft.class_7532;
import java.util.Arrays;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

/** Watches server join announcements for usernames explicitly listed by the player. */
public final class ConnectionTracker {
    private static final Pattern JOIN = Pattern.compile("(?i)\\b([A-Za-z0-9_]{3,16})\\s+(?:vient de se connect(?:é|e)|s'est connect(?:é|e)(?:e)?|a rejoint (?:le jeu|le serveur)|joined(?: the game| the server)?|has joined the game)\\b");
    private static String playerName;
    private static long expiresAt;

    private ConnectionTracker() { }

    public static void initialize() {
        ClientReceiveMessageEvents.GAME.register((message, overlay) -> onServerMessage(message.getString()));
    }

    private static void onServerMessage(String message) {
        if (!ModConfig.get().connectionTrackerEnabled || class_310.method_1551().field_1724 == null) return;
        Matcher matcher = JOIN.matcher(message.replace('\u00a0', ' '));
        if (!matcher.find()) return;
        String candidate = matcher.group(1);
        Set<String> tracked = Arrays.stream(ModConfig.get().trackedPlayers.split("[,;\\n]"))
                .map(String::strip).filter(name -> !name.isEmpty()).map(name -> name.toLowerCase(Locale.ROOT)).collect(Collectors.toSet());
        if (!tracked.contains(candidate.toLowerCase(Locale.ROOT))) return;
        class_310 client = class_310.method_1551();
        playerName = candidate;
        expiresAt = System.currentTimeMillis() + 5500;
        client.method_1483().method_4873(net.minecraft.class_1109.method_4757(class_3417.field_14627, 0.8f, 0.85f));
    }

    public static void render(class_332 context, class_310 client) {
        if (playerName == null) return;
        if (System.currentTimeMillis() >= expiresAt || client.field_1724 == null) { playerName = null; return; }
        if (client.field_1755 != null) return;

        int width = 230, height = 48;
        int x = (context.method_51421() - width) / 2;
        // Sit below the server's boss bars and announcements, leaving the crosshair unobstructed.
        int y = 52;
        context.method_25294(x, y, x+width, y+height, 0xE6101720);
        context.method_25294(x, y, x+width, y+2, 0xFFFFD383);
        context.method_25294(x, y+height-1, x+width, y+height, 0xFF756B57);
        context.method_25294(x, y+2, x+1, y+height-1, 0xFF756B57);
        context.method_25294(x+width-1, y+2, x+width, y+height-1, 0xFF756B57);
        class_640 entry = client.method_1562() == null ? null : client.method_1562().method_2874(playerName);
        if (entry != null) class_7532.method_52722(context, entry.method_52810(), x+8, y+8, 32);
        else context.method_51427(class_1802.field_8575.method_7854(), x+12, y+12);

        context.method_27535(client.field_1772, class_2561.method_43470(playerName), x+49, y+10, 0xFFFFD383);
        context.method_27535(client.field_1772, class_2561.method_43471("craftaria_utils.tracker.joined"), x+49, y+26, 0xFFF0E9DA);
        int remaining = (int)Math.clamp((expiresAt-System.currentTimeMillis())*100/5500, 0, 100);
        context.method_25294(x+49, y+40, x+width-9, y+42, 0xFF45454B);
        context.method_25294(x+49, y+40, x+49+(width-58)*remaining/100, y+42, 0xFFFFD383);
    }
}
