package fr.craftaria.utils.mixin;

import fr.craftaria.utils.ServerArrival;
import net.minecraft.class_2535;
import net.minecraft.class_2596;
import net.minecraft.class_2856;
import net.minecraft.class_8673;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_8673.class)
public abstract class ResourcePackArrivalMixin {
    @Shadow @Final protected class_2535 connection;
    @Inject(method="sendPacket",at=@At("HEAD"))
    private void craftariaUtils$packStatus(class_2596<?> packet, CallbackInfo ci) {
        if(packet instanceof class_2856 status) ServerArrival.resourcePackStatus(connection,status);
    }
}
