package fr.craftaria.utils.protection;

import fr.craftaria.utils.config.ModConfig;
import java.util.ArrayList;
import java.util.Base64;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.class_1799;
import net.minecraft.class_2509;
import net.minecraft.class_310;
import net.minecraft.class_5455;
import net.minecraft.class_7923;

/** Tracks selected stacks individually using their complete item components and count. */
public final class ProtectedStacks {
    private static final String PREFIX = "stack:";
    private ProtectedStacks() { }

    public static String fingerprint(class_1799 stack, class_5455 registries) {
        if (stack == null || stack.method_7960()) return "";
        var normalized = stack.method_46651(1);
        normalized.method_57381(net.minecraft.class_9334.field_49629);
        var encoded = class_1799.field_24671.encodeStart(registries.method_57093(class_2509.field_11560), normalized)
                .result().orElse(null);
        if (encoded == null) return "";
        return PREFIX + class_7923.field_41178.method_10221(stack.method_7909()) + ":"
                + Base64.getUrlEncoder().withoutPadding().encodeToString(encoded.toString().getBytes(java.nio.charset.StandardCharsets.UTF_8));
    }

    public static int count(class_1799 stack, class_5455 registries) {
        String key = fingerprint(stack, registries);
        return key.isEmpty() ? 0 : ModConfig.get().protectedStackCounts.getOrDefault(key, 0);
    }

    public static boolean isProtected(class_1799 stack, class_5455 registries) {
        return !stack.method_7960() && count(stack, registries) > 0;
    }

    public static void add(class_1799 stack, class_5455 registries) {
        String key = fingerprint(stack, registries);
        if (key.isEmpty()) return;
        ModConfig.get().protectedStackCounts.put(key, stack.method_7947());
        syncList();
    }

    public static void remove(class_1799 stack, class_5455 registries) {
        ModConfig.get().protectedStackCounts.remove(fingerprint(stack, registries));
        syncList();
    }

    /** Missing and ambiguous selections are retained; never guess a replacement by item type. */
    public static boolean needsReselection(List<class_1799> inventory, class_5455 registries) {
        Map<String, Integer> occurrences = new LinkedHashMap<>();
        for (class_1799 stack : inventory) if (!stack.method_7960())
            occurrences.merge(fingerprint(stack, registries), 1, Integer::sum);
        for (String key : ModConfig.get().protectedStackCounts.keySet())
            if (occurrences.getOrDefault(key, 0) != 1) return true;
        return !ModConfig.get().protectedItems.isEmpty() && ModConfig.get().protectedStackCounts.isEmpty();
    }

    public static String decodePayload(String key) {
        int separator = key.indexOf(':', key.indexOf(':', PREFIX.length()) + 1);
        return new String(Base64.getUrlDecoder().decode(key.substring(separator + 1)), java.nio.charset.StandardCharsets.UTF_8);
    }

    /** Upgrade old full snapshots without guessing which inventory item they describe. */
    public static void migrate(class_5455 registries) {
        Map<String, Integer> normalized = new LinkedHashMap<>();
        for (var entry : ModConfig.get().protectedStackCounts.entrySet()) {
            try {
                var stack = class_1799.method_57360(registries, net.minecraft.class_2522.method_10718(decodePayload(entry.getKey()))).orElse(class_1799.field_8037);
                String key = fingerprint(stack, registries);
                normalized.merge(key.isEmpty() ? entry.getKey() : key, entry.getValue(), Integer::sum);
            } catch (Exception ignored) { normalized.put(entry.getKey(), entry.getValue()); }
        }
        if (!normalized.equals(ModConfig.get().protectedStackCounts)) {
            ModConfig.get().protectedStackCounts = normalized;
            syncList();
            ModConfig.save();
        }
    }

    public static void removeKey(String key) {
        ModConfig.get().protectedStackCounts.remove(key);
        syncList();
    }

    public static class_1799 previewStack(String key) {
        if (key.startsWith("legacy:")) return fr.craftaria.utils.config.QuickHome.iconStack(key.substring("legacy:".length()));
        try {
            String encoded = decodePayload(key);
            var nbt = net.minecraft.class_2522.method_10718(encoded);
            var client = class_310.method_1551();
            if (client.field_1687 != null) return class_1799.method_57360(client.field_1687.method_30349(), nbt).orElse(class_1799.field_8037);
        } catch (Exception ignored) { }
        return class_1799.field_8037;
    }

    private static String itemId(String fingerprint) {
        if (!fingerprint.startsWith(PREFIX)) return "";
        int separator = fingerprint.indexOf(':', PREFIX.length());
        return separator < 0 ? fingerprint.substring(PREFIX.length()) : fingerprint.substring(PREFIX.length(), separator);
    }

    private static void syncList() {
        ModConfig.get().protectedItems = new ArrayList<>(ModConfig.get().protectedStackCounts.keySet());
    }
}
