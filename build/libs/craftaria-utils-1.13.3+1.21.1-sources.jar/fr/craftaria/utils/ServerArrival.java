package fr.craftaria.utils;

import java.util.HashSet;
import java.util.Map;
import java.util.UUID;
import java.util.WeakHashMap;
import net.minecraft.class_2535;
import net.minecraft.class_2856;
import net.minecraft.class_310;

/** The proxy world is not considered the destination until the server pack has loaded. */
public final class ServerArrival {
    private static final Map<class_2535, Packs> packs = new WeakHashMap<>();
    private static Object world;
    private static int stableTicks;
    private static boolean ready;
    private static final class Packs {
        final HashSet<UUID> pending = new HashSet<>();
        boolean loaded;
    }
    private ServerArrival() { }
    public static synchronized void resourcePackStatus(class_2535 connection, class_2856 packet) {
        var state=packs.computeIfAbsent(connection, key -> new Packs());
        switch(packet.comp_2164()) {
            case field_13016, field_47704 -> state.pending.add(packet.comp_2163());
            case field_13017 -> { state.pending.remove(packet.comp_2163()); state.loaded=true; }
            default -> { state.pending.remove(packet.comp_2163()); state.loaded=false; }
        }
        stableTicks=0; ready=false;
    }
    public static synchronized void tick(class_310 client) {
        if(world!=client.field_1687) { world=client.field_1687; stableTicks=0; ready=false; }
        var network=client.method_1562();
        if(client.field_1687==null || client.field_1724==null || network==null) { stableTicks=0; ready=false; return; }
        var state=packs.get(network.method_48296());
        var server=client.method_1558();
        String host=server==null?"":server.field_3761.toLowerCase(java.util.Locale.ROOT).split(":",2)[0];
        boolean craftaria=host.equals("craftaria.fr") || host.endsWith(".craftaria.fr");
        boolean packReady=state==null?!craftaria:state.loaded && state.pending.isEmpty();
        if(!packReady || client.method_18506()!=null) { stableTicks=0; ready=false; return; }
        // Once arrived, opening ordinary menus does not suspend protection.
        if(!ready) {
            if(client.field_1755!=null) { stableTicks=0; return; }
            if(++stableTicks>=40) ready=true;
        }
    }
    public static synchronized boolean isReady() { return ready; }
}
