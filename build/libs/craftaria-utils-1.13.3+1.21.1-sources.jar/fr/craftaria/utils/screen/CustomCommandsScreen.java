package fr.craftaria.utils.screen;

import fr.craftaria.utils.config.ModConfig;
import fr.craftaria.utils.config.CustomCommand;
import fr.craftaria.utils.wallpaper.WallpaperManager;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_437;

/** The same settings page is accessible from the mod settings and the chat popup. */
public final class CustomCommandsScreen extends CraftariaScreen {
    private final class_437 parent;
    private String commandDraft="",labelDraft="",icon="minecraft:command_block",editing;
    private class_342 commandField,labelField;
    private SettingsButton save;
    private String status;
    private int left,contentWidth,page,pageSize=1,pageCount=1;
    public CustomCommandsScreen(class_437 parent) { super(class_2561.method_43471("craftaria_utils.custom_commands.title")); this.parent=parent; }
    public void editCommand(CustomCommand home) { edit(home); }
    @Override protected void method_25426() {
        contentWidth=Math.min(680,field_22789-28); left=(field_22789-contentWidth)/2;
        int commandWidth=Math.max(100,contentWidth/3-8);
        int labelWidth=contentWidth-commandWidth-54-100;
        commandField=method_37063(new class_342(field_22793,left,60,commandWidth,22,class_2561.method_43471("craftaria_utils.custom_commands.command")));
        commandField.method_47404(class_2561.method_43471("craftaria_utils.custom_commands.command"));
        commandField.method_1880(256); commandField.method_1852(commandDraft);
        commandField.method_1863(value -> commandDraft=value);
        labelField=method_37063(new class_342(field_22793,left+commandWidth+8,60,labelWidth,22,class_2561.method_43471("craftaria_utils.custom_commands.friendly_name")));
        labelField.method_47404(class_2561.method_43471("craftaria_utils.custom_commands.friendly_name"));
        labelField.method_1880(32); labelField.method_1852(labelDraft);
        labelField.method_1863(value -> labelDraft=value);
        int iconX=left+commandWidth+8+labelWidth+8;
        method_37063(new ItemIconButton(iconX,59,CustomCommand.iconStack(icon),false,
                class_2561.method_43471("craftaria_utils.custom_commands.choose_icon"),() -> field_22787.method_1507(new ItemIconPickerScreen(this,icon,value -> icon=value))));
        save=method_37063(new SettingsButton(left+contentWidth-100,60,100,
                () -> class_2561.method_43471(editing==null?"craftaria_utils.custom_commands.save":"craftaria_utils.custom_commands.update"),this::saveCommand));
        List<CustomCommand> homes=ModConfig.get().customCommands;
        pageSize=Math.max(1,(field_22790-174)/32); pageCount=Math.max(1,(homes.size()+pageSize-1)/pageSize); page=Math.clamp(page,0,pageCount-1);
        for (int i=0;i<pageSize && page*pageSize+i<homes.size();i++) {
            CustomCommand home=homes.get(page*pageSize+i); int y=132+i*32;
            method_37063(new ItemIconButton(left,y,CustomCommand.iconStack(home.icon),false,class_2561.method_43470(home.label()+" — /"+home.name),() -> edit(home)));
            method_37063(new SettingsButton(left+30,y+1,contentWidth-110,() -> class_2561.method_43470(home.label()+"  →  /"+home.name),() -> edit(home)));
            method_37063(new SettingsButton(left+contentWidth-72,y+1,72,() -> class_2561.method_43471("craftaria_utils.custom_commands.delete"),() -> {
                ModConfig.get().customCommands.remove(home);
                if (home.name.equals(editing)) resetDraft();
                ModConfig.save(); method_41843();
            }));
        }
        method_37063(new SettingsButton(left,field_22790-28,60,() -> class_2561.method_43471("gui.back"),this::method_25419));
        method_37063(new SettingsButton(left+contentWidth-60,field_22790-28,60,() -> class_2561.method_43471("craftaria_utils.custom_commands.new"),() -> { resetDraft(); method_41843(); }));
        var previous=method_37063(new SettingsButton(field_22789/2-84,field_22790-28,28,() -> class_2561.method_43470("<"),() -> { page--; method_41843(); }));
        var next=method_37063(new SettingsButton(field_22789/2+56,field_22790-28,28,() -> class_2561.method_43470(">"),() -> { page++; method_41843(); }));
        previous.field_22763=page>0; next.field_22763=page+1<pageCount; previous.field_22764=next.field_22764=pageCount>1;
        method_48265(commandField);
    }
    private void edit(CustomCommand home) { commandDraft=home.name; labelDraft=home.label(); icon=home.icon; editing=home.name; status=null; method_41843(); }
    private void resetDraft() { commandDraft=""; labelDraft=""; icon="minecraft:command_block"; editing=null; status=null; }
    private void saveCommand() {
        String name=CustomCommand.normalize(commandDraft);
        String label=labelDraft.strip();
        if (!CustomCommand.validName(name)) { status="invalid"; return; }
        List<CustomCommand> homes=ModConfig.get().customCommands;
        if (homes.stream().anyMatch(home -> home.name.equalsIgnoreCase(name) && (editing==null || !home.name.equalsIgnoreCase(editing)))) {
            status="duplicate"; return;
        }
        CustomCommand target=editing==null?null:homes.stream().filter(home -> home.name.equals(editing)).findFirst().orElse(null);
        if (target==null) { homes.add(new CustomCommand(name,label,icon)); page=(homes.size()-1)/pageSize; }
        else { target.name=name; target.displayName=label; target.icon=icon; }
        ModConfig.save(); resetDraft(); status="saved"; method_41843();
    }
    @Override public boolean method_25401(double x,double y,double horizontal,double vertical) {
        if (y>=122 && y<field_22790-36 && vertical!=0) { page+=vertical>0?-1:1; method_41843(); return true; }
        return super.method_25401(x,y,horizontal,vertical);
    }
    @Override public void method_25420(class_332 c,int x,int y,float delta) { }
    @Override public void method_25394(class_332 c,int x,int y,float delta) {
        WallpaperManager.draw(c,field_22789,field_22790); c.method_25294(0,0,field_22789,field_22790,0xBF0A1017);
        MenuTextButton.drawLabel(c,field_22785,left,13,1.35f,false,true);
        c.method_25303(field_22793,field_22793.method_27523(class_2561.method_43471("craftaria_utils.custom_commands.description").getString(),contentWidth),left,35,0xFFC5C1B8);
        String hint=status==null?"hint":status;
        c.method_25303(field_22793,field_22793.method_27523(class_2561.method_43471("craftaria_utils.custom_commands."+hint).getString(),contentWidth),left,94,
                "invalid".equals(status)||"duplicate".equals(status)?0xFFFF8888:0xFFCFAD6D);
        c.method_27535(field_22793,class_2561.method_43469("craftaria_utils.custom_commands.list",ModConfig.get().customCommands.size()),left,115,0xFFB8B4AA);
        if (ModConfig.get().customCommands.isEmpty()) c.method_27535(field_22793,class_2561.method_43471("craftaria_utils.custom_commands.empty"),left,139,0xFF99968F);
        c.method_27534(field_22793,class_2561.method_43470((page+1)+" / "+pageCount),field_22789/2,field_22790-21,0xFFF0E9DA);
        save.field_22763=CustomCommand.validName(commandDraft.strip());
        super.method_25394(c,x,y,delta);
    }
    @Override public void method_25419() { field_22787.method_1507(parent); }
}
