package fr.craftaria.utils.chat;

import fr.craftaria.utils.config.ModConfig;
import fr.craftaria.utils.config.QuickHome;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import net.minecraft.class_1802;
import net.minecraft.class_2561;

public final class ChatCustomMenu extends ChatActionMenu {
    public ChatCustomMenu(Consumer<String> action) {
        super(236,112,class_2561.method_43471("craftaria_utils.custom_commands.button"),class_1802.field_8866,ChatCustomMenu::entries,action);
    }
    private static List<Action> entries() {
        List<Action> entries=new ArrayList<>();
        for (var command:ModConfig.get().customCommands)
            entries.add(new Action("custom:run:"+command.name,class_2561.method_43470(command.label()),QuickHome.iconStack(command.icon),
                    class_2561.method_43470("/"+command.name),"/"+command.name));
        entries.add(new Action("custom:add",class_2561.method_43471("craftaria_utils.custom_commands.add"),class_1802.field_8674.method_7854(),
                class_2561.method_43471("craftaria_utils.custom_commands.description"),"+"));
        return entries;
    }
}
