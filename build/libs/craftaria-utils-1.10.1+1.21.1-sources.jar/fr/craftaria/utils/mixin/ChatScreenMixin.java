package fr.craftaria.utils.mixin;

import fr.craftaria.utils.chat.ChatShareMenu;
import fr.craftaria.utils.chat.ChatTeleportMenu;
import fr.craftaria.utils.chat.ChatGeneralMenu;
import fr.craftaria.utils.CraftariaUtilsClient;
import fr.craftaria.utils.screen.TeleportPlayersScreen;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_408;
import net.minecraft.class_437;
import net.minecraft.class_4717;
import fr.craftaria.utils.screen.QuickHomesScreen;
import fr.craftaria.utils.config.ModConfig;
import fr.craftaria.utils.config.QuickHome;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_408.class)
public abstract class ChatScreenMixin extends class_437 {
    @Shadow protected class_342 chatField;
    @Shadow protected String originalChatText;
    @Shadow private class_4717 chatInputSuggestor;
    @Unique private ChatShareMenu craftariaUtils$shareMenu;
    @Unique private ChatTeleportMenu craftariaUtils$teleportMenu;
    @Unique private ChatGeneralMenu craftariaUtils$generalMenu;

    protected ChatScreenMixin(class_2561 title) { super(title); }

    @Unique private boolean craftariaUtils$hideButtons() {
        return (chatInputSuggestor != null && chatInputSuggestor.method_53867())
                || (chatField != null && !chatField.method_1882().isBlank());
    }

    @Inject(method = "init", at = @At("TAIL"))
    private void craftariaUtils$initShareMenu(CallbackInfo ci) {
        craftariaUtils$shareMenu = new ChatShareMenu(token -> {
            int cursor = chatField.method_1881();
            String draft = chatField.method_1882();
            String prefix = cursor > 0 && !Character.isWhitespace(draft.charAt(cursor-1)) ? " " : "";
            String insertion = prefix+token;
            int available = 256-(draft.length()-chatField.method_1866().length());
            if (insertion.length()>available) {
                field_22787.field_1705.method_1758(class_2561.method_43471("craftaria_utils.chat.full"), false);
                return;
            }
            chatField.method_1867(insertion+(available>insertion.length() ? " " : ""));
            originalChatText = chatField.method_1882();
            method_25395(chatField);
            chatField.method_25365(true);
        });
        craftariaUtils$shareMenu.layout(field_22789, chatField.method_46427());
        craftariaUtils$teleportMenu = new ChatTeleportMenu(command -> {
            craftariaUtils$shareMenu.close();
            originalChatText = chatField.method_1882();
            if (command.equals("quick:add") || command.startsWith("quick:edit:")) {
                QuickHome selected = command.startsWith("quick:edit:") ? ModConfig.get().quickHomes.stream()
                        .filter(home -> home.name.equals(command.substring("quick:edit:".length()))).findFirst().orElse(null) : null;
                field_22787.method_1507(new QuickHomesScreen((class_437)(Object)this));
                if (selected != null) ((QuickHomesScreen)field_22787.field_1755).editHome(selected);
            } else if (command.equals("tpa") || command.equals("tpahere")) {
                field_22787.method_1507(new TeleportPlayersScreen((class_437)(Object)this,
                        command.equals("tpa") ? TeleportPlayersScreen.Mode.TPA : TeleportPlayersScreen.Mode.TPAHERE));
            } else {
                CraftariaUtilsClient.sendCommand(field_22787, command);
                field_22787.method_1507(null);
            }
        });
        craftariaUtils$teleportMenu.layout(field_22789, chatField.method_46427());
        craftariaUtils$generalMenu = new ChatGeneralMenu(command -> {
            craftariaUtils$shareMenu.close();
            craftariaUtils$teleportMenu.close();
            originalChatText = chatField.method_1882();
            CraftariaUtilsClient.sendCommand(field_22787, command);
            field_22787.method_1507(null);
        });
        craftariaUtils$generalMenu.layout(field_22789, chatField.method_46427());
    }

    @Inject(method = "render", at = @At("TAIL"))
    private void craftariaUtils$renderShareMenu(class_332 context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        if (craftariaUtils$hideButtons()) {
            craftariaUtils$shareMenu.close();
            craftariaUtils$teleportMenu.close();
            craftariaUtils$generalMenu.close();
            return;
        }
        context.method_51452();
        context.method_51448().method_22903();
        context.method_51448().method_46416(0, 0, 1000);
        try {
        if (craftariaUtils$shareMenu != null) {
            craftariaUtils$shareMenu.layout(field_22789, chatField.method_46427());
            craftariaUtils$shareMenu.render(context, mouseX, mouseY);
        }
        if (craftariaUtils$teleportMenu != null) {
            craftariaUtils$teleportMenu.layout(field_22789, chatField.method_46427());
            craftariaUtils$teleportMenu.render(context, mouseX, mouseY);
        }
        if (craftariaUtils$generalMenu != null) {
            craftariaUtils$generalMenu.layout(field_22789, chatField.method_46427());
            craftariaUtils$generalMenu.render(context, mouseX, mouseY);
        }
        } finally {
            context.method_51452();
            context.method_51448().method_22909();
        }
    }

    @Inject(method = "mouseClicked", at = @At("HEAD"), cancellable = true)
    private void craftariaUtils$clickShareMenu(double mouseX, double mouseY, int button, CallbackInfoReturnable<Boolean> cir) {
        // Leave clicks on Minecraft's completion window entirely to the vanilla suggestor.
        if (craftariaUtils$hideButtons()) return;
        if (craftariaUtils$generalMenu != null && craftariaUtils$generalMenu.mouseClicked(mouseX, mouseY, button)) {
            if (craftariaUtils$shareMenu != null) craftariaUtils$shareMenu.close();
            if (craftariaUtils$teleportMenu != null) craftariaUtils$teleportMenu.close();
            cir.setReturnValue(true);
            return;
        }
        if (craftariaUtils$teleportMenu != null && craftariaUtils$teleportMenu.mouseClicked(mouseX, mouseY, button)) {
            if (craftariaUtils$generalMenu != null) craftariaUtils$generalMenu.close();
            if (craftariaUtils$shareMenu != null) craftariaUtils$shareMenu.close();
            cir.setReturnValue(true);
            return;
        }
        if (craftariaUtils$shareMenu != null && craftariaUtils$shareMenu.mouseClicked(mouseX, mouseY, button)) {
            if (craftariaUtils$generalMenu != null) craftariaUtils$generalMenu.close();
            if (craftariaUtils$teleportMenu != null) craftariaUtils$teleportMenu.close();
            cir.setReturnValue(true);
        }
    }

    @Inject(method = "keyPressed", at = @At("HEAD"), cancellable = true)
    private void craftariaUtils$closeShareMenu(int keyCode, int scanCode, int modifiers, CallbackInfoReturnable<Boolean> cir) {
        boolean menuOpen = (craftariaUtils$shareMenu != null && craftariaUtils$shareMenu.isOpen())
                || (craftariaUtils$teleportMenu != null && craftariaUtils$teleportMenu.isOpen())
                || (craftariaUtils$generalMenu != null && craftariaUtils$generalMenu.isOpen());
        if (menuOpen && keyCode==GLFW.GLFW_KEY_ESCAPE) {
            if (craftariaUtils$shareMenu != null) craftariaUtils$shareMenu.close();
            if (craftariaUtils$teleportMenu != null) craftariaUtils$teleportMenu.close();
            if (craftariaUtils$generalMenu != null) craftariaUtils$generalMenu.close();
            cir.setReturnValue(true);
        }
    }

    @Inject(method = "mouseScrolled", at = @At("HEAD"), cancellable = true)
    private void craftariaUtils$shareMenuScroll(double mouseX, double mouseY, double horizontal, double vertical,
                                              CallbackInfoReturnable<Boolean> cir) {
        if (craftariaUtils$hideButtons()) return;
        if ((craftariaUtils$generalMenu != null && craftariaUtils$generalMenu.mouseScrolled(mouseX, mouseY, vertical))
                || (craftariaUtils$teleportMenu != null && craftariaUtils$teleportMenu.mouseScrolled(mouseX, mouseY, vertical))) {
            cir.setReturnValue(true);
            return;
        }
        if ((craftariaUtils$shareMenu != null && craftariaUtils$shareMenu.covers(mouseX, mouseY))
                || (craftariaUtils$teleportMenu != null && craftariaUtils$teleportMenu.covers(mouseX, mouseY))) cir.setReturnValue(true);
    }
}
