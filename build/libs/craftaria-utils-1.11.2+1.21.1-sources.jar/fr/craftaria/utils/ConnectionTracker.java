package fr.craftaria.utils;

import fr.craftaria.utils.config.ModConfig;
import java.util.Locale;
import java.util.Set;
import java.util.stream.Collectors;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3417;
import net.minecraft.class_640;
import net.minecraft.class_7532;

/** Detects new UUIDs in the server player list after the initial roster has loaded. */
public final class ConnectionTracker {
    private static String playerName;
    private static long expiresAt;
    private static boolean preview;
    private static net.minecraft.class_634 connection;
    private static final ConnectionRoster roster = new ConnectionRoster();
    private static final java.util.ArrayDeque<String> pending = new java.util.ArrayDeque<>();

    private ConnectionTracker() { }

    public static void tick(class_310 client) {
        var network = client.method_1562();
        if (client.field_1724 == null || network == null) {
            connection=null; roster.reset(); pending.clear(); playerName=null; return;
        }
        if (network != connection) {
            connection=network; pending.clear(); playerName=null;
        }
        var current = network.method_2880().stream()
                .filter(entry -> !entry.method_2966().getId().equals(client.field_1724.method_5667()))
                .collect(Collectors.toMap(entry -> entry.method_2966().getId(),entry -> entry.method_2966().getName(),(a,b)->a));
        Set<String> tracked = TrackedPlayers.parse(ModConfig.get().trackedPlayers).stream()
                .map(name -> name.toLowerCase(Locale.ROOT)).collect(Collectors.toSet());
        for(String name:roster.update(network,current,tracked,ModConfig.get().connectionTrackerEnabled)) {
            if(pending.size()<20) pending.addLast(name);
        }
        if (!ModConfig.get().connectionTrackerEnabled) { pending.clear(); if(!preview) playerName=null; return; }
        if (client.field_1755 == null && (playerName == null || System.currentTimeMillis()>=expiresAt) && !pending.isEmpty()) {
            show(client,pending.removeFirst(),false);
        }
    }

    private static void show(class_310 client,String name,boolean isPreview) {
        playerName=name; preview=isPreview; expiresAt=System.currentTimeMillis()+5500;
        TrackedPlayerSkins.request(name);
        client.method_1483().method_4873(net.minecraft.class_1109.method_4757(class_3417.field_14627,1f,1f));
    }

    public static void preview(class_310 client) {
        if(client.field_1724==null) return;
        var tracked=TrackedPlayers.parse(ModConfig.get().trackedPlayers);
        show(client,tracked.isEmpty()?client.field_1724.method_7334().getName():tracked.getFirst(),true);
        client.method_1507(null);
    }

    public static boolean isOnline(class_310 client,String name) {
        return client.method_1562()!=null && client.method_1562().method_2880().stream()
                .anyMatch(entry->entry.method_2966().getName().equalsIgnoreCase(name));
    }

    public static void render(class_332 context, class_310 client) {
        if (playerName == null) return;
        if (System.currentTimeMillis() >= expiresAt || client.field_1724 == null) { playerName = null; return; }
        if (client.field_1755 != null) return;

        context.method_51452();
        context.method_51448().method_22903();
        context.method_51448().method_46416(0,0,800);
        int width = 230, height = 48;
        int x = (context.method_51421() - width) / 2;
        // Sit below the server's boss bars and announcements, leaving the crosshair unobstructed.
        int y = 52;
        context.method_25294(x, y, x+width, y+height, 0xE6101720);
        context.method_25294(x, y, x+width, y+2, 0xFFFFD383);
        context.method_25294(x, y+height-1, x+width, y+height, 0xFF756B57);
        context.method_25294(x, y+2, x+1, y+height-1, 0xFF756B57);
        context.method_25294(x+width-1, y+2, x+width, y+height-1, 0xFF756B57);
        class_640 entry = client.method_1562() == null ? null : client.method_1562().method_2874(playerName);
        if (entry != null) class_7532.method_52722(context, entry.method_52810(), x+8, y+8, 32);
        else if (TrackedPlayerSkins.get(playerName)!=null) class_7532.method_52722(context,TrackedPlayerSkins.get(playerName),x+8,y+8,32);
        else context.method_51427(class_1802.field_8575.method_7854(), x+12, y+12);

        context.method_27535(client.field_1772, class_2561.method_43470(playerName), x+49, y+10, 0xFFFFD383);
        context.method_27535(client.field_1772, class_2561.method_43471(preview?"craftaria_utils.tracker.preview_message":"craftaria_utils.tracker.joined"), x+49, y+26, 0xFFF0E9DA);
        int remaining = (int)Math.clamp((expiresAt-System.currentTimeMillis())*100/5500, 0, 100);
        context.method_25294(x+49, y+40, x+width-9, y+42, 0xFF45454B);
        context.method_25294(x+49, y+40, x+49+(width-58)*remaining/100, y+42, 0xFFFFD383);
        context.method_51452();
        context.method_51448().method_22909();
    }
}
