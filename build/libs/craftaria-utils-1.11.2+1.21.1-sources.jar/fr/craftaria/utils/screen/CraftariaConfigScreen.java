package fr.craftaria.utils.screen;

import fr.craftaria.utils.CraftariaUtilsClient;
import fr.craftaria.utils.TrackedPlayerSkins;
import fr.craftaria.utils.config.ModConfig;
import fr.craftaria.utils.wallpaper.WallpaperManager;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_3675;
import net.minecraft.class_437;
import net.minecraft.class_458;
import net.minecraft.class_7532;
import fr.craftaria.utils.screen.GuiTextures;
import org.lwjgl.glfw.GLFW;

public final class CraftariaConfigScreen extends CraftariaScreen {
    private static final class_2960 LOGO = class_2960.method_60655("craftaria_utils", "icon-transparent.png");
    private enum Page { REPAIR, LOGIN, COOKING, KEYS, TRACKER, ANTIDROP }
    private final class_437 parent;
    private Page page = Page.REPAIR;
    private class_304 capturing;
    private class_342 passwordField;
    private class_342 trackedPlayerField;
    private SettingsButton addTrackedPlayerButton;
    private String trackedPlayerDraft="";
    private int trackedListY,trackedPage,trackedPageSize=1;
    private int antiDropPage,antiDropPageCount=1;
    private int left, top, contentX, contentWidth, bodyY;

    public CraftariaConfigScreen(class_437 parent) { super(class_2561.method_43471("craftaria_utils.title")); this.parent = parent; }

    @Override protected void method_25426() {
        capturing = null;
        passwordField = null;
        trackedPlayerField = null;
        addTrackedPlayerButton = null;
        int totalWidth = Math.min(620, field_22789-28);
        left = (field_22789-totalWidth)/2;
        top = Math.max(12, (field_22790-280)/2);
        int sidebarWidth = field_22789 < 400 ? 92 : 128;
        contentX = left+sidebarWidth+20;
        contentWidth = totalWidth-sidebarWidth-20;
        bodyY = top+44;

        Page[] pages = Page.values();
        int sidebarSpacing = Math.min(27, Math.max(16, (field_22790-43-(bodyY+8)-22)/(pages.length+2)));
        for (int i=0; i<pages.length; i++) {
            Page tab = pages[i];
            method_37063(new MenuTextButton(left+8, bodyY+8+i*sidebarSpacing, sidebarWidth-10, 22,
                    class_2561.method_43471(pageKey(tab)), 1f, () -> { savePassword(); page=tab; method_41843(); }));
        }
        method_37063(new MenuTextButton(left+8, bodyY+8+pages.length*sidebarSpacing, sidebarWidth-10, 22,
                class_2561.method_43471("craftaria_utils.settings.wallpaper"), 1f, () -> {
            savePassword(); field_22787.method_1507(new WallpaperGalleryScreen(this));
        }));
        method_37063(new MenuTextButton(left+8, bodyY+8+(pages.length+1)*sidebarSpacing, sidebarWidth-10, 22,
                class_2561.method_43471("craftaria_utils.quick_homes.tab"), 1f, () -> {
            savePassword(); field_22787.method_1507(new QuickHomesScreen(this));
        }));
        method_37063(new MenuTextButton(left+8, field_22790-27, 100, 20, class_2561.method_43471("gui.back"), 1f, this::method_25419));
        method_37063(new MenuTextButton(field_22789-115, field_22790-27, 104, 20,
                class_2561.method_43471("craftaria_utils.settings.controls"), .85f, () -> {
                    savePassword(); field_22787.method_1507(new class_458(this, field_22787.field_1690));
                }));

        int y = bodyY+45;
        switch (page) {
            case REPAIR -> {
                method_37063(new SettingsButton(contentX, y, contentWidth, () -> class_2561.method_43469("craftaria_utils.repair",
                        class_2561.method_43471(ModConfig.get().autoRepair ? "options.on" : "options.off")), () -> {
                    ModConfig.get().autoRepair = !ModConfig.get().autoRepair;
                    ModConfig.save();
                }));
                method_37063(new RepairThresholdSlider(contentX, y+38, contentWidth));
            }
            case LOGIN -> {
                passwordField = new class_342(field_22793, contentX+1, y+13, contentWidth-2, 22,
                        class_2561.method_43471("craftaria_utils.login.password"));
                passwordField.method_1880(128);
                passwordField.method_1852(ModConfig.get().password);
                passwordField.method_1868(0xFFF0E9DA);
                passwordField.method_1858(false);
                passwordField.method_1854((value, cursor) -> class_2561.method_43470("•".repeat(value.length())).method_30937());
                passwordField.method_1863(value -> { ModConfig.get().password=value; ModConfig.save(); });
                method_37063(passwordField);
                addBindingRow(CraftariaUtilsClient.loginKey, "craftaria_utils.settings.login_key", y+52);
            }
            case COOKING -> {
                method_37063(new CookingDelaySlider(contentX, y, contentWidth));
                addBindingRow(CraftariaUtilsClient.cookingKey, "craftaria_utils.settings.cooking_key", y+35);
                method_37063(new SettingsButton(contentX, y+70, contentWidth,
                        () -> class_2561.method_43471("craftaria_utils.open_cooking"), () -> {
                    if (field_22787.field_1724 != null) { savePassword(); field_22787.method_1507(new CookingScreen(this)); }
                }));
            }
            case KEYS -> {
                addBindingRow(CraftariaUtilsClient.fourKey, "craftaria_utils.settings.four_key", y);
                addBindingRow(CraftariaUtilsClient.loginKey, "craftaria_utils.settings.login_key", y+29);
                addBindingRow(CraftariaUtilsClient.cookingKey, "craftaria_utils.settings.cooking_key", y+58);
            }
            case ANTIDROP -> {
                method_37063(new SettingsButton(contentX,y,contentWidth,
                        ()->class_2561.method_43469("craftaria_utils.antidrop.toggle",class_2561.method_43471(ModConfig.get().antiDropEnabled?"options.on":"options.off")),()->{
                    ModConfig.get().antiDropEnabled=!ModConfig.get().antiDropEnabled; ModConfig.save();
                }));
                var select=method_37063(new SettingsButton(contentX,y+36,contentWidth,
                        ()->class_2561.method_43471("craftaria_utils.antidrop.select"),()->field_22787.method_1507(new AntiDropScreen(this))));
                select.field_22763=field_22787.field_1724!=null;
                var protectedItems=ModConfig.get().protectedItems;
                int columns=Math.max(1,contentWidth/28);
                int rows=Math.max(1,(field_22790-54-(y+100))/28);
                int pageSize=columns*rows;
                antiDropPageCount=Math.max(1,(protectedItems.size()+pageSize-1)/pageSize);
                antiDropPage=Math.clamp(antiDropPage,0,antiDropPageCount-1);
                for(int i=0;i<pageSize && antiDropPage*pageSize+i<protectedItems.size();i++) {
                    String id=protectedItems.get(antiDropPage*pageSize+i);
                    var item=fr.craftaria.utils.config.QuickHome.iconStack(id);
                    method_37063(new ItemIconButton(contentX+(i%columns)*28,y+100+(i/columns)*28,item,true,
                            item.method_7964().method_27661().method_27693("\n").method_10852(class_2561.method_43471("craftaria_utils.antidrop.remove_hint")),()->{
                        ModConfig.get().protectedItems.remove(id); ModConfig.save(); method_41843();
                    }));
                }
                if(antiDropPageCount>1) {
                    var prev=method_37063(new SettingsButton(contentX+contentWidth-80,y+70,32,()->class_2561.method_43470("<"),()->{antiDropPage--;method_41843();}));
                    var next=method_37063(new SettingsButton(contentX+contentWidth-36,y+70,32,()->class_2561.method_43470(">"),()->{antiDropPage++;method_41843();}));
                    prev.field_22763=antiDropPage>0; next.field_22763=antiDropPage+1<antiDropPageCount;
                }
            }
            case TRACKER -> {
                method_37063(new SettingsButton(contentX, y, contentWidth-98,
                        () -> class_2561.method_43469("craftaria_utils.tracker.toggle",
                                class_2561.method_43471(ModConfig.get().connectionTrackerEnabled ? "options.on" : "options.off")), () -> {
                    ModConfig.get().connectionTrackerEnabled = !ModConfig.get().connectionTrackerEnabled;
                    ModConfig.save();
                }));
                var test=method_37063(new SettingsButton(contentX+contentWidth-92,y,92,
                        ()->class_2561.method_43471("craftaria_utils.tracker.test"),()->fr.craftaria.utils.ConnectionTracker.preview(field_22787)));
                test.field_22763=field_22787.field_1724!=null;
                trackedPlayerField = new class_342(field_22793, contentX+1, y+48, contentWidth-94, 22,
                        class_2561.method_43471("craftaria_utils.tracker.player_name"));
                trackedPlayerField.method_47404(class_2561.method_43471("craftaria_utils.tracker.player_hint"));
                trackedPlayerField.method_1880(16);
                trackedPlayerField.method_1852(trackedPlayerDraft);
                trackedPlayerField.method_1863(value -> trackedPlayerDraft=value);
                method_37063(trackedPlayerField);
                addTrackedPlayerButton=method_37063(new SettingsButton(contentX+contentWidth-88,y+48,88,
                        () -> class_2561.method_43471("craftaria_utils.tracker.add"),this::confirmTrackedPlayer));

                var tracked=parseTrackedPlayers();
                trackedPageSize=Math.max(1,(field_22790-(y+112)-45)/29);
                int pageCount=Math.max(1,(tracked.size()+trackedPageSize-1)/trackedPageSize);
                trackedPage=Math.clamp(trackedPage,0,pageCount-1);
                trackedListY=y+112;
                for(int i=0;i<trackedPageSize && trackedPage*trackedPageSize+i<tracked.size();i++) {
                    String name=tracked.get(trackedPage*trackedPageSize+i);
                    TrackedPlayerSkins.request(name);
                    int rowY=trackedListY+i*29;
                    method_37063(new SettingsButton(contentX+28,rowY,contentWidth-84,
                            () -> class_2561.method_43470(name+" · ").method_10852(class_2561.method_43471(fr.craftaria.utils.ConnectionTracker.isOnline(field_22787,name)?"craftaria_utils.tracker.online":"craftaria_utils.tracker.offline")),() -> { trackedPlayerDraft=name; trackedPageFieldSync(); }));
                    method_37063(new SettingsButton(contentX+contentWidth-52,rowY,52,
                            () -> class_2561.method_43471("craftaria_utils.tracker.remove"),() -> removeTrackedPlayer(name)));
                }
                if(pageCount>1) {
                    var prev=method_37063(new SettingsButton(contentX, field_22790-58, 42,
                            () -> class_2561.method_43470("‹"),() -> { trackedPage--; method_41843(); }));
                    var next=method_37063(new SettingsButton(contentX+contentWidth-42,field_22790-58,42,
                            () -> class_2561.method_43470("›"),() -> { trackedPage++; method_41843(); }));
                    prev.field_22763=trackedPage>0; next.field_22763=trackedPage+1<pageCount;
                }
            }
        }
    }

    private static String pageKey(Page page) { return "craftaria_utils.settings."+page.name().toLowerCase(java.util.Locale.ROOT); }

    private void addBindingRow(class_304 binding, String label, int y) {
        int keyWidth = Math.min(115, contentWidth/2);
        method_37063(new SettingsButton(contentX+contentWidth-keyWidth, y, keyWidth, () -> {
            if (capturing == binding) return class_2561.method_43471("craftaria_utils.settings.press_key");
            class_2561 key = binding.method_16007();
            return hasConflict(binding) ? class_2561.method_43469("craftaria_utils.settings.conflict_key", key) : key;
        }, () -> { capturing=binding; method_25395(null); }));
    }

    private boolean hasConflict(class_304 binding) {
        if (binding.method_1415()) return false;
        for (class_304 other : field_22787.field_1690.field_1839) if (other != binding && binding.method_1435(other)) return true;
        return false;
    }

    private void bind(class_3675.class_306 key) {
        capturing.method_1422(key);
        class_304.method_1426();
        class_304.method_1437();
        field_22787.field_1690.method_1640();
        capturing = null;
    }

    @Override public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        if (capturing != null) {
            bind(keyCode==GLFW.GLFW_KEY_ESCAPE ? class_3675.field_16237 : class_3675.method_15985(keyCode, scanCode));
            return true;
        }
        return super.method_25404(keyCode, scanCode, modifiers);
    }

    @Override public boolean method_25402(double mouseX, double mouseY, int button) {
        if (capturing != null) {
            bind(class_3675.class_307.field_1672.method_1447(button));
            return true;
        }
        return super.method_25402(mouseX, mouseY, button);
    }

    private void savePassword() {
        if (passwordField != null) ModConfig.get().password=passwordField.method_1882();
        ModConfig.save();
    }
    @Override public void method_25419() { savePassword(); field_22787.method_1507(parent); }
    @Override public void method_25432() { savePassword(); }

    @Override public void method_25420(class_332 context, int mouseX, int mouseY, float delta) { }

    @Override public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        WallpaperManager.draw(context, field_22789, field_22790);
        context.method_25294(0, 0, field_22789, field_22790, 0xAB0A1017);
        GuiTextures.draw(context, LOGO, left, top-1, 0, 0, 36, 36, 1254, 1254, 1254, 1254);
        MenuTextButton.drawLabel(context, field_22785, left+46, top+3, 1.5f, false, true);
        context.method_27535(field_22793, class_2561.method_43471("craftaria_utils.settings.subtitle"), left+46, top+23, 0xFFB8B4AA);
        context.method_25294(contentX-11, bodyY, contentX-10, field_22790-43, 0x606E6554);
        context.method_27535(field_22793, class_2561.method_43471(pageKey(page)), contentX, bodyY+3, 0xFFFFD383);
        context.method_51440(field_22793, class_2561.method_43471(pageKey(page)+".description"),
                contentX, bodyY+20, contentWidth, 0xFFC5C1B8);
        int y=bodyY+45;
        if (page==Page.LOGIN) {
            context.method_27535(field_22793, class_2561.method_43471("craftaria_utils.login.password"), contentX, y, 0xFFF0E9DA);
            context.method_25294(contentX, y+12, contentX+contentWidth, y+36, 0x50101720);
            context.method_25294(contentX, y+35, contentX+contentWidth, y+36, 0x806E6554);
            bindingLabel(context, "craftaria_utils.settings.login_key", y+52);
            if (y+103 < field_22790-46) context.method_51440(field_22793, class_2561.method_43471("craftaria_utils.password_storage"), contentX, y+83, contentWidth, 0xFF99968F);
        } else if (page==Page.COOKING) bindingLabel(context, "craftaria_utils.settings.cooking_key", y+35);
        else if (page==Page.KEYS) {
            bindingLabel(context, "craftaria_utils.settings.four_key", y);
            bindingLabel(context, "craftaria_utils.settings.login_key", y+29);
            bindingLabel(context, "craftaria_utils.settings.cooking_key", y+58);
        } else if (page==Page.REPAIR) {
            context.method_51440(field_22793, class_2561.method_43471("craftaria_utils.settings.repair.note"), contentX, y+70, contentWidth, 0xFF99968F);
        } else if (page==Page.ANTIDROP) {
            String label=class_2561.method_43469("craftaria_utils.antidrop.list",ModConfig.get().protectedItems.size()).getString();
            context.method_25303(field_22793,field_22793.method_27523(label,contentWidth-(antiDropPageCount>1?90:0)),contentX,y+78,0xFFFFD383);
            if(ModConfig.get().protectedItems.isEmpty()) context.method_51440(field_22793,
                    class_2561.method_43471("craftaria_utils.antidrop.empty"),contentX,y+108,contentWidth,0xFFB8B4AA);
        } else if (page==Page.TRACKER) {
            context.method_27535(field_22793, class_2561.method_43471("craftaria_utils.tracker.player_name"), contentX, y+34, 0xFFF0E9DA);
            context.method_25294(contentX, y+47, contentX+contentWidth, y+71, 0x50101720);
            context.method_25294(contentX, y+70, contentX+contentWidth, y+71, 0x806E6554);
            context.method_27535(field_22793,class_2561.method_43469("craftaria_utils.tracker.players",parseTrackedPlayers().size()),contentX, y+91,0xFFFFD383);
            var tracked=parseTrackedPlayers();
            for(int i=0;i<trackedPageSize && trackedPage*trackedPageSize+i<tracked.size();i++) {
                String name=tracked.get(trackedPage*trackedPageSize+i);
                var skin=TrackedPlayerSkins.get(name);
                if(skin!=null) class_7532.method_52722(context,skin,contentX+5,trackedListY+i*29+2,22);
                else context.method_51427(net.minecraft.class_1802.field_8575.method_7854(),contentX+8,trackedListY+i*29+4);
            }
            if(addTrackedPlayerButton!=null) addTrackedPlayerButton.field_22763=validPlayerName(trackedPlayerDraft)
                    && tracked.stream().noneMatch(name->name.equalsIgnoreCase(trackedPlayerDraft));
        }
        if (capturing != null) context.method_27534(field_22793,
                class_2561.method_43471("craftaria_utils.settings.capture_hint"), field_22789/2, field_22790-41, 0xFFFFD383);
        else context.method_27534(field_22793, class_2561.method_43471("craftaria_utils.settings.saved"), field_22789/2, field_22790-41, 0xFF99968F);
        super.method_25394(context, mouseX, mouseY, delta);
    }

    private void bindingLabel(class_332 context, String key, int y) {
        int maxWidth=contentWidth-Math.min(115, contentWidth/2)-7;
        context.method_27535(field_22793, class_2561.method_43470(field_22793.method_27523(class_2561.method_43471(key).getString(), maxWidth)), contentX, y+7, 0xFFF0E9DA);
    }

    private static boolean validPlayerName(String name) { return name!=null && name.matches("[A-Za-z0-9_]{3,16}"); }
    private static java.util.List<String> parseTrackedPlayers() {
        return fr.craftaria.utils.TrackedPlayers.parse(ModConfig.get().trackedPlayers);
    }
    private void confirmTrackedPlayer() {
        String name=trackedPlayerDraft.strip();
        if(!validPlayerName(name) || parseTrackedPlayers().stream().anyMatch(existing->existing.equalsIgnoreCase(name))) return;
        field_22787.method_1507(new TrackedPlayerConfirmScreen(this,name,()->addTrackedPlayer(name)));
    }
    private void addTrackedPlayer(String name) {
        var players=new java.util.ArrayList<>(parseTrackedPlayers()); players.add(name);
        ModConfig.get().trackedPlayers=String.join(", ",players);
        ModConfig.get().connectionTrackerEnabled=true; ModConfig.save();
        trackedPlayerDraft=""; trackedPage=Math.max(0,(players.size()-1)/trackedPageSize);
    }
    private void removeTrackedPlayer(String name) {
        var players=new java.util.ArrayList<>(parseTrackedPlayers());
        players.removeIf(existing->existing.equalsIgnoreCase(name));
        ModConfig.get().trackedPlayers=String.join(", ",players); ModConfig.save();
        trackedPage=Math.min(trackedPage,Math.max(0,(players.size()-1)/trackedPageSize)); method_41843();
    }
    private void trackedPageFieldSync() { method_41843(); }

    @Override public boolean method_25401(double mouseX,double mouseY,double horizontal,double vertical) {
        if(page==Page.TRACKER && mouseY>=trackedListY && mouseY<field_22790-62 && vertical!=0) {
            int pageCount=Math.max(1,(parseTrackedPlayers().size()+trackedPageSize-1)/trackedPageSize);
            trackedPage=Math.clamp(trackedPage+(vertical>0?-1:1),0,pageCount-1); method_41843(); return true;
        }
        return super.method_25401(mouseX,mouseY,horizontal,vertical);
    }
}
