package fr.craftaria.utils.config;

import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public final class QuickHome {
    /** The exact home argument sent to the server, for example "b". */
    public String name;
    /** Optional friendly label shown in Craftaria Utils, for example "Base". */
    public String displayName;
    public String icon = "minecraft:red_bed";
    public QuickHome() { }
    public QuickHome(String name, String displayName, String icon) { this.name=name; this.displayName=displayName; this.icon=icon; }
    public String label() { return displayName==null || displayName.isBlank() ? name : displayName; }
    public static boolean validName(String name) {
        return name!=null && !name.isBlank() && name.length()<=32
                && name.chars().noneMatch(c -> Character.isWhitespace(c) || Character.isISOControl(c) || c=='/' || c=='\\');
    }
    public static class_1799 iconStack(String icon) {
        class_2960 id = icon==null ? null : class_2960.method_12829(icon);
        var item = id==null ? null : class_7923.field_41178.method_10223(id);
        return item==null || item==class_1802.field_8162 ? class_1802.field_8789.method_7854() : item.method_7854();
    }
}
