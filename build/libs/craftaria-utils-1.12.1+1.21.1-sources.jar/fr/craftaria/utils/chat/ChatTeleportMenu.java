package fr.craftaria.utils.chat;

import fr.craftaria.utils.config.ModConfig;
import fr.craftaria.utils.config.QuickHome;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import net.minecraft.class_1802;
import net.minecraft.class_2561;

public final class ChatTeleportMenu extends ChatActionMenu {
    public ChatTeleportMenu(Consumer<String> action) {
        super(28,112,class_2561.method_43471("craftaria_utils.teleport.title"),class_1802.field_8634,ChatTeleportMenu::entries,action);
    }
    private static List<Action> entries() {
        List<Action> entries=new ArrayList<>(List.of(
                Action.command("tpa","craftaria_utils.teleport.tpa",class_1802.field_8575),
                Action.command("tpahere","craftaria_utils.teleport.tpahere",class_1802.field_8634)));
        for (QuickHome home:ModConfig.get().quickHomes) if (home!=null && QuickHome.validName(home.name))
            entries.add(new Action("home "+home.name,class_2561.method_43470(home.label()),QuickHome.iconStack(home.icon),
                    class_2561.method_43469("craftaria_utils.quick_homes.go",home.name),"/home "+home.name));
        for (QuickHome home:ModConfig.get().quickHomes) if (home!=null && QuickHome.validName(home.name))
            entries.add(new Action("quick:edit:"+home.name,class_2561.method_43469("craftaria_utils.quick_homes.edit",home.label()),
                    QuickHome.iconStack(home.icon),class_2561.method_43469("craftaria_utils.quick_homes.edit_description",home.name),"✎"));
        entries.addAll(List.of(
                Action.command("rtp","craftaria_utils.teleport.rtp",class_1802.field_8251),
                Action.command("warp","craftaria_utils.teleport.warp",class_1802.field_8449),
                Action.command("home","craftaria_utils.teleport.home",class_1802.field_8789),
                Action.command("spawn","craftaria_utils.teleport.spawn",class_1802.field_23141),
                Action.command("casino","craftaria_utils.teleport.casino",class_1802.field_8687),
                Action.command("crate","craftaria_utils.teleport.crate",class_1802.field_8106)));
        entries.add(new Action("quick:add",class_2561.method_43471("craftaria_utils.quick_homes.add"),class_1802.field_8448.method_7854(),
                class_2561.method_43471("craftaria_utils.quick_homes.description"),"+"));
        return entries;
    }
}
