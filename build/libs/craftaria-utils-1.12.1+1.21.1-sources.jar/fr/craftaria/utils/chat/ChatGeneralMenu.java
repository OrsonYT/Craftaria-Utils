package fr.craftaria.utils.chat;

import java.util.List;
import java.util.function.Consumer;
import net.minecraft.class_1802;
import net.minecraft.class_2561;

public final class ChatGeneralMenu extends ChatActionMenu {
    public ChatGeneralMenu(Consumer<String> action) {
        super(144,88,class_2561.method_43471("craftaria_utils.general.title"),class_1802.field_8137,ChatGeneralMenu::entries,action);
    }
    private static List<Action> entries() {
        return List.of(
                Action.command("shop","craftaria_utils.general.shop",class_1802.field_8106),
                Action.command("menu","craftaria_utils.general.menu",class_1802.field_8137),
                Action.command("ec","craftaria_utils.general.ec",class_1802.field_8466),
                Action.command("quete","craftaria_utils.general.quete",class_1802.field_8674),
                Action.command("skill","craftaria_utils.general.skill",class_1802.field_8287),
                Action.command("skill top","craftaria_utils.general.skill_top",class_1802.field_8862),
                Action.command("dex","craftaria_utils.general.dex",class_1802.field_8529),
                Action.command("profil","craftaria_utils.general.profil",class_1802.field_8575),
                Action.command("kit","craftaria_utils.general.kit",class_1802.field_27023),
                Action.command("stats","craftaria_utils.general.stats",class_1802.field_8407),
                Action.command("flytime","craftaria_utils.general.flytime",class_1802.field_8833),
                Action.command("wiki","craftaria_utils.general.wiki",class_1802.field_8361),
                Action.command("bossbar","craftaria_utils.general.bossbar",class_1802.field_8712),
                Action.command("sb","craftaria_utils.general.sb",class_1802.field_8788),
                Action.command("b","craftaria_utils.general.b",class_1802.field_8880));
    }
}
