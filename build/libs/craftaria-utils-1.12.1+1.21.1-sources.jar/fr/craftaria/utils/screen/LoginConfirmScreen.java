package fr.craftaria.utils.screen;

import fr.craftaria.utils.CraftariaUtilsClient;
import fr.craftaria.utils.config.ModConfig;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public final class LoginConfirmScreen extends CraftariaScreen {
    private final class_437 parent;
    public LoginConfirmScreen(class_437 parent) { super(class_2561.method_43471("craftaria_utils.login.title")); this.parent = parent; }
    @Override protected void method_25426() {
        method_37063(class_4185.method_46430(class_2561.method_43471("gui.yes"), b -> {
            CraftariaUtilsClient.sendCommand(class_310.method_1551(), "login " + ModConfig.get().password);
            class_310.method_1551().method_1507(parent);
        }).method_46434(field_22789 / 2 - 104, field_22790 / 2 + 12, 100, 20).method_46431());
        method_37063(class_4185.method_46430(class_2561.method_43471("gui.no"), b -> class_310.method_1551().method_1507(parent)).method_46434(field_22789 / 2 + 4, field_22790 / 2 + 12, 100, 20).method_46431());
    }
    @Override public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        method_25420(context, mouseX, mouseY, delta);
        context.method_27534(field_22793, class_2561.method_43471("craftaria_utils.login.confirm"), field_22789 / 2, field_22790 / 2 - 10, 0xFFFFFF);
        super.method_25394(context, mouseX, mouseY, delta);
    }
    @Override public void method_25419() { class_310.method_1551().method_1507(parent); }
}
