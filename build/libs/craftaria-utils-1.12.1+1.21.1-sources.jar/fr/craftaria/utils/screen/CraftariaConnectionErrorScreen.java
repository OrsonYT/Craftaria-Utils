package fr.craftaria.utils.screen;

import net.minecraft.class_2561;
import net.minecraft.class_332;

/** Keeps Minecraft's actual disconnect reason and offers an explicit retry. */
public final class CraftariaConnectionErrorScreen extends CraftariaScreen {
    private final CraftariaTitleScreen menu;
    private final class_2561 reason;

    public CraftariaConnectionErrorScreen(CraftariaTitleScreen menu, class_2561 reason) {
        super(class_2561.method_43471("craftaria_utils.connection.failed"));
        this.menu=menu;
        this.reason=reason;
    }

    @Override protected void method_25426() {
        float scale=Math.min(field_22789/960f,field_22790/540f);
        int left=Math.round(64*scale), buttonWidth=Math.max(160,Math.round(420*scale));
        int buttonY=Math.max(Math.round(325*scale),field_22790-90);
        method_37063(new MenuTextButton(left,buttonY,buttonWidth,26,
                class_2561.method_43471("craftaria_utils.connection.retry"),1.4f*scale,menu::retryConnection));
        method_37063(new MenuTextButton(left,buttonY+34,buttonWidth,26,
                class_2561.method_43471("craftaria_utils.connection.back"),1.4f*scale,this::method_25419));
    }

    @Override public void method_25420(class_332 context,int mouseX,int mouseY,float delta) { }

    @Override public void method_25394(class_332 context,int mouseX,int mouseY,float delta) {
        menu.renderScene(context,field_22789,field_22790);
        float scale=Math.min(field_22789/960f,field_22790/540f);
        int left=Math.round(64*scale), top=Math.round(185*scale);
        MenuTextButton.drawLabel(context,field_22785,left,top,2.3f*scale,false,true);
        int textWidth=Math.min(field_22789-left-16,Math.max(180,Math.round(560*scale)));
        int reasonY=top+Math.max(26,Math.round(40*scale));
        context.method_44379(left,reasonY,left+textWidth,Math.max(reasonY,field_22790-104));
        context.method_51440(field_22793,reason,left,reasonY,textWidth,0xFFE2D9C4);
        context.method_44380();
        super.method_25394(context,mouseX,mouseY,delta);
    }

    @Override public void method_25419() { field_22787.method_1507(menu); }
}
