package fr.craftaria.utils.screen;

import net.minecraft.class_2561;
import net.minecraft.class_437;

/** Shared screen base that avoids requesting the global menu blur more than once per frame. */
public abstract class CraftariaScreen extends class_437 {
    protected CraftariaScreen(class_2561 title) { super(title); }

    @Override
    protected void method_57734(float delta) {
        // Vanilla may already have blurred this frame while replacing the pause screen.
    }
}
