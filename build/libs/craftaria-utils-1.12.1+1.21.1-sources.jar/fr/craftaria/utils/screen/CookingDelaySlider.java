package fr.craftaria.utils.screen;

import fr.craftaria.utils.config.ModConfig;
import java.util.Locale;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_357;

public final class CookingDelaySlider extends class_357 {
    public CookingDelaySlider(int x, int y, int width) {
        super(x, y, width, 20, class_2561.method_43473(), (ModConfig.get().cookingDelayTicks - 2) / 98.0);
        method_25346();
    }

    @Override public void method_48579(class_332 context, int mouseX, int mouseY, float delta) {
        var font = class_310.method_1551().field_1772;
        context.method_27535(font, method_25369(), method_46426(), method_46427(), 0xFFF0E9DA);
        int trackY=method_46427()+16;
        context.method_25294(method_46426(), trackY, method_46426()+method_25368(), trackY+2, 0xFF514D45);
        int handleX=method_46426()+(int)Math.round(field_22753*(method_25368()-8));
        context.method_25294(method_46426(), trackY, handleX+4, trackY+2, 0xFFCFAD6D);
        context.method_25294(handleX, trackY-3, handleX+8, trackY+5, method_49606() || method_25370() ? 0xFFFFD383 : 0xFFE4D3AC);
    }

    @Override protected void method_25346() {
        method_25355(class_2561.method_43469("craftaria_utils.settings.delay",
                String.format(Locale.getDefault(), "%.1f", ModConfig.get().cookingDelayTicks / 20.0)));
    }

    @Override protected void method_25344() {
        // Fifty values, one for each tenth of a second from 0.1 to 5.0.
        ModConfig.get().cookingDelayTicks = 2 + (int)Math.round(field_22753 * 49) * 2;
        ModConfig.save();
        method_25346();
    }
}
