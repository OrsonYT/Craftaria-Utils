package fr.craftaria.utils.screen;

import org.lwjgl.glfw.GLFW;
import java.util.function.Supplier;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_6382;

/** Quiet, gold-accented action matching the custom title menu. */
public final class SettingsButton extends class_339 {
    private final Runnable action;
    private final Supplier<class_2561> label;
    public SettingsButton(int x, int y, int width, Supplier<class_2561> label, Runnable action) {
        super(x, y, width, 22, label.get());
        this.action = action;
        this.label = label;
    }
    @Override protected void method_48579(class_332 context, int mouseX, int mouseY, float delta) {
        method_25355(label.get());
        boolean highlighted = method_49606() || method_25370();
        context.method_25294(method_46426(), method_46427(), method_46426()+method_25368(), method_46427()+method_25364(), highlighted ? 0x453E3020 : 0x35101720);
        context.method_25294(method_46426(), method_46427()+method_25364()-1, method_46426()+method_25368(), method_46427()+method_25364(), highlighted ? 0xFFFFD383 : 0x806E6554);
        var font = class_310.method_1551().field_1772;
        String text = font.method_27523(method_25369().getString(), method_25368()-14);
        context.method_27535(font, class_2561.method_43470(text), method_46426()+7, method_46427()+7, highlighted ? 0xFFFFD383 : 0xFFF0E9DA);
    }
    @Override public void method_25348(double mouseX, double mouseY) { action.run(); }
    @Override public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        if (field_22763 && method_25370() && (keyCode==GLFW.GLFW_KEY_ENTER || keyCode==GLFW.GLFW_KEY_SPACE || keyCode==GLFW.GLFW_KEY_KP_ENTER)) {
            method_25354(class_310.method_1551().method_1483());
            action.run();
            return true;
        }
        return false;
    }
    @Override protected void method_47399(class_6382 builder) { method_37021(builder); }
}
