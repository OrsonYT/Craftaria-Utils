package fr.craftaria.utils.screen;

import fr.craftaria.utils.TrackedPlayerSkins;
import fr.craftaria.utils.wallpaper.WallpaperManager;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_437;
import net.minecraft.class_7532;

/** Confirmation card shown before adding a watched username. */
public final class TrackedPlayerConfirmScreen extends CraftariaScreen {
    private final class_437 parent;
    private final String playerName;
    private final Runnable confirm;

    public TrackedPlayerConfirmScreen(class_437 parent, String playerName, Runnable confirm) {
        super(class_2561.method_43471("craftaria_utils.tracker.confirm_title"));
        this.parent=parent;
        this.playerName=playerName;
        this.confirm=confirm;
        TrackedPlayerSkins.request(playerName);
    }

    @Override protected void method_25426() {
        int center=field_22789/2, y=field_22790/2+42;
        method_37063(new SettingsButton(center-104,y,96,() -> class_2561.method_43471("gui.yes"),() -> {
            confirm.run(); field_22787.method_1507(parent);
        }));
        method_37063(new SettingsButton(center+8,y,96,() -> class_2561.method_43471("gui.no"),() -> field_22787.method_1507(parent)));
    }

    @Override public void method_25420(class_332 context,int mouseX,int mouseY,float delta) { }
    @Override public void method_25394(class_332 context,int mouseX,int mouseY,float delta) {
        WallpaperManager.draw(context,field_22789,field_22790);
        context.method_25294(0,0,field_22789,field_22790,0xC80A1017);
        int boxWidth=300, boxHeight=128, x=(field_22789-boxWidth)/2, y=(field_22790-boxHeight)/2;
        context.method_25294(x,y,x+boxWidth,y+boxHeight,0xEF101720);
        context.method_25294(x,y,x+boxWidth,y+2,0xFFFFD383);
        context.method_25294(x,y+boxHeight-1,x+boxWidth,y+boxHeight,0xFF756B57);
        context.method_27534(field_22793,field_22785,field_22789/2,y+12,0xFFFFD383);
        var skin=TrackedPlayerSkins.get(playerName);
        if (skin!=null) class_7532.method_52722(context,skin,field_22789/2-36,y+42,32);
        else context.method_51427(class_1802.field_8575.method_7854(),field_22789/2-32,y+46);
        context.method_27534(field_22793,class_2561.method_43470(playerName),field_22789/2,y+79,0xFFF0E9DA);
        context.method_27534(field_22793,class_2561.method_43471("craftaria_utils.tracker.confirm"),field_22789/2,y+95,0xFFB8B4AA);
        super.method_25394(context,mouseX,mouseY,delta);
    }
}
