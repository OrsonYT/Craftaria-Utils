package fr.craftaria.utils.screen;

import fr.craftaria.utils.config.ModConfig;
import fr.craftaria.utils.wallpaper.WallpaperManager;
import java.util.function.BooleanSupplier;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_437;

public final class TrackerAlertSettingsScreen extends CraftariaScreen {
    private final class_437 parent;
    private int left,contentWidth;
    public TrackerAlertSettingsScreen(class_437 parent) {
        super(class_2561.method_43471("craftaria_utils.tracker.alerts")); this.parent=parent;
    }
    @Override protected void method_25426() {
        contentWidth=Math.min(440,field_22789-28); left=(field_22789-contentWidth)/2;
        int y=Math.max(74,field_22790/2-45);
        addToggle(y,"join",()->ModConfig.get().trackerNotifyJoin,()->ModConfig.get().trackerNotifyJoin=!ModConfig.get().trackerNotifyJoin);
        addToggle(y+32,"leave",()->ModConfig.get().trackerNotifyLeave,()->ModConfig.get().trackerNotifyLeave=!ModConfig.get().trackerNotifyLeave);
        addToggle(y+64,"initial",()->ModConfig.get().trackerNotifyAlreadyOnline,()->ModConfig.get().trackerNotifyAlreadyOnline=!ModConfig.get().trackerNotifyAlreadyOnline);
        method_37063(new SettingsButton(left,field_22790-28,contentWidth,()->class_2561.method_43471("gui.back"),this::method_25419));
    }
    private void addToggle(int y,String key,BooleanSupplier value,Runnable change) {
        method_37063(new SettingsButton(left,y,contentWidth,
                ()->class_2561.method_43469("craftaria_utils.tracker.notify_"+key,class_2561.method_43471(value.getAsBoolean()?"options.on":"options.off")),()->{
            change.run(); ModConfig.save();
        }));
    }
    @Override public void method_25420(class_332 c,int x,int y,float delta) { }
    @Override public void method_25394(class_332 c,int x,int y,float delta) {
        WallpaperManager.draw(c,field_22789,field_22790); c.method_25294(0,0,field_22789,field_22790,0xBF0A1017);
        MenuTextButton.drawLabel(c,field_22785,left,16,1.3f,false,true);
        c.method_51440(field_22793,class_2561.method_43471("craftaria_utils.tracker.alerts_hint"),left,40,contentWidth,0xFFB8B4AA);
        super.method_25394(c,x,y,delta);
    }
    @Override public void method_25419() { field_22787.method_1507(parent); }
}
