package fr.craftaria.utils.protection;

import fr.craftaria.utils.config.ModConfig;
import java.util.ArrayList;
import java.util.Base64;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.class_1799;
import net.minecraft.class_2509;
import net.minecraft.class_310;
import net.minecraft.class_5455;
import net.minecraft.class_7923;

/** Tracks selected stacks individually using their complete item components and count. */
public final class ProtectedStacks {
    private static final String PREFIX = "stack:";
    private ProtectedStacks() { }

    public static String fingerprint(class_1799 stack, class_5455 registries) {
        if (stack == null || stack.method_7960()) return "";
        var encoded = class_1799.field_24671.encodeStart(registries.method_57093(class_2509.field_11560), stack)
                .result().orElse(null);
        if (encoded == null) return "";
        return PREFIX + class_7923.field_41178.method_10221(stack.method_7909()) + ":"
                + Base64.getUrlEncoder().withoutPadding().encodeToString(encoded.toString().getBytes(java.nio.charset.StandardCharsets.UTF_8));
    }

    public static int count(class_1799 stack, class_5455 registries) {
        String key = fingerprint(stack, registries);
        return key.isEmpty() ? 0 : ModConfig.get().protectedStackCounts.getOrDefault(key, 0);
    }

    public static boolean isProtected(class_1799 stack, class_5455 registries) {
        return !stack.method_7960() && count(stack, registries) > 0;
    }

    public static void add(class_1799 stack, class_5455 registries) {
        String key = fingerprint(stack, registries);
        if (key.isEmpty()) return;
        ModConfig.get().protectedStackCounts.put(key, stack.method_7947());
        syncList();
    }

    public static void remove(class_1799 stack, class_5455 registries) {
        ModConfig.get().protectedStackCounts.remove(fingerprint(stack, registries));
        syncList();
    }

    /** Refreshes stack-count keys after legitimate uses/consumption without extending the protected quantity. */
    public static void reconcile(List<class_1799> inventory, class_5455 registries) {
        Map<String, Integer> available = new LinkedHashMap<>();
        for (class_1799 stack : inventory) if (!stack.method_7960()) {
            String key = fingerprint(stack, registries);
            if (!key.isEmpty()) available.merge(key, stack.method_7947(), Integer::sum);
        }
        Map<String, Integer> updated = new LinkedHashMap<>();
        List<String> oldKeys = new ArrayList<>(ModConfig.get().protectedStackCounts.keySet());
        for (String protectedKey : oldKeys) {
            int protectedCount = Math.max(0, ModConfig.get().protectedStackCounts.getOrDefault(protectedKey, 0));
            if (protectedCount == 0) continue;
            if (available.containsKey(protectedKey)) {
                int retained = Math.min(protectedCount, available.get(protectedKey));
                updated.put(protectedKey, retained);
                available.put(protectedKey, available.get(protectedKey) - retained);
                continue;
            }
            String oldItem = itemId(protectedKey);
            String match = available.keySet().stream()
                    .filter(candidate -> itemId(candidate).equals(oldItem))
                    .findFirst().orElse(null);
            if (match != null) {
                int retained = Math.min(protectedCount, available.get(match));
                updated.merge(match, retained, Math::max);
                available.put(match, available.get(match) - retained);
            }
        }
        ModConfig.get().protectedStackCounts = updated;
        syncList();
    }

    public static void removeKey(String key) {
        ModConfig.get().protectedStackCounts.remove(key);
        syncList();
    }

    public static class_1799 previewStack(String key) {
        if (key.startsWith("legacy:")) return fr.craftaria.utils.config.QuickHome.iconStack(key.substring("legacy:".length()));
        try {
            String encoded = new String(Base64.getUrlDecoder().decode(key.substring(key.indexOf(':', PREFIX.length())+1)), java.nio.charset.StandardCharsets.UTF_8);
            var nbt = net.minecraft.class_2522.method_10718(encoded);
            var client = class_310.method_1551();
            if (client.field_1687 != null) return class_1799.method_57360(client.field_1687.method_30349(), nbt).orElse(class_1799.field_8037);
        } catch (Exception ignored) { }
        return class_1799.field_8037;
    }

    private static String itemId(String fingerprint) {
        if (!fingerprint.startsWith(PREFIX)) return "";
        int separator = fingerprint.indexOf(':', PREFIX.length());
        return separator < 0 ? fingerprint.substring(PREFIX.length()) : fingerprint.substring(PREFIX.length(), separator);
    }

    private static void syncList() {
        ModConfig.get().protectedItems = new ArrayList<>(ModConfig.get().protectedStackCounts.keySet());
    }
}
