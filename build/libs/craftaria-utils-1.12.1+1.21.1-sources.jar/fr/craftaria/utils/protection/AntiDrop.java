package fr.craftaria.utils.protection;

import fr.craftaria.utils.config.ModConfig;
import net.minecraft.class_1109;
import net.minecraft.class_1657;
import net.minecraft.class_1713;
import net.minecraft.class_1723;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3417;

/** Guards ordinary client inventory actions before vanilla mutates or sends them. */
public final class AntiDrop {
    private static long until, lastSound;
    private static class_2561 message;
    private AntiDrop() { }

    public static boolean isProtected(class_1799 stack) {
        var client = class_310.method_1551();
        return ModConfig.get().antiDropEnabled && client.field_1687 != null && client.field_1687.method_30349() != null
                && ProtectedStacks.isProtected(stack, client.field_1687.method_30349());
    }

    public static boolean blocksClick(class_1657 player,int slotId,int button,class_1713 action) {
        if (!ModConfig.get().antiDropEnabled) return false;
        var handler=player.field_7512;
        var slot=slotId>=0 && slotId<handler.field_7761.size()?handler.field_7761.get(slotId):null;
        boolean foreign=slot!=null && slot.field_7871!=player.method_31548();
        boolean protectedSource=slot!=null && isProtected(slot.method_7677());
        boolean protectedCursor=isProtected(handler.method_34255());
        var destination=slot==null?AntiDropPolicy.Destination.OUTSIDE:
                foreign?AntiDropPolicy.Destination.CONTAINER:AntiDropPolicy.Destination.PLAYER;
        boolean protectedSwap=button>=0 && button<9 && isProtected(player.method_31548().method_5438(button))
                || button==40 && isProtected(player.method_6079());
        return AntiDropPolicy.blocks(action.name(),destination,protectedSource,protectedCursor,protectedSwap,handler instanceof class_1723);
    }

    public static void alert(boolean cursorMustBePlaced) {
        long now=System.currentTimeMillis();
        message=class_2561.method_43471(cursorMustBePlaced?"craftaria_utils.antidrop.place_first":"craftaria_utils.antidrop.blocked");
        until=now+3000;
        if(now-lastSound>650) {
            class_310.method_1551().method_1483().method_4873(class_1109.method_4757(class_3417.field_14785,1.4f,1f));
            lastSound=now;
        }
    }

    public static void render(class_332 c) {
        var client=class_310.method_1551();
        if(client.field_1724==null) { message=null; return; }
        if(message==null || System.currentTimeMillis()>=until) return;
        int width=Math.min(c.method_51421()-16,Math.max(220,client.field_1772.method_27525(message)+24));
        int x=(c.method_51421()-width)/2,y=Math.min(110,c.method_51443()/4);
        c.method_51452(); c.method_51448().method_22903(); c.method_51448().method_46416(0,0,2000);
        c.method_25294(x,y,x+width,y+30,0xF01B1418);
        c.method_25294(x,y,x+width,y+2,0xFFFF7777);
        c.method_25300(client.field_1772,client.field_1772.method_27523(message.getString(),width-16),x+width/2,y+11,0xFFFFC9C9);
        c.method_51452(); c.method_51448().method_22909();
    }

    public static void reconcileInventory() {
        var client = class_310.method_1551();
        if (client.field_1724 == null || client.field_1687 == null || ModConfig.get().protectedStackCounts.isEmpty()) return;
        ProtectedStacks.reconcile(client.field_1724.method_31548().field_7547, client.field_1687.method_30349());
        ProtectedStacks.reconcile(client.field_1724.method_31548().field_7548, client.field_1687.method_30349());
        ProtectedStacks.reconcile(client.field_1724.method_31548().field_7544, client.field_1687.method_30349());
    }
}
