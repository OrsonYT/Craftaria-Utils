package fr.craftaria.utils.mixin;

import fr.craftaria.utils.protection.AntiDrop;
import net.minecraft.class_310;
import net.minecraft.class_465;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_465.class)
public abstract class AntiDropHandledScreenMixin {
    @Inject(method="close",at=@At("HEAD"),cancellable=true)
    private void craftariaUtils$placeProtectedCursorFirst(CallbackInfo ci) {
        var player=class_310.method_1551().field_1724;
        if(player!=null && AntiDrop.isProtected(player.field_7512.method_34255())) {
            AntiDrop.alert(true); ci.cancel();
        }
    }
}
