package fr.craftaria.utils.mixin;

import fr.craftaria.utils.screen.CraftariaTitleScreen;
import fr.craftaria.utils.screen.MenuTextButton;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4068;
import net.minecraft.class_412;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_412.class)
public abstract class ConnectScreenMixin extends class_437 {
    @Shadow @Final private class_437 parent;
    @Shadow private class_2561 status;
    protected ConnectScreenMixin(class_2561 title) { super(title); }

    @Inject(method = "init", at = @At("TAIL"))
    private void craftariaUtils$positionCancel(CallbackInfo ci) {
        if (parent instanceof CraftariaTitleScreen) {
            float s = Math.min(field_22789/960f, field_22790/540f);
            for (var child : java.util.List.copyOf(method_25396())) if (child instanceof class_4185 button) {
                method_37066(button);
                method_37063(new MenuTextButton(Math.round(64*s), Math.round(302*s),
                        Math.round(280*s), Math.max(20, Math.round(32*s)), class_2561.method_43471("gui.cancel"),
                        2.1f*s, button::method_25306));
            }
        }
    }

    @Inject(method = "render", at = @At("HEAD"), cancellable = true)
    private void craftariaUtils$render(class_332 context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        if (parent instanceof CraftariaTitleScreen menu) {
            menu.renderConnecting(context, field_22789, field_22790, status);
            // Screen.render draws its background again in 1.21.1, hiding our logo and title.
            for (var child : method_25396()) if (child instanceof class_4068 drawable) drawable.method_25394(context, mouseX, mouseY, delta);
            ci.cancel();
        }
    }
}
