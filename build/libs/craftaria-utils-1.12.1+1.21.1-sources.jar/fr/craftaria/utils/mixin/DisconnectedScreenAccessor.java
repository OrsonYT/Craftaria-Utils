package fr.craftaria.utils.mixin;

import net.minecraft.class_419;
import net.minecraft.class_437;
import net.minecraft.class_9812;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_419.class)
public interface DisconnectedScreenAccessor {
    @Accessor("parent") class_437 craftariaUtils$getParent();
    @Accessor("info") class_9812 craftariaUtils$getInfo();
}
