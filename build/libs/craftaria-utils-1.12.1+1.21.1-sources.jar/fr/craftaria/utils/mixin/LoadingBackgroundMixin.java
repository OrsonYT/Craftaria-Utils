package fr.craftaria.utils.mixin;

import fr.craftaria.utils.wallpaper.WallpaperManager;
import net.minecraft.class_332;
import net.minecraft.class_3928;
import net.minecraft.class_412;
import net.minecraft.class_424;
import net.minecraft.class_434;
import net.minecraft.class_435;
import net.minecraft.class_437;
import net.minecraft.class_8671;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(class_437.class)
public abstract class LoadingBackgroundMixin {
    /** Intercept the background dispatch so overridden terrain/portal backgrounds are covered too. */
    @Redirect(method = "render", at = @At(value = "INVOKE",
            target = "Lnet/minecraft/client/gui/screen/Screen;renderBackground(Lnet/minecraft/client/gui/DrawContext;IIF)V"))
    private void craftariaUtils$loadingBackground(class_437 screen, class_332 context, int mouseX, int mouseY, float delta) {
        if (screen instanceof class_434 || screen instanceof class_3928 || screen instanceof class_8671
                || screen instanceof class_435 || screen instanceof class_424 || screen instanceof class_412) {
            WallpaperManager.draw(context, screen.field_22789, screen.field_22790);
            context.method_25294(0, 0, screen.field_22789, screen.field_22790, 0x60000000);
        } else {
            screen.method_25420(context, mouseX, mouseY, delta);
        }
    }
}
