package fr.craftaria.utils.mixin;

import fr.craftaria.utils.protection.AntiDrop;
import net.minecraft.class_1657;
import net.minecraft.class_1713;
import net.minecraft.class_1799;
import net.minecraft.class_636;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_636.class)
public abstract class AntiDropInteractionMixin {
    @Inject(method="clickSlot",at=@At("HEAD"),cancellable=true)
    private void craftariaUtils$protectClick(int syncId,int slotId,int button,class_1713 action,class_1657 player,CallbackInfo ci) {
        if(AntiDrop.blocksClick(player,slotId,button,action)) { AntiDrop.alert(false); ci.cancel(); }
    }
    @Inject(method="dropCreativeStack",at=@At("HEAD"),cancellable=true)
    private void craftariaUtils$protectCreativeDrop(class_1799 stack,CallbackInfo ci) {
        if(AntiDrop.isProtected(stack)) { AntiDrop.alert(false); ci.cancel(); }
    }
}
