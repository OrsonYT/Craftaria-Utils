package fr.craftaria.utils.mixin;

import fr.craftaria.utils.protection.AntiDrop;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_746.class)
public abstract class AntiDropPlayerMixin {
    @Inject(method="dropSelectedItem",at=@At("HEAD"),cancellable=true)
    private void craftariaUtils$protectDrop(boolean entireStack,CallbackInfoReturnable<Boolean> cir) {
        if(AntiDrop.isProtected(((class_746)(Object)this).method_6047())) {
            AntiDrop.alert(false); cir.setReturnValue(false);
        }
    }
    @Inject(method="closeHandledScreen",at=@At("HEAD"),cancellable=true)
    private void craftariaUtils$protectCursorOnClose(CallbackInfo ci) {
        if(AntiDrop.isProtected(((class_746)(Object)this).field_7512.method_34255())) {
            AntiDrop.alert(true); ci.cancel();
        }
    }
}
