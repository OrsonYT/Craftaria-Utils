package fr.craftaria.utils.mixin;

import fr.craftaria.utils.protection.AntiDrop;
import net.minecraft.class_332;
import net.minecraft.class_437;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_437.class)
public abstract class AntiDropAlertMixin {
    @Inject(method="renderWithTooltip",at=@At("TAIL"))
    private void craftariaUtils$alert(class_332 context,int mouseX,int mouseY,float delta,CallbackInfo ci) {
        AntiDrop.render(context);
    }
}
