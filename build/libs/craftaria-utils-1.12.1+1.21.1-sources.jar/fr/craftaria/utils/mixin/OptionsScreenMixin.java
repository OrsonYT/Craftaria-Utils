package fr.craftaria.utils.mixin;

import com.llamalad7.mixinextras.sugar.Local;
import fr.craftaria.utils.screen.CraftariaConfigScreen;
import fr.craftaria.utils.screen.OptionsImageButton;
import net.minecraft.class_2561;
import net.minecraft.class_429;
import net.minecraft.class_437;
import net.minecraft.class_7845;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_429.class)
public abstract class OptionsScreenMixin extends class_437 {
    protected OptionsScreenMixin(class_2561 title) { super(title); }

    @Inject(method = "init", at = @At(value = "INVOKE",
            target = "Lnet/minecraft/client/gui/widget/ThreePartsLayoutWidget;addBody(Lnet/minecraft/client/gui/widget/Widget;)Lnet/minecraft/client/gui/widget/Widget;"))
    private void craftariaUtils$addSettings(CallbackInfo ci, @Local class_7845.class_7939 adder) {
        // Let Minecraft lay out this full-width row together with its own options.
        adder.method_47613(new OptionsImageButton(() -> field_22787.method_1507(new CraftariaConfigScreen((class_437)(Object)this))), 2);
    }
}
