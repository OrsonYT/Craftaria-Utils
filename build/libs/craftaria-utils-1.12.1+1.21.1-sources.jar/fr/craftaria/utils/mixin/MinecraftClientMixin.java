package fr.craftaria.utils.mixin;

import fr.craftaria.utils.screen.CraftariaTitleScreen;
import fr.craftaria.utils.screen.MenuNavigation;
import net.minecraft.class_310;
import net.minecraft.class_419;
import net.minecraft.class_437;
import net.minecraft.class_442;
import net.minecraft.class_500;
import fr.craftaria.utils.screen.CraftariaConnectionErrorScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(class_310.class)
public abstract class MinecraftClientMixin {
    @ModifyVariable(method = "setScreen", at = @At("HEAD"), argsOnly = true)
    private class_437 craftariaUtils$titleScreen(class_437 screen) {
        if (screen instanceof class_419 && screen instanceof DisconnectedScreenAccessor disconnected
                && disconnected.craftariaUtils$getParent() instanceof CraftariaTitleScreen menu
                && disconnected.craftariaUtils$getInfo().comp_2854().isEmpty()
                && disconnected.craftariaUtils$getInfo().comp_2855().isEmpty()) {
            return new CraftariaConnectionErrorScreen(menu,disconnected.craftariaUtils$getInfo().comp_2853());
        }
        if (!MenuNavigation.isVanillaMenuSelected() && screen != null
                && (screen.getClass() == class_442.class || screen instanceof class_500)) {
            return new CraftariaTitleScreen();
        }
        return screen;
    }
}
