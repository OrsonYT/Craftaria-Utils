package fr.craftaria.utils.mixin;

import fr.craftaria.utils.screen.CraftariaTitleScreen;
import net.minecraft.class_2561;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_442;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_442.class)
public abstract class TitleScreenMixin extends class_437 {
    protected TitleScreenMixin(class_2561 title) { super(title); }

    @Inject(method = "init", at = @At("TAIL"))
    private void craftariaUtils$returnToCustomMenu(CallbackInfo ci) {
        method_37063(class_4185.method_46430(class_2561.method_43471("craftaria_utils.menu.return_custom"),
                button -> field_22787.method_1507(new CraftariaTitleScreen()))
                .method_46434(field_22789 / 2 - 100, field_22790 / 4 + 20, 200, 20).method_46431());
    }
}
