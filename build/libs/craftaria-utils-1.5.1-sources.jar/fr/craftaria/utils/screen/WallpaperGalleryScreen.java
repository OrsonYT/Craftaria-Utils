package fr.craftaria.utils.screen;

import fr.craftaria.utils.config.ModConfig;
import fr.craftaria.utils.wallpaper.WallpaperManager;
import java.util.List;
import net.minecraft.class_156;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_437;

/** A paged thumbnail grid supports large collections and small GUI resolutions. */
public final class WallpaperGalleryScreen extends CraftariaScreen {
    private final class_437 parent;
    private List<String> wallpapers;
    private int page;
    private int pageSize = 1;
    private int pageCount = 1;
    private int left, galleryWidth;
    private boolean error;
    private boolean locateSelection = true;

    public WallpaperGalleryScreen(class_437 parent) {
        super(class_2561.method_43471("craftaria_utils.settings.wallpaper"));
        this.parent = parent;
        wallpapers = WallpaperManager.list();
    }

    @Override protected void method_25426() {
        galleryWidth = Math.min(900, field_22789-28);
        left = (field_22789-galleryWidth)/2;
        int columns = Math.clamp(galleryWidth/130, 1, 4);
        int gap = 10;
        int tileWidth = (galleryWidth-gap*(columns-1))/columns;
        int availableHeight = Math.max(36, field_22790-122);
        int tileHeight = Math.min(availableHeight, Math.clamp(tileWidth*9/16+17, 64, 124));
        int rows = Math.max(1, (availableHeight+gap)/(tileHeight+gap));
        pageSize = columns*rows;
        pageCount = Math.max(1, (wallpapers.size()+pageSize-1)/pageSize);
        if (locateSelection) {
            page = Math.max(0, wallpapers.indexOf(ModConfig.get().wallpaper))/pageSize;
            locateSelection = false;
        }
        page = Math.clamp(page, 0, pageCount-1);
        for (int i=0; i<pageSize && page*pageSize+i<wallpapers.size(); i++) {
            String name = wallpapers.get(page*pageSize+i);
            method_37063(new WallpaperTile(left+(i%columns)*(tileWidth+gap), 54+(i/columns)*(tileHeight+gap),
                    tileWidth, tileHeight, name, () -> error = !WallpaperManager.select(name)));
        }
        if (pageCount>1) {
            var previous = method_37063(new SettingsButton(field_22789/2-84, field_22790-58, 28,
                    () -> class_2561.method_43470("<"), () -> changePage(-1)));
            previous.field_22763 = page>0;
            var next = method_37063(new SettingsButton(field_22789/2+56, field_22790-58, 28,
                    () -> class_2561.method_43470(">"), () -> changePage(1)));
            next.field_22763 = page+1<pageCount;
        }
        method_37063(new SettingsButton(left, field_22790-28, 60, () -> class_2561.method_43471("gui.back"), this::method_25419));
        int folderWidth = Math.min(130, (galleryWidth-76)/2);
        int refreshWidth = Math.min(90, (galleryWidth-76)/2);
        method_37063(new SettingsButton(left+galleryWidth-refreshWidth-folderWidth-8, field_22790-28, folderWidth,
                () -> class_2561.method_43471("craftaria_utils.wallpaper.folder"), () -> class_156.method_668().method_60932(WallpaperManager.directory())));
        method_37063(new SettingsButton(left+galleryWidth-refreshWidth, field_22790-28, refreshWidth,
                () -> class_2561.method_43471("craftaria_utils.wallpaper.refresh"), () -> {
            WallpaperManager.refresh();
            wallpapers = WallpaperManager.list();
            error = false;
            method_41843();
        }));
    }

    private void changePage(int step) {
        int next = Math.clamp(page+step, 0, pageCount-1);
        if (next != page) { page = next; method_41843(); }
    }

    @Override public boolean method_25401(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (verticalAmount != 0) { changePage(verticalAmount>0 ? -1 : 1); return true; }
        return super.method_25401(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    @Override public void method_25420(class_332 context, int mouseX, int mouseY, float delta) { }
    @Override public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        WallpaperManager.draw(context, field_22789, field_22790);
        context.method_25294(0, 0, field_22789, field_22790, 0xB50A1017);
        MenuTextButton.drawLabel(context, field_22785, left, 12, 1.5f, false, true);
        boolean failed = error || WallpaperManager.hasLoadError();
        class_2561 description = class_2561.method_43471(failed ? "craftaria_utils.wallpaper.error"
                : "craftaria_utils.settings.wallpaper.description");
        context.method_25303(field_22793, field_22793.method_27523(description.getString(), galleryWidth),
                left, 35, failed ? 0xFFFF8888 : 0xFFC5C1B8);
        if (pageCount>1) context.method_27534(field_22793,
                class_2561.method_43470((page+1)+" / "+pageCount), field_22789/2, field_22790-51, 0xFFF0E9DA);
        else context.method_27534(field_22793, WallpaperManager.label(ModConfig.get().wallpaper), field_22789/2, field_22790-51, 0xFFFFD383);
        super.method_25394(context, mouseX, mouseY, delta);
    }

    @Override public void method_25432() { WallpaperManager.clearThumbnails(); }
    @Override public void method_25419() { field_22787.method_1507(parent); }
}
