package fr.craftaria.utils.screen;

import fr.craftaria.utils.CraftariaUtilsClient;
import fr.craftaria.utils.config.ModConfig;
import net.minecraft.class_10799;
import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_3675;
import net.minecraft.class_437;
import net.minecraft.class_458;
import org.lwjgl.glfw.GLFW;

public final class CraftariaConfigScreen extends CraftariaScreen {
    private static final class_2960 BACKGROUND = class_2960.method_60655("craftaria_utils", "fondbase.png");
    private static final class_2960 LOGO = class_2960.method_60655("craftaria_utils", "icon-transparent.png");
    private enum Page { REPAIR, LOGIN, COOKING, KEYS }
    private final class_437 parent;
    private Page page = Page.REPAIR;
    private class_304 capturing;
    private class_342 passwordField;
    private int left, top, contentX, contentWidth, bodyY;

    public CraftariaConfigScreen(class_437 parent) { super(class_2561.method_43471("craftaria_utils.title")); this.parent = parent; }

    @Override protected void method_25426() {
        capturing = null;
        passwordField = null;
        int totalWidth = Math.min(620, field_22789-28);
        left = (field_22789-totalWidth)/2;
        top = Math.max(12, (field_22790-280)/2);
        int sidebarWidth = field_22789 < 400 ? 92 : 128;
        contentX = left+sidebarWidth+20;
        contentWidth = totalWidth-sidebarWidth-20;
        bodyY = top+44;

        Page[] pages = Page.values();
        for (int i=0; i<pages.length; i++) {
            Page tab = pages[i];
            method_37063(new MenuTextButton(left+8, bodyY+8+i*27, sidebarWidth-10, 22,
                    class_2561.method_43471(pageKey(tab)), 1f, () -> { savePassword(); page=tab; method_41843(); }));
        }
        method_37063(new MenuTextButton(left+8, field_22790-27, 100, 20, class_2561.method_43471("gui.back"), 1f, this::method_25419));
        method_37063(new MenuTextButton(field_22789-115, field_22790-27, 104, 20,
                class_2561.method_43471("craftaria_utils.settings.controls"), .85f, () -> {
                    savePassword(); field_22787.method_1507(new class_458(this, field_22787.field_1690));
                }));

        int y = bodyY+45;
        switch (page) {
            case REPAIR -> {
                method_37063(new SettingsButton(contentX, y, contentWidth, () -> class_2561.method_43469("craftaria_utils.repair",
                        class_2561.method_43471(ModConfig.get().autoRepair ? "options.on" : "options.off")), () -> {
                    ModConfig.get().autoRepair = !ModConfig.get().autoRepair;
                    ModConfig.save();
                }));
            }
            case LOGIN -> {
                passwordField = new class_342(field_22793, contentX+1, y+13, contentWidth-2, 22,
                        class_2561.method_43471("craftaria_utils.login.password"));
                passwordField.method_1880(128);
                passwordField.method_1852(ModConfig.get().password);
                passwordField.method_1868(0xFFF0E9DA);
                passwordField.method_1858(false);
                passwordField.method_73210((value, cursor) -> class_2561.method_43470("•".repeat(value.length())).method_30937());
                passwordField.method_1863(value -> { ModConfig.get().password=value; ModConfig.save(); });
                method_37063(passwordField);
                addBindingRow(CraftariaUtilsClient.loginKey, "craftaria_utils.settings.login_key", y+52);
            }
            case COOKING -> {
                method_37063(new CookingDelaySlider(contentX, y, contentWidth));
                addBindingRow(CraftariaUtilsClient.cookingKey, "craftaria_utils.settings.cooking_key", y+35);
                method_37063(new SettingsButton(contentX, y+70, contentWidth,
                        () -> class_2561.method_43471("craftaria_utils.open_cooking"), () -> {
                    if (field_22787.field_1724 != null) { savePassword(); field_22787.method_1507(new CookingScreen(this)); }
                }));
            }
            case KEYS -> {
                addBindingRow(CraftariaUtilsClient.fourKey, "craftaria_utils.settings.four_key", y);
                addBindingRow(CraftariaUtilsClient.loginKey, "craftaria_utils.settings.login_key", y+29);
                addBindingRow(CraftariaUtilsClient.cookingKey, "craftaria_utils.settings.cooking_key", y+58);
            }
        }
    }

    private static String pageKey(Page page) { return "craftaria_utils.settings."+page.name().toLowerCase(java.util.Locale.ROOT); }

    private void addBindingRow(class_304 binding, String label, int y) {
        int keyWidth = Math.min(115, contentWidth/2);
        method_37063(new SettingsButton(contentX+contentWidth-keyWidth, y, keyWidth, () -> {
            if (capturing == binding) return class_2561.method_43471("craftaria_utils.settings.press_key");
            class_2561 key = binding.method_16007();
            return hasConflict(binding) ? class_2561.method_43469("craftaria_utils.settings.conflict_key", key) : key;
        }, () -> { capturing=binding; method_25395(null); }));
    }

    private boolean hasConflict(class_304 binding) {
        if (binding.method_1415()) return false;
        for (class_304 other : field_22787.field_1690.field_1839) if (other != binding && binding.method_1435(other)) return true;
        return false;
    }

    private void bind(class_3675.class_306 key) {
        capturing.method_1422(key);
        class_304.method_1426();
        class_304.method_1437();
        field_22787.field_1690.method_1640();
        capturing = null;
    }

    @Override public boolean method_25404(class_11908 input) {
        if (capturing != null) {
            bind(input.comp_4795()==GLFW.GLFW_KEY_ESCAPE ? class_3675.field_16237 : class_3675.method_15985(input));
            return true;
        }
        return super.method_25404(input);
    }

    @Override public boolean method_25402(class_11909 click, boolean doubled) {
        if (capturing != null) {
            bind(class_3675.class_307.field_1672.method_1447(click.method_74245()));
            return true;
        }
        return super.method_25402(click, doubled);
    }

    private void savePassword() {
        if (passwordField != null) ModConfig.get().password=passwordField.method_1882();
        ModConfig.save();
    }
    @Override public void method_25419() { savePassword(); field_22787.method_1507(parent); }
    @Override public void method_25432() { savePassword(); }

    @Override public void method_25420(class_332 context, int mouseX, int mouseY, float delta) { }

    @Override public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        float cover = Math.max(field_22789/2560f, field_22790/1600f);
        int bgWidth=(int)Math.ceil(2560*cover), bgHeight=(int)Math.ceil(1600*cover);
        context.method_25302(class_10799.field_56883, BACKGROUND, (field_22789-bgWidth)/2, (field_22790-bgHeight)/2,
                0, 0, bgWidth, bgHeight, 2560, 1600, 2560, 1600);
        context.method_25294(0, 0, field_22789, field_22790, 0xAB0A1017);
        context.method_25302(class_10799.field_56883, LOGO, left, top-1, 0, 0, 36, 36, 1254, 1254, 1254, 1254);
        MenuTextButton.drawLabel(context, field_22785, left+46, top+3, 1.5f, false, true);
        context.method_27535(field_22793, class_2561.method_43471("craftaria_utils.settings.subtitle"), left+46, top+23, 0xFFB8B4AA);
        context.method_25294(contentX-11, bodyY, contentX-10, field_22790-43, 0x606E6554);
        context.method_27535(field_22793, class_2561.method_43471(pageKey(page)), contentX, bodyY+3, 0xFFFFD383);
        context.method_65179(field_22793, class_2561.method_43471(pageKey(page)+".description"), contentX, bodyY+20, contentWidth, 0xFFC5C1B8);
        int y=bodyY+45;
        if (page==Page.LOGIN) {
            context.method_27535(field_22793, class_2561.method_43471("craftaria_utils.login.password"), contentX, y, 0xFFF0E9DA);
            context.method_25294(contentX, y+12, contentX+contentWidth, y+36, 0x50101720);
            context.method_25294(contentX, y+35, contentX+contentWidth, y+36, 0x806E6554);
            bindingLabel(context, "craftaria_utils.settings.login_key", y+52);
            if (y+103 < field_22790-46) context.method_65179(field_22793, class_2561.method_43471("craftaria_utils.password_storage"), contentX, y+83, contentWidth, 0xFF99968F);
        } else if (page==Page.COOKING) bindingLabel(context, "craftaria_utils.settings.cooking_key", y+35);
        else if (page==Page.KEYS) {
            bindingLabel(context, "craftaria_utils.settings.four_key", y);
            bindingLabel(context, "craftaria_utils.settings.login_key", y+29);
            bindingLabel(context, "craftaria_utils.settings.cooking_key", y+58);
        } else if (page==Page.REPAIR) {
            context.method_65179(field_22793, class_2561.method_43471("craftaria_utils.settings.repair.note"), contentX, y+35, contentWidth, 0xFF99968F);
        }
        if (capturing != null) context.method_27534(field_22793,
                class_2561.method_43471("craftaria_utils.settings.capture_hint"), field_22789/2, field_22790-41, 0xFFFFD383);
        else context.method_27534(field_22793, class_2561.method_43471("craftaria_utils.settings.saved"), field_22789/2, field_22790-41, 0xFF99968F);
        super.method_25394(context, mouseX, mouseY, delta);
    }

    private void bindingLabel(class_332 context, String key, int y) {
        int maxWidth=contentWidth-Math.min(115, contentWidth/2)-7;
        context.method_27535(field_22793, class_2561.method_43470(field_22793.method_27523(class_2561.method_43471(key).getString(), maxWidth)), contentX, y+7, 0xFFF0E9DA);
    }
}
