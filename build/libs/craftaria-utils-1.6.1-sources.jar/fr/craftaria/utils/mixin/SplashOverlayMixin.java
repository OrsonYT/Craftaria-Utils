package fr.craftaria.utils.mixin;

import com.mojang.blaze3d.pipeline.RenderPipeline;
import fr.craftaria.utils.wallpaper.WallpaperManager;
import net.minecraft.class_10799;
import net.minecraft.class_156;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_425;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Change the visuals only; vanilla still handles reload completion, errors, and fading. */
@Mixin(class_425.class)
public abstract class SplashOverlayMixin {
    @Shadow @Final private boolean reloading;
    @Shadow private long reloadCompleteTime;
    @Shadow private long reloadStartTime;
    @Unique private static final class_2960 CRAFTARIA_LOGO = class_2960.method_60655("craftaria_utils", "icon-transparent.png");

    @Redirect(method = "render", at = @At(value = "INVOKE",
            target = "Lnet/minecraft/client/gui/DrawContext;fill(IIIII)V"))
    private void craftariaUtils$reloadBackground(class_332 context, int x, int y, int right, int bottom, int color) {
        if (!reloading) {
            context.method_25294(x, y, right, bottom, color);
            return;
        }
        int alpha = color >>> 24;
        WallpaperManager.draw(context, x, y, right - x, bottom - y, alpha);
        context.method_25294(x, y, right, bottom, (Math.round(alpha * .40f) << 24));
    }

    @Redirect(method = "render", at = @At(value = "INVOKE",
            target = "Lnet/minecraft/client/gui/DrawContext;drawTexture(Lcom/mojang/blaze3d/pipeline/RenderPipeline;Lnet/minecraft/util/Identifier;IIFFIIIIIII)V"))
    private void craftariaUtils$startupLogoOnly(class_332 context, RenderPipeline pipeline, class_2960 texture,
            int x, int y, float u, float v, int width, int height, int regionWidth, int regionHeight,
            int textureWidth, int textureHeight, int color) {
        if (!reloading) context.method_25293(pipeline, texture, x, y, u, v, width, height,
                regionWidth, regionHeight, textureWidth, textureHeight, color);
    }

    @Inject(method = "render", at = @At("TAIL"))
    private void craftariaUtils$reloadLabel(class_332 context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        if (!reloading) return;
        long now = class_156.method_658();
        float alpha = Math.clamp((now - reloadStartTime) / 500f, 0f, 1f);
        if (reloadCompleteTime > -1) alpha *= 1f - Math.clamp((now - reloadCompleteTime) / 1000f, 0f, 1f);
        if (Math.round(alpha * 255) < 4) return;
        int color = (Math.round(alpha * 255) << 24) | 0xFFFFFF;
        int centerX = context.method_51421() / 2, centerY = context.method_51443() / 2;
        context.method_25293(class_10799.field_56883, CRAFTARIA_LOGO, centerX - 32, centerY - 44,
                0, 0, 64, 64, 1254, 1254, 1254, 1254, color);
        context.method_27534(class_310.method_1551().field_1772,
                class_2561.method_43471("craftaria_utils.wallpaper.reloading"), centerX, centerY + 34, color);
    }
}
