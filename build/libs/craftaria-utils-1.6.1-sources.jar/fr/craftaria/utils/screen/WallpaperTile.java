package fr.craftaria.utils.screen;

import fr.craftaria.utils.config.ModConfig;
import fr.craftaria.utils.wallpaper.WallpaperManager;
import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_6382;
import net.minecraft.class_7919;
import org.lwjgl.glfw.GLFW;

public final class WallpaperTile extends class_339 {
    private final String wallpaper;
    private final Runnable action;

    public WallpaperTile(int x, int y, int width, int height, String wallpaper, Runnable action) {
        super(x, y, width, height, WallpaperManager.label(wallpaper));
        this.wallpaper = wallpaper;
        this.action = action;
        method_47400(class_7919.method_47407(WallpaperManager.tooltip(wallpaper)));
    }

    @Override protected void method_48579(class_332 context, int mouseX, int mouseY, float delta) {
        int x = method_46426(), y = method_46427(), w = method_25368(), h = method_25364();
        WallpaperManager.drawThumbnail(context, wallpaper, x+1, y+1, w-2, h-17);
        context.method_25294(x, y+h-16, x+w, y+h, 0xE0101720);
        boolean selected = wallpaper.equals(ModConfig.get().wallpaper);
        int border = selected ? 0xFFFFD383 : method_49606() || method_25370() ? 0xFFE4D3AC : 0xFF60584A;
        context.method_25294(x, y, x+w, y+1, border);
        context.method_25294(x, y+h-1, x+w, y+h, border);
        context.method_25294(x, y+1, x+1, y+h-1, border);
        context.method_25294(x+w-1, y+1, x+w, y+h-1, border);
        var font = class_310.method_1551().field_1772;
        context.method_25303(font, font.method_27523(method_25369().getString(), w-12), x+6, y+h-12,
                selected ? 0xFFFFD383 : 0xFFF0E9DA);
        if (selected) {
            context.method_25294(x+w-15, y+4, x+w-4, y+15, 0xDD101720);
            context.method_25294(x+w-13, y+9, x+w-11, y+12, 0xFFFFD383);
            context.method_25294(x+w-11, y+10, x+w-9, y+13, 0xFFFFD383);
            context.method_25294(x+w-9, y+7, x+w-7, y+11, 0xFFFFD383);
        }
    }

    @Override public void method_25348(class_11909 click, boolean doubled) { action.run(); }
    @Override public boolean method_25404(class_11908 input) {
        if (field_22763 && method_25370() && (input.comp_4795()==GLFW.GLFW_KEY_ENTER || input.comp_4795()==GLFW.GLFW_KEY_SPACE || input.comp_4795()==GLFW.GLFW_KEY_KP_ENTER)) {
            method_25354(class_310.method_1551().method_1483());
            action.run();
            return true;
        }
        return false;
    }
    @Override protected void method_47399(class_6382 builder) { method_37021(builder); }
}
