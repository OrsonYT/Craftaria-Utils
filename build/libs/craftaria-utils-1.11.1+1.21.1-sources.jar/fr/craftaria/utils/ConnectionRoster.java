package fr.craftaria.utils;

import java.util.*;

/** The initial roster is a baseline, never a batch of new connections. */
public final class ConnectionRoster {
    private Object connection;
    private Set<UUID> previous=Set.of();
    private int warmup;
    public void reset() { connection=null; previous=Set.of(); warmup=0; }
    public List<String> update(Object session,Map<UUID,String> players,Set<String> tracked,boolean enabled) {
        if(session!=connection) { connection=session; previous=Set.of(); warmup=60; }
        List<String> joined=new ArrayList<>();
        if(warmup>0) warmup--;
        else if(enabled) for(var entry:players.entrySet()) {
            if(!previous.contains(entry.getKey()) && tracked.contains(entry.getValue().toLowerCase(Locale.ROOT))) joined.add(entry.getValue());
        }
        previous=Set.copyOf(players.keySet());
        return joined;
    }
}
