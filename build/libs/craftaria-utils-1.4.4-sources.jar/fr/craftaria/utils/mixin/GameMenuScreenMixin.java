package fr.craftaria.utils.mixin;

import fr.craftaria.utils.screen.CraftariaConfigScreen;
import fr.craftaria.utils.screen.OptionsImageButton;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_4185;
import net.minecraft.class_433;
import net.minecraft.class_437;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_433.class)
public abstract class GameMenuScreenMixin extends class_437 {
    protected GameMenuScreenMixin(class_2561 title) { super(title); }

    @Inject(method = "init", at = @At("TAIL"))
    private void craftariaUtils$addButton(CallbackInfo ci) {
        class_433 screen = (class_433)(Object)this;
        int y = screen.field_22790 / 4 + 144;
        int buttonHeight = Math.max(20, (int)Math.round(200.0 * 30.0 / 308.0));
        for (var child : screen.method_25396()) {
            if (child instanceof class_4185 button && button.method_25369().getString().equals(class_2561.method_43471("menu.disconnect").getString())) {
                y = button.method_46427();
                button.method_46419(button.method_46427() + buttonHeight + 4);
                break;
            }
        }
        OptionsImageButton craftariaButton = new OptionsImageButton(200,
                () -> class_310.method_1551().method_1507(new CraftariaConfigScreen(screen)));
        craftariaButton.method_46421(screen.field_22789 / 2 - 100);
        craftariaButton.method_46419(y);
        method_37063(craftariaButton);
    }
}
