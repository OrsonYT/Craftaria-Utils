package fr.craftaria.utils.screen;

import net.minecraft.class_1011;
import net.minecraft.class_10799;
import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_4185;
import net.minecraft.class_6382;
import org.lwjgl.glfw.GLFW;

/** Uses the supplied banner, including its lettering, without drawing a second label. */
public final class OptionsImageButton extends class_339 {
    private static final class_2960 TEXTURE = class_2960.method_60655("craftaria_utils", "textures/gui/options_button.png");
    private final Runnable action;
    private final class_4185 fallback;
    private boolean hasTexture;
    private int imageWidth, imageHeight;
    private int sourceX, sourceY, sourceWidth, sourceHeight;

    public OptionsImageButton(Runnable action) {
        this(308, action);
    }

    public OptionsImageButton(int width, Runnable action) {
        super(0, 0, width, Math.max(20, (int)Math.round(width * 30.0 / 308.0)), class_2561.method_43471("craftaria_utils.title"));
        this.action = action;
        fallback = class_4185.method_46430(method_25369(), button -> action.run()).method_46432(width).method_46431();
        var resource = class_310.method_1551().method_1478().method_14486(TEXTURE);
        if (resource.isPresent()) {
            try (var stream = resource.get().method_14482(); class_1011 image = class_1011.method_4309(stream)) {
                imageWidth = image.method_4307();
                imageHeight = image.method_4323();
                int minX = imageWidth, minY = imageHeight, maxX = -1, maxY = -1;
                for (int y = 0; y < imageHeight; y++) {
                    for (int x = 0; x < imageWidth; x++) {
                        int color = image.method_61940(x, y);
                        int brightness = Math.max((color >> 16) & 255, Math.max((color >> 8) & 255, color & 255));
                        if ((color >>> 24) >= 128 && brightness > 20) {
                            minX = Math.min(minX, x); minY = Math.min(minY, y);
                            maxX = Math.max(maxX, x); maxY = Math.max(maxY, y);
                        }
                    }
                }
                if (maxX >= minX && maxY >= minY) {
                    sourceX = Math.max(0, minX-2); sourceY = Math.max(0, minY-2);
                    sourceWidth = Math.min(imageWidth-sourceX, maxX-sourceX+3);
                    sourceHeight = Math.min(imageHeight-sourceY, maxY-sourceY+3);
                    method_53533(Math.max(20, (int)Math.round(method_25368()*(double)sourceHeight/sourceWidth)));
                    hasTexture = true;
                }
            } catch (Exception ignored) { /* Keep the settings accessible if a resource pack replaces the image incorrectly. */ }
        }
    }

    @Override protected void method_48579(class_332 context, int mouseX, int mouseY, float delta) {
        if (!hasTexture) {
            fallback.method_46421(method_46426());
            fallback.method_46419(method_46427()+(method_25364()-20)/2);
            fallback.method_25365(method_25370());
            fallback.method_25394(context, mouseX, mouseY, delta);
            return;
        }
        context.method_25302(class_10799.field_56883, TEXTURE, method_46426(), method_46427(), sourceX, sourceY,
                method_25368(), method_25364(), sourceWidth, sourceHeight, imageWidth, imageHeight);
        if (method_49606() || method_25370()) {
            context.method_25294(method_46426()+2, method_46427()+2, method_46426()+method_25368()-2, method_46427()+method_25364()-2, 0x18FFD383);
            context.method_25294(method_46426()+2, method_46427()+method_25364()-1, method_46426()+method_25368()-2, method_46427()+method_25364(), 0xFFFFD383);
        }
    }

    @Override public void method_25348(class_11909 click, boolean doubled) { action.run(); }
    @Override public boolean method_25404(class_11908 input) {
        if (field_22763 && method_25370() && (input.comp_4795()==GLFW.GLFW_KEY_ENTER || input.comp_4795()==GLFW.GLFW_KEY_SPACE || input.comp_4795()==GLFW.GLFW_KEY_KP_ENTER)) {
            method_25354(class_310.method_1551().method_1483());
            action.run();
            return true;
        }
        return false;
    }
    @Override protected void method_47399(class_6382 builder) { method_37021(builder); }
}
