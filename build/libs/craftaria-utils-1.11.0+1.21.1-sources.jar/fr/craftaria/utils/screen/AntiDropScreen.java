package fr.craftaria.utils.screen;

import fr.craftaria.utils.config.ModConfig;
import net.minecraft.class_1713;
import net.minecraft.class_1723;
import net.minecraft.class_1735;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_465;
import net.minecraft.class_490;
import net.minecraft.class_7923;

/** Only edits the protection list; selecting never sends an inventory click. */
public final class AntiDropScreen extends class_465<class_1723> {
    private final class_437 parent;
    public AntiDropScreen(class_437 parent) {
        super(class_310.method_1551().field_1724.field_7498,class_310.method_1551().field_1724.method_31548(),
                class_2561.method_43471("craftaria_utils.settings.antidrop"));
        this.parent=parent;
    }
    @Override protected void method_25426() {
        super.method_25426();
        method_37063(class_4185.method_46430(class_2561.method_43471("gui.done"),b->method_25419()).method_46434(field_2776,field_2800+field_2779+6,85,20).method_46431());
        method_37063(class_4185.method_46430(class_2561.method_43471("craftaria_utils.antidrop.clear"),b->{ModConfig.get().protectedItems.clear();ModConfig.save();})
                .method_46434(field_2776+91,field_2800+field_2779+6,85,20).method_46431());
    }
    @Override public boolean method_25402(double mouseX,double mouseY,int button) {
        for(class_1735 slot:field_2797.field_7761) if(mouseX>=field_2776+slot.field_7873 && mouseX<field_2776+slot.field_7873+16 && mouseY>=field_2800+slot.field_7872 && mouseY<field_2800+slot.field_7872+16) {
            if(button==0 && slot.field_7871==field_22787.field_1724.method_31548() && slot.method_7681()) {
                String id=class_7923.field_41178.method_10221(slot.method_7677().method_7909()).toString();
                if(!ModConfig.get().protectedItems.remove(id)) ModConfig.get().protectedItems.add(id);
                ModConfig.save();
            }
            return true;
        }
        return super.method_25402(mouseX,mouseY,button);
    }
    @Override protected void method_2383(class_1735 slot,int slotId,int button,class_1713 action) { }
    @Override protected void method_2385(class_332 context,class_1735 slot) {
        super.method_2385(context,slot);
        if(slot.method_7681() && slot.field_7871==field_22787.field_1724.method_31548()
                && ModConfig.get().protectedItems.contains(class_7923.field_41178.method_10221(slot.method_7677().method_7909()).toString()))
            context.method_25294(slot.field_7873,slot.field_7872,slot.field_7873+16,slot.field_7872+16,0x8033DD55);
    }
    @Override protected void method_2389(class_332 context,float delta,int mouseX,int mouseY) {
        GuiTextures.draw(context,class_2960.method_60656("textures/gui/container/inventory.png"),field_2776,field_2800,0,0,field_2792,field_2779,256,256);
        class_490.method_2486(context,field_2776+26,field_2800+8,field_2776+75,field_2800+78,30,.0625f,mouseX,mouseY,field_22787.field_1724);
    }
    @Override public void method_25394(class_332 context,int mouseX,int mouseY,float delta) {
        super.method_25394(context,mouseX,mouseY,delta);
        context.method_27534(field_22793,class_2561.method_43471("craftaria_utils.antidrop.select_hint"),field_22789/2,field_2800-23,0xFFF0E9DA);
        context.method_27534(field_22793,class_2561.method_43471("craftaria_utils.antidrop.all_of_type"),field_22789/2,field_2800-11,0xFFFFD383);
        method_2380(context,mouseX,mouseY);
    }
    @Override protected void method_57734(float delta) { }
    @Override public void method_25419() { field_22787.method_1507(parent); }
}
