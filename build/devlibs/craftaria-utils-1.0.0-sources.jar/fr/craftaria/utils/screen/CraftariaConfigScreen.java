package fr.craftaria.utils.screen;

import fr.craftaria.utils.CraftariaUtilsClient;
import fr.craftaria.utils.config.ModConfig;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;
import net.minecraft.text.OrderedText;

public final class CraftariaConfigScreen extends CraftariaScreen {
    private final Screen parent;
    private TextFieldWidget passwordField;
    private ButtonWidget repairButton;
    public CraftariaConfigScreen(Screen parent) { super(Text.translatable("craftaria_utils.title")); this.parent = parent; }

    @Override protected void init() {
        repairButton = addDrawableChild(ButtonWidget.builder(repairLabel(), b -> {
            ModConfig.get().autoRepair = !ModConfig.get().autoRepair;
            b.setMessage(repairLabel()); ModConfig.save();
        }).dimensions(width / 2 - 100, 52, 200, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.translatable("craftaria_utils.binds", key(CraftariaUtilsClient.fourKey), key(CraftariaUtilsClient.loginKey), key(CraftariaUtilsClient.cookingKey)), b -> MinecraftClient.getInstance().setScreen(new net.minecraft.client.gui.screen.option.ControlsOptionsScreen(this, MinecraftClient.getInstance().options))).dimensions(width / 2 - 150, 78, 300, 20).build());
        passwordField = new TextFieldWidget(textRenderer, width / 2 - 100, 116, 200, 20, Text.translatable("craftaria_utils.login.password"));
        passwordField.setText(ModConfig.get().password);
        passwordField.setMaxLength(128);
        passwordField.addFormatter((value, cursor) -> Text.literal("•".repeat(value.length())).asOrderedText());
        addDrawableChild(passwordField);
        addDrawableChild(ButtonWidget.builder(Text.translatable("craftaria_utils.save"), b -> saveAndClose()).dimensions(width / 2 - 100, 146, 98, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.translatable("gui.done"), b -> { save(); close(); }).dimensions(width / 2 + 2, 146, 98, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.translatable("craftaria_utils.open_cooking"), b -> MinecraftClient.getInstance().setScreen(new CookingScreen(this))).dimensions(width / 2 - 100, 176, 200, 20).build());
        addDrawableChild(new CookingDelaySlider(width / 2 - 100, 206, 200));
    }
    private Text repairLabel() { return Text.translatable("craftaria_utils.repair", Text.translatable(ModConfig.get().autoRepair ? "options.on" : "options.off")); }
    private String key(net.minecraft.client.option.KeyBinding binding) { return binding.getBoundKeyLocalizedText().getString(); }
    private void save() { ModConfig.get().password = passwordField.getText(); ModConfig.save(); }
    private void saveAndClose() { save(); close(); }
    @Override public void close() { MinecraftClient.getInstance().setScreen(parent); }
    @Override public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        renderBackground(context, mouseX, mouseY, delta);
        context.drawCenteredTextWithShadow(textRenderer, title, width / 2, 25, 0xFFFFFF);
        context.drawCenteredTextWithShadow(textRenderer, Text.translatable("craftaria_utils.password_hint"), width / 2, 103, 0xA0A0A0);
        context.drawCenteredTextWithShadow(textRenderer, Text.translatable("craftaria_utils.password_storage"), width / 2, 235, 0x909090);
        super.render(context, mouseX, mouseY, delta);
    }
}
