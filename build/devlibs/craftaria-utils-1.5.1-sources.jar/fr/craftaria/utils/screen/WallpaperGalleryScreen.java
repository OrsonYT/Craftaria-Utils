package fr.craftaria.utils.screen;

import fr.craftaria.utils.config.ModConfig;
import fr.craftaria.utils.wallpaper.WallpaperManager;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import net.minecraft.util.Util;
import java.util.List;

/** A paged thumbnail grid supports large collections and small GUI resolutions. */
public final class WallpaperGalleryScreen extends CraftariaScreen {
    private final Screen parent;
    private List<String> wallpapers;
    private int page;
    private int pageSize = 1;
    private int pageCount = 1;
    private int left, galleryWidth;
    private boolean error;
    private boolean locateSelection = true;

    public WallpaperGalleryScreen(Screen parent) {
        super(Text.translatable("craftaria_utils.settings.wallpaper"));
        this.parent = parent;
        wallpapers = WallpaperManager.list();
    }

    @Override protected void init() {
        galleryWidth = Math.min(900, width-28);
        left = (width-galleryWidth)/2;
        int columns = Math.clamp(galleryWidth/130, 1, 4);
        int gap = 10;
        int tileWidth = (galleryWidth-gap*(columns-1))/columns;
        int availableHeight = Math.max(36, height-122);
        int tileHeight = Math.min(availableHeight, Math.clamp(tileWidth*9/16+17, 64, 124));
        int rows = Math.max(1, (availableHeight+gap)/(tileHeight+gap));
        pageSize = columns*rows;
        pageCount = Math.max(1, (wallpapers.size()+pageSize-1)/pageSize);
        if (locateSelection) {
            page = Math.max(0, wallpapers.indexOf(ModConfig.get().wallpaper))/pageSize;
            locateSelection = false;
        }
        page = Math.clamp(page, 0, pageCount-1);
        for (int i=0; i<pageSize && page*pageSize+i<wallpapers.size(); i++) {
            String name = wallpapers.get(page*pageSize+i);
            addDrawableChild(new WallpaperTile(left+(i%columns)*(tileWidth+gap), 54+(i/columns)*(tileHeight+gap),
                    tileWidth, tileHeight, name, () -> error = !WallpaperManager.select(name)));
        }
        if (pageCount>1) {
            var previous = addDrawableChild(new SettingsButton(width/2-84, height-58, 28,
                    () -> Text.literal("<"), () -> changePage(-1)));
            previous.active = page>0;
            var next = addDrawableChild(new SettingsButton(width/2+56, height-58, 28,
                    () -> Text.literal(">"), () -> changePage(1)));
            next.active = page+1<pageCount;
        }
        addDrawableChild(new SettingsButton(left, height-28, 60, () -> Text.translatable("gui.back"), this::close));
        int folderWidth = Math.min(130, (galleryWidth-76)/2);
        int refreshWidth = Math.min(90, (galleryWidth-76)/2);
        addDrawableChild(new SettingsButton(left+galleryWidth-refreshWidth-folderWidth-8, height-28, folderWidth,
                () -> Text.translatable("craftaria_utils.wallpaper.folder"), () -> Util.getOperatingSystem().open(WallpaperManager.directory())));
        addDrawableChild(new SettingsButton(left+galleryWidth-refreshWidth, height-28, refreshWidth,
                () -> Text.translatable("craftaria_utils.wallpaper.refresh"), () -> {
            WallpaperManager.refresh();
            wallpapers = WallpaperManager.list();
            error = false;
            clearAndInit();
        }));
    }

    private void changePage(int step) {
        int next = Math.clamp(page+step, 0, pageCount-1);
        if (next != page) { page = next; clearAndInit(); }
    }

    @Override public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (verticalAmount != 0) { changePage(verticalAmount>0 ? -1 : 1); return true; }
        return super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    @Override public void renderBackground(DrawContext context, int mouseX, int mouseY, float delta) { }
    @Override public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        WallpaperManager.draw(context, width, height);
        context.fill(0, 0, width, height, 0xB50A1017);
        MenuTextButton.drawLabel(context, title, left, 12, 1.5f, false, true);
        boolean failed = error || WallpaperManager.hasLoadError();
        Text description = Text.translatable(failed ? "craftaria_utils.wallpaper.error"
                : "craftaria_utils.settings.wallpaper.description");
        context.drawTextWithShadow(textRenderer, textRenderer.trimToWidth(description.getString(), galleryWidth),
                left, 35, failed ? 0xFFFF8888 : 0xFFC5C1B8);
        if (pageCount>1) context.drawCenteredTextWithShadow(textRenderer,
                Text.literal((page+1)+" / "+pageCount), width/2, height-51, 0xFFF0E9DA);
        else context.drawCenteredTextWithShadow(textRenderer, WallpaperManager.label(ModConfig.get().wallpaper), width/2, height-51, 0xFFFFD383);
        super.render(context, mouseX, mouseY, delta);
    }

    @Override public void removed() { WallpaperManager.clearThumbnails(); }
    @Override public void close() { client.setScreen(parent); }
}
