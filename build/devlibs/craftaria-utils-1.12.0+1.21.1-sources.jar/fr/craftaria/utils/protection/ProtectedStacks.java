package fr.craftaria.utils.protection;

import fr.craftaria.utils.config.ModConfig;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtOps;
import net.minecraft.client.MinecraftClient;
import net.minecraft.registry.DynamicRegistryManager;
import net.minecraft.registry.Registries;

import java.util.ArrayList;
import java.util.Base64;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Tracks selected stacks individually using their complete item components and count. */
public final class ProtectedStacks {
    private static final String PREFIX = "stack:";
    private ProtectedStacks() { }

    public static String fingerprint(ItemStack stack, DynamicRegistryManager registries) {
        if (stack == null || stack.isEmpty()) return "";
        var encoded = ItemStack.CODEC.encodeStart(registries.getOps(NbtOps.INSTANCE), stack)
                .result().orElse(null);
        if (encoded == null) return "";
        return PREFIX + Registries.ITEM.getId(stack.getItem()) + ":"
                + Base64.getUrlEncoder().withoutPadding().encodeToString(encoded.toString().getBytes(java.nio.charset.StandardCharsets.UTF_8));
    }

    public static int count(ItemStack stack, DynamicRegistryManager registries) {
        String key = fingerprint(stack, registries);
        return key.isEmpty() ? 0 : ModConfig.get().protectedStackCounts.getOrDefault(key, 0);
    }

    public static boolean isProtected(ItemStack stack, DynamicRegistryManager registries) {
        return !stack.isEmpty() && count(stack, registries) > 0;
    }

    public static void add(ItemStack stack, DynamicRegistryManager registries) {
        String key = fingerprint(stack, registries);
        if (key.isEmpty()) return;
        ModConfig.get().protectedStackCounts.put(key, stack.getCount());
        syncList();
    }

    public static void remove(ItemStack stack, DynamicRegistryManager registries) {
        ModConfig.get().protectedStackCounts.remove(fingerprint(stack, registries));
        syncList();
    }

    /** Refreshes stack-count keys after legitimate uses/consumption without extending the protected quantity. */
    public static void reconcile(List<ItemStack> inventory, DynamicRegistryManager registries) {
        Map<String, Integer> available = new LinkedHashMap<>();
        for (ItemStack stack : inventory) if (!stack.isEmpty()) {
            String key = fingerprint(stack, registries);
            if (!key.isEmpty()) available.merge(key, stack.getCount(), Integer::sum);
        }
        Map<String, Integer> updated = new LinkedHashMap<>();
        List<String> oldKeys = new ArrayList<>(ModConfig.get().protectedStackCounts.keySet());
        for (String protectedKey : oldKeys) {
            int protectedCount = Math.max(0, ModConfig.get().protectedStackCounts.getOrDefault(protectedKey, 0));
            if (protectedCount == 0) continue;
            if (available.containsKey(protectedKey)) {
                int retained = Math.min(protectedCount, available.get(protectedKey));
                updated.put(protectedKey, retained);
                available.put(protectedKey, available.get(protectedKey) - retained);
                continue;
            }
            String oldItem = itemId(protectedKey);
            String match = available.keySet().stream()
                    .filter(candidate -> itemId(candidate).equals(oldItem))
                    .findFirst().orElse(null);
            if (match != null) {
                int retained = Math.min(protectedCount, available.get(match));
                updated.merge(match, retained, Math::max);
                available.put(match, available.get(match) - retained);
            }
        }
        ModConfig.get().protectedStackCounts = updated;
        syncList();
    }

    public static void removeKey(String key) {
        ModConfig.get().protectedStackCounts.remove(key);
        syncList();
    }

    public static ItemStack previewStack(String key) {
        if (key.startsWith("legacy:")) return fr.craftaria.utils.config.QuickHome.iconStack(key.substring("legacy:".length()));
        try {
            String encoded = new String(Base64.getUrlDecoder().decode(key.substring(key.indexOf(':', PREFIX.length())+1)), java.nio.charset.StandardCharsets.UTF_8);
            var nbt = net.minecraft.nbt.StringNbtReader.parse(encoded);
            var client = MinecraftClient.getInstance();
            if (client.world != null) return ItemStack.fromNbt(client.world.getRegistryManager(), nbt).orElse(ItemStack.EMPTY);
        } catch (Exception ignored) { }
        return ItemStack.EMPTY;
    }

    private static String itemId(String fingerprint) {
        if (!fingerprint.startsWith(PREFIX)) return "";
        int separator = fingerprint.indexOf(':', PREFIX.length());
        return separator < 0 ? fingerprint.substring(PREFIX.length()) : fingerprint.substring(PREFIX.length(), separator);
    }

    private static void syncList() {
        ModConfig.get().protectedItems = new ArrayList<>(ModConfig.get().protectedStackCounts.keySet());
    }
}
