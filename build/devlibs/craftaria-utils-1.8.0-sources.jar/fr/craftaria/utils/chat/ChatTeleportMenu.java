package fr.craftaria.utils.chat;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import java.util.List;
import java.util.function.Consumer;

public final class ChatTeleportMenu {
    private record Entry(String command, String label, Item icon) { }
    private static final List<Entry> ENTRIES = List.of(
            new Entry("tpa", "tpa", Items.PLAYER_HEAD),
            new Entry("tpahere", "tpahere", Items.ENDER_PEARL),
            new Entry("rtp", "rtp", Items.COMPASS),
            new Entry("warp", "warp", Items.ENDER_EYE),
            new Entry("home", "home", Items.RED_BED),
            new Entry("spawn", "spawn", Items.RESPAWN_ANCHOR),
            new Entry("casino", "casino", Items.EMERALD),
            new Entry("crate", "crate", Items.CHEST));
    private static final int ROW_HEIGHT = 22;
    private final Consumer<String> action;
    private final int x = 28;
    private final int popupHeight = 22+ENTRIES.size()*ROW_HEIGHT;
    private int buttonY, popupY, popupWidth, buttonWidth;
    private boolean open;

    public ChatTeleportMenu(Consumer<String> action) { this.action = action; }
    public boolean isOpen() { return open; }
    public void close() { open = false; }
    public void layout(int screenWidth, int fieldY) {
        buttonY = Math.max(4, fieldY-26);
        buttonWidth = Math.min(112, screenWidth-x-4);
        popupWidth = Math.min(268, screenWidth-x-4);
        popupY = Math.max(2, buttonY-popupHeight-4);
    }
    public void render(DrawContext context, int mouseX, int mouseY) {
        var font = MinecraftClient.getInstance().textRenderer;
        context.createNewRootLayer();
        boolean hovered = inside(mouseX,mouseY,x,buttonY,buttonWidth,20);
        context.fill(x,buttonY,x+buttonWidth,buttonY+20,0xDC101720);
        border(context,x,buttonY,buttonWidth,20,hovered||open ? 0xFFFFD383 : 0xFF756B57);
        context.drawItem(Items.ENDER_PEARL.getDefaultStack(),x+2,buttonY+2);
        context.drawTextWithShadow(font,font.trimToWidth(Text.translatable("craftaria_utils.teleport.title").getString(),buttonWidth-26),x+23,buttonY+6,0xFFF0E9DA);
        if (!open) return;
        context.fill(x,popupY,x+popupWidth,popupY+popupHeight,0xF2101720);
        border(context,x,popupY,popupWidth,popupHeight,0xFFCFAD6D);
        context.drawTextWithShadow(font,Text.translatable("craftaria_utils.teleport.title"),x+7,popupY+6,0xFFFFD383);
        context.fill(x+5,popupY+18,x+popupWidth-5,popupY+19,0xFF514D45);
        Text tooltip = null;
        for (int i=0;i<ENTRIES.size();i++) {
            Entry entry = ENTRIES.get(i);
            int y=popupY+20+i*ROW_HEIGHT;
            if (inside(mouseX,mouseY,x+2,y,popupWidth-4,ROW_HEIGHT)) {
                context.fill(x+2,y,x+popupWidth-2,y+ROW_HEIGHT,0xFF29313A);
                tooltip = Text.translatable("craftaria_utils.teleport."+entry.label()+".description");
            }
            context.drawItem(entry.icon().getDefaultStack(),x+6,y+3);
            context.drawTextWithShadow(font,Text.translatable("craftaria_utils.teleport."+entry.label()),x+28,y+7,0xFFF0E9DA);
            String command="/"+entry.command();
            context.drawTextWithShadow(font,command,x+popupWidth-8-font.getWidth(command),y+7,0xFFB8B4AA);
        }
        if (tooltip!=null) context.drawTooltip(font,tooltip,mouseX,mouseY);
    }
    public boolean mouseClicked(double mouseX,double mouseY,int button) {
        if (inside(mouseX,mouseY,x,buttonY,buttonWidth,20)) {
            if (button==0) { open=!open; clickSound(); }
            return true;
        }
        if (!open) return false;
        if (inside(mouseX,mouseY,x,popupY,popupWidth,popupHeight)) {
            if (button==0 && mouseY>=popupY+20) {
                int index=(int)(mouseY-popupY-20)/ROW_HEIGHT;
                if (index>=0 && index<ENTRIES.size()) {
                    open=false;
                    clickSound();
                    action.accept(ENTRIES.get(index).command());
                }
            }
            return true;
        }
        open=false;
        return false;
    }
    public boolean covers(double mouseX,double mouseY) { return open && inside(mouseX,mouseY,x,popupY,popupWidth,popupHeight); }
    private static boolean inside(double mouseX,double mouseY,int x,int y,int width,int height) {
        return mouseX>=x && mouseX<x+width && mouseY>=y && mouseY<y+height;
    }
    private static void clickSound() { MinecraftClient.getInstance().getSoundManager().play(PositionedSoundInstance.ui(SoundEvents.UI_BUTTON_CLICK,1f)); }
    private static void border(DrawContext context,int x,int y,int width,int height,int color) {
        context.fill(x,y,x+width,y+1,color); context.fill(x,y+height-1,x+width,y+height,color);
        context.fill(x,y+1,x+1,y+height-1,color); context.fill(x+width-1,y+1,x+width,y+height-1,color);
    }
}
