package fr.craftaria.utils.wallpaper;

import fr.craftaria.utils.config.ModConfig;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.imageio.ImageIO;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;

/** Dynamic textures stay available while resource packs reload. */
public final class WallpaperManager {
    private static final Logger LOGGER = LoggerFactory.getLogger("Craftaria Utils/Wallpaper");
    private static final Path DIRECTORY = FabricLoader.getInstance().getGameDir().resolve("Wallpaper").toAbsolutePath().normalize();
    private static final String BUILTIN = "builtin:";
    private static final String BUILTIN_DIRECTORY = "assets/base_wallpaper/";
    private static final Identifier TEXTURE = Identifier.of("craftaria_utils", "selected_wallpaper");
    private record ImageTexture(Identifier id, int width, int height) { }
    private static final Map<String, ImageTexture> THUMBNAILS = new HashMap<>();
    private static final Set<String> FAILED_THUMBNAILS = new HashSet<>();
    private static int nextThumbnail;
    private static boolean ready;
    private static int imageWidth = 2560, imageHeight = 1600;
    private static boolean loadFailed;

    private WallpaperManager() { }

    public static void initializeDirectory() {
        try { Files.createDirectories(DIRECTORY); }
        catch (IOException e) { LOGGER.warn("Could not create Wallpaper folder", e); }
    }

    public static Path directory() { return DIRECTORY; }
    public static boolean hasLoadError() { return loadFailed; }

    public static Text label(String name) {
        if (name.isEmpty()) return Text.translatable("craftaria_utils.wallpaper.default");
        String filename = name.startsWith(BUILTIN) ? name.substring(BUILTIN.length()) : name;
        int slash = filename.lastIndexOf('/');
        return Text.literal(filename.substring(slash + 1));
    }

    public static boolean isBundled(String name) { return name.isEmpty() || name.startsWith(BUILTIN); }

    public static List<String> list() {
        initializeDirectory();
        LinkedHashSet<String> names = new LinkedHashSet<>();
        names.add(""); // Always first, always the initial default: craftaria_utils/fondbase.png.
        var mod = FabricLoader.getInstance().getModContainer("craftaria_utils").orElseThrow();
        // Fabric's roots work for both a packaged JAR and the development resource directories.
        TreeSet<String> bundled = new TreeSet<>(String.CASE_INSENSITIVE_ORDER);
        for (Path root : mod.getRootPaths()) {
            Path folder = root.resolve(BUILTIN_DIRECTORY);
            if (!Files.isDirectory(folder)) continue;
            try (var files = Files.walk(folder)) {
                files.filter(Files::isRegularFile).filter(path -> supported(path.toString()))
                        .map(path -> folder.relativize(path).toString().replace('\\', '/'))
                        .forEach(name -> bundled.add(BUILTIN + name));
            } catch (IOException e) { LOGGER.warn("Could not list bundled wallpapers", e); }
        }
        names.addAll(bundled);
        try (var files = Files.list(DIRECTORY)) {
            files.filter(Files::isRegularFile).map(path -> path.getFileName().toString())
                    .filter(WallpaperManager::supported).sorted(String.CASE_INSENSITIVE_ORDER).forEach(names::add);
        } catch (IOException e) { LOGGER.warn("Could not list wallpapers", e); }
        return new ArrayList<>(names);
    }

    private static boolean supported(String name) {
        String lower = name.toLowerCase(Locale.ROOT);
        return lower.endsWith(".png") || lower.endsWith(".jpg") || lower.endsWith(".jpeg");
    }

    private static InputStream open(String name) throws IOException {
        if (name == null || name.isEmpty()) {
            InputStream stream = WallpaperManager.class.getResourceAsStream("/assets/craftaria_utils/fondbase.png");
            if (stream == null) throw new IOException("Default Craftaria wallpaper is missing");
            return stream;
        }
        if (name.startsWith(BUILTIN)) {
            String relative = name.substring(BUILTIN.length());
            if (relative.contains("..") || relative.startsWith("/") || relative.contains("\\") || !supported(relative))
                throw new IOException("Invalid bundled wallpaper filename");
            Path path = FabricLoader.getInstance().getModContainer("craftaria_utils").orElseThrow()
                    .findPath(BUILTIN_DIRECTORY + relative).orElseThrow(() -> new IOException("Bundled wallpaper is missing"));
            return Files.newInputStream(path);
        }
        Path file = DIRECTORY.resolve(name).normalize();
        if (!DIRECTORY.equals(file.getParent()) || !supported(name)) throw new IOException("Invalid wallpaper filename");
        return Files.newInputStream(file);
    }

    private static BufferedImage decode(String name) throws IOException {
        try (InputStream stream = open(name)) {
            BufferedImage image = ImageIO.read(stream);
            if (image == null || image.getWidth() > 8192 || image.getHeight() > 8192)
                throw new IOException("Unreadable image or dimensions exceed 8192 pixels");
            return image;
        }
    }

    private static ImageTexture upload(Identifier id, BufferedImage decoded) {
        NativeImage image = new NativeImage(decoded.getWidth(), decoded.getHeight(), false);
        NativeImageBackedTexture texture = null;
        try {
            for (int y = 0; y < decoded.getHeight(); y++)
                for (int x = 0; x < decoded.getWidth(); x++) image.setColorArgb(x, y, decoded.getRGB(x, y));
            texture = new NativeImageBackedTexture(() -> "Craftaria wallpaper", image);
            MinecraftClient.getInstance().getTextureManager().registerTexture(id, texture);
            return new ImageTexture(id, decoded.getWidth(), decoded.getHeight());
        } catch (RuntimeException e) {
            if (texture != null) texture.close();
            else image.close();
            throw e;
        }
    }

    public static boolean select(String name) {
        if (!load(name)) return false;
        ModConfig.get().wallpaper = name;
        ModConfig.save();
        return true;
    }

    public static void clearThumbnails() {
        var manager = MinecraftClient.getInstance().getTextureManager();
        THUMBNAILS.values().forEach(texture -> manager.destroyTexture(texture.id()));
        THUMBNAILS.clear();
        FAILED_THUMBNAILS.clear();
    }

    public static void refresh() {
        ready = false;
        clearThumbnails();
    }

    private static boolean load(String name) {
        try {
            ImageTexture texture = upload(TEXTURE, decode(name));
            imageWidth = texture.width();
            imageHeight = texture.height();
            ready = true;
            loadFailed = false;
            return true;
        } catch (Exception e) {
            loadFailed = true;
            LOGGER.warn("Could not load wallpaper {}", name, e);
            return false;
        }
    }

    public static void drawThumbnail(DrawContext context, String name, int x, int y, int width, int height) {
        ImageTexture texture = THUMBNAILS.get(name);
        if (texture == null && !FAILED_THUMBNAILS.contains(name)) {
            try {
                BufferedImage full = decode(name);
                double scale = Math.min(1, Math.min(320.0 / full.getWidth(), 180.0 / full.getHeight()));
                BufferedImage small = new BufferedImage(Math.max(1, (int)Math.round(full.getWidth()*scale)),
                        Math.max(1, (int)Math.round(full.getHeight()*scale)), BufferedImage.TYPE_INT_ARGB);
                var graphics = small.createGraphics();
                try {
                    graphics.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
                    graphics.drawImage(full, 0, 0, small.getWidth(), small.getHeight(), null);
                } finally { graphics.dispose(); }
                texture = upload(Identifier.of("craftaria_utils", "wallpaper_thumbnail_" + nextThumbnail++), small);
                THUMBNAILS.put(name, texture);
            } catch (Exception e) {
                FAILED_THUMBNAILS.add(name);
                LOGGER.warn("Could not load wallpaper thumbnail {}", name, e);
            }
        }
        if (texture != null) drawTexture(context, texture, x, y, width, height, 255);
        else {
            context.fill(x, y, x+width, y+height, 0xFF22252B);
            context.drawCenteredTextWithShadow(MinecraftClient.getInstance().textRenderer, Text.literal("?"), x+width/2, y+height/2-4, 0xFFFF8888);
        }
    }

    public static void draw(DrawContext context, int width, int height) { draw(context, 0, 0, width, height, 255); }

    public static void draw(DrawContext context, int x, int y, int width, int height, int alpha) {
        if (width <= 0 || height <= 0 || alpha <= 0) return;
        if (!ready && !load(ModConfig.get().wallpaper)) {
            if (!load("")) {
                context.fill(x, y, x+width, y+height, 0xFF101720);
                return;
            }
            loadFailed = true;
        }
        drawTexture(context, new ImageTexture(TEXTURE, imageWidth, imageHeight), x, y, width, height, alpha);
    }

    private static void drawTexture(DrawContext context, ImageTexture texture, int x, int y, int width, int height, int alpha) {
        if (width <= 0 || height <= 0) return;
        double scale = Math.max((double)width/texture.width(), (double)height/texture.height());
        int rw = Math.max(1, Math.min(texture.width(), (int)Math.round(width/scale)));
        int rh = Math.max(1, Math.min(texture.height(), (int)Math.round(height/scale)));
        float u = (texture.width()-rw)/2f, v = (texture.height()-rh)/2f;
        context.drawTexture(RenderPipelines.GUI_TEXTURED, texture.id(), x, y, u, v, width, height,
                rw, rh, texture.width(), texture.height(), (Math.clamp(alpha, 0, 255)<<24)|0xFFFFFF);
    }
}
