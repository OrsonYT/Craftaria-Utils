package fr.craftaria.utils.mixin;

import fr.craftaria.utils.chat.ChatShareMenu;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(ChatScreen.class)
public abstract class ChatScreenMixin extends Screen {
    @Shadow protected TextFieldWidget chatField;
    @Shadow protected String originalChatText;
    @Unique private ChatShareMenu craftariaUtils$shareMenu;

    protected ChatScreenMixin(Text title) { super(title); }

    @Inject(method = "init", at = @At("TAIL"))
    private void craftariaUtils$initShareMenu(CallbackInfo ci) {
        craftariaUtils$shareMenu = new ChatShareMenu(token -> {
            int cursor = chatField.getCursor();
            String draft = chatField.getText();
            String prefix = cursor > 0 && !Character.isWhitespace(draft.charAt(cursor-1)) ? " " : "";
            String insertion = prefix+token;
            int available = 256-(draft.length()-chatField.getSelectedText().length());
            if (insertion.length()>available) {
                client.inGameHud.setOverlayMessage(Text.translatable("craftaria_utils.chat.full"), false);
                return;
            }
            chatField.write(insertion+(available>insertion.length() ? " " : ""));
            originalChatText = chatField.getText();
            setFocused(chatField);
            chatField.setFocused(true);
        });
        craftariaUtils$shareMenu.layout(width, chatField.getY());
    }

    @Inject(method = "render", at = @At("TAIL"))
    private void craftariaUtils$renderShareMenu(DrawContext context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        if (craftariaUtils$shareMenu != null) {
            craftariaUtils$shareMenu.layout(width, chatField.getY());
            craftariaUtils$shareMenu.render(context, mouseX, mouseY);
        }
    }

    @Inject(method = "mouseClicked", at = @At("HEAD"), cancellable = true)
    private void craftariaUtils$clickShareMenu(Click click, boolean doubled, CallbackInfoReturnable<Boolean> cir) {
        if (craftariaUtils$shareMenu != null && craftariaUtils$shareMenu.mouseClicked(click.x(), click.y(), click.button()))
            cir.setReturnValue(true);
    }

    @Inject(method = "keyPressed", at = @At("HEAD"), cancellable = true)
    private void craftariaUtils$closeShareMenu(KeyInput input, CallbackInfoReturnable<Boolean> cir) {
        if (craftariaUtils$shareMenu != null && craftariaUtils$shareMenu.isOpen() && input.key()==GLFW.GLFW_KEY_ESCAPE) {
            craftariaUtils$shareMenu.close();
            cir.setReturnValue(true);
        }
    }

    @Inject(method = "mouseScrolled", at = @At("HEAD"), cancellable = true)
    private void craftariaUtils$shareMenuScroll(double mouseX, double mouseY, double horizontal, double vertical,
                                              CallbackInfoReturnable<Boolean> cir) {
        if (craftariaUtils$shareMenu != null && craftariaUtils$shareMenu.covers(mouseX, mouseY)) cir.setReturnValue(true);
    }
}
