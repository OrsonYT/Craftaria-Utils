package fr.craftaria.utils.screen;

import fr.craftaria.utils.config.ModConfig;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.registry.Registries;
import net.minecraft.screen.PlayerScreenHandler;
import net.minecraft.screen.slot.Slot;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

/** Only edits the protection list; selecting never sends an inventory click. */
public final class AntiDropScreen extends HandledScreen<PlayerScreenHandler> {
    private final Screen parent;
    public AntiDropScreen(Screen parent) {
        super(MinecraftClient.getInstance().player.playerScreenHandler,MinecraftClient.getInstance().player.getInventory(),
                Text.translatable("craftaria_utils.settings.antidrop"));
        this.parent=parent;
    }
    @Override protected void init() {
        super.init();
        addDrawableChild(ButtonWidget.builder(Text.translatable("gui.done"),b->close()).dimensions(x,y+backgroundHeight+6,85,20).build());
        addDrawableChild(ButtonWidget.builder(Text.translatable("craftaria_utils.antidrop.clear"),b->{ModConfig.get().protectedItems.clear();ModConfig.save();})
                .dimensions(x+91,y+backgroundHeight+6,85,20).build());
    }
    @Override public boolean mouseClicked(double mouseX,double mouseY,int button) {
        for(Slot slot:handler.slots) if(mouseX>=x+slot.x && mouseX<x+slot.x+16 && mouseY>=y+slot.y && mouseY<y+slot.y+16) {
            if(button==0 && slot.inventory==client.player.getInventory() && slot.hasStack()) {
                String id=Registries.ITEM.getId(slot.getStack().getItem()).toString();
                if(!ModConfig.get().protectedItems.remove(id)) ModConfig.get().protectedItems.add(id);
                ModConfig.save();
            }
            return true;
        }
        return super.mouseClicked(mouseX,mouseY,button);
    }
    @Override protected void onMouseClick(Slot slot,int slotId,int button,SlotActionType action) { }
    @Override protected void drawSlot(DrawContext context,Slot slot) {
        super.drawSlot(context,slot);
        if(slot.hasStack() && slot.inventory==client.player.getInventory()
                && ModConfig.get().protectedItems.contains(Registries.ITEM.getId(slot.getStack().getItem()).toString()))
            context.fill(slot.x,slot.y,slot.x+16,slot.y+16,0x8033DD55);
    }
    @Override protected void drawBackground(DrawContext context,float delta,int mouseX,int mouseY) {
        GuiTextures.draw(context,Identifier.ofVanilla("textures/gui/container/inventory.png"),x,y,0,0,backgroundWidth,backgroundHeight,256,256);
        InventoryScreen.drawEntity(context,x+26,y+8,x+75,y+78,30,.0625f,mouseX,mouseY,client.player);
    }
    @Override public void render(DrawContext context,int mouseX,int mouseY,float delta) {
        super.render(context,mouseX,mouseY,delta);
        context.drawCenteredTextWithShadow(textRenderer,Text.translatable("craftaria_utils.antidrop.select_hint"),width/2,y-23,0xFFF0E9DA);
        context.drawCenteredTextWithShadow(textRenderer,Text.translatable("craftaria_utils.antidrop.all_of_type"),width/2,y-11,0xFFFFD383);
        drawMouseoverTooltip(context,mouseX,mouseY);
    }
    @Override protected void applyBlur(float delta) { }
    @Override public void close() { client.setScreen(parent); }
}
