package fr.craftaria.utils.screen;

import fr.craftaria.utils.config.ModConfig;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.text.Text;
import java.util.Locale;

public final class CookingDelaySlider extends SliderWidget {
    public CookingDelaySlider(int x, int y, int width) {
        super(x, y, width, 20, Text.empty(), (ModConfig.get().cookingDelayTicks - 2) / 98.0);
        updateMessage();
    }

    @Override protected void updateMessage() {
        setMessage(Text.translatable("craftaria_utils.cooking.delay",
                String.format(Locale.getDefault(), "%.1f", ModConfig.get().cookingDelayTicks / 20.0)));
    }

    @Override protected void applyValue() {
        // Fifty values, one for each tenth of a second from 0.1 to 5.0.
        ModConfig.get().cookingDelayTicks = 2 + (int)Math.round(value * 49) * 2;
        ModConfig.save();
        updateMessage();
    }
}
