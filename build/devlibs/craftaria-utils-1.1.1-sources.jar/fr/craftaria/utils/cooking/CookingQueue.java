package fr.craftaria.utils.cooking;

import fr.craftaria.utils.CraftariaUtilsClient;
import fr.craftaria.utils.config.ModConfig;
import net.minecraft.client.MinecraftClient;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.text.Text;
import java.util.ArrayDeque;
import java.util.Queue;

public final class CookingQueue {
    private static final Queue<Integer> QUEUE = new ArrayDeque<>();
    private static int ticksLeft;
    private static boolean active;
    private CookingQueue() {}
    public static void start(Iterable<Integer> playerInventoryIndices) {
        QUEUE.clear();
        int heldSlot = MinecraftClient.getInstance().player.getInventory().getSelectedSlot();
        boolean includeHeld = false;
        for (int index : playerInventoryIndices) {
            if (index == heldSlot) includeHeld = true;
            else QUEUE.add(index);
        }
        // The active hotbar slot is used to hold each stack. Process its contents first.
        if (includeHeld) {
            var remaining = new ArrayDeque<>(QUEUE);
            QUEUE.clear();
            QUEUE.add(heldSlot);
            QUEUE.addAll(remaining);
        }
        active = !QUEUE.isEmpty();
        ticksLeft = 0;
    }
    public static boolean isActive() { return active; }
    public static void cancel() { active = false; QUEUE.clear(); }
    public static void tick(MinecraftClient client) {
        if (!active) return;
        if (client.player == null || client.interactionManager == null || client.getNetworkHandler() == null) { cancel(); return; }
        if (client.player.currentScreenHandler != client.player.playerScreenHandler) { cancel(); return; }
        if (ticksLeft > 0) { ticksLeft--; return; }
        Integer inventoryIndex = QUEUE.poll();
        if (inventoryIndex == null) {
            active = false;
            client.inGameHud.getChatHud().addMessage(Text.translatable("craftaria_utils.cooking.done"));
            return;
        }
        int syncId = client.player.currentScreenHandler.syncId;
        int slotId = inventoryIndex < 9 ? 36 + inventoryIndex : inventoryIndex;
        int hotbar = client.player.getInventory().getSelectedSlot();
        client.interactionManager.clickSlot(syncId, slotId, hotbar, SlotActionType.SWAP, client.player);
        CraftariaUtilsClient.sendCommand(client, "four");
        ticksLeft = Math.clamp(ModConfig.get().cookingDelayTicks, 2, 100) - 1;
    }
}
