package fr.craftaria.utils;

import fr.craftaria.utils.config.ModConfig;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.PlayerSkinDrawer;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.item.Items;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;

import java.util.Locale;
import java.util.Set;
import java.util.stream.Collectors;

/** Detects new UUIDs in the server player list after the initial roster has loaded. */
public final class ConnectionTracker {
    private static String playerName;
    private static long expiresAt;
    private static boolean preview;
    private static net.minecraft.client.network.ClientPlayNetworkHandler connection;
    private static final ConnectionRoster roster = new ConnectionRoster();
    private static final java.util.ArrayDeque<String> pending = new java.util.ArrayDeque<>();

    private ConnectionTracker() { }

    public static void tick(MinecraftClient client) {
        var network = client.getNetworkHandler();
        if (client.player == null || network == null) {
            connection=null; roster.reset(); pending.clear(); playerName=null; return;
        }
        if (network != connection) {
            connection=network; pending.clear(); playerName=null;
        }
        var current = network.getPlayerList().stream()
                .filter(entry -> !entry.getProfile().getId().equals(client.player.getUuid()))
                .collect(Collectors.toMap(entry -> entry.getProfile().getId(),entry -> entry.getProfile().getName(),(a,b)->a));
        Set<String> tracked = TrackedPlayers.parse(ModConfig.get().trackedPlayers).stream()
                .map(name -> name.toLowerCase(Locale.ROOT)).collect(Collectors.toSet());
        for(String name:roster.update(network,current,tracked,ModConfig.get().connectionTrackerEnabled)) {
            if(pending.size()<20) pending.addLast(name);
        }
        if (!ModConfig.get().connectionTrackerEnabled) { pending.clear(); if(!preview) playerName=null; return; }
        if (client.currentScreen == null && (playerName == null || System.currentTimeMillis()>=expiresAt) && !pending.isEmpty()) {
            show(client,pending.removeFirst(),false);
        }
    }

    private static void show(MinecraftClient client,String name,boolean isPreview) {
        playerName=name; preview=isPreview; expiresAt=System.currentTimeMillis()+5500;
        TrackedPlayerSkins.request(name);
        client.getSoundManager().play(net.minecraft.client.sound.PositionedSoundInstance.master(SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP,1f,1f));
    }

    public static void preview(MinecraftClient client) {
        if(client.player==null) return;
        var tracked=TrackedPlayers.parse(ModConfig.get().trackedPlayers);
        show(client,tracked.isEmpty()?client.player.getGameProfile().getName():tracked.getFirst(),true);
        client.setScreen(null);
    }

    public static boolean isOnline(MinecraftClient client,String name) {
        return client.getNetworkHandler()!=null && client.getNetworkHandler().getPlayerList().stream()
                .anyMatch(entry->entry.getProfile().getName().equalsIgnoreCase(name));
    }

    public static void render(DrawContext context, MinecraftClient client) {
        if (playerName == null) return;
        if (System.currentTimeMillis() >= expiresAt || client.player == null) { playerName = null; return; }
        if (client.currentScreen != null) return;

        context.draw();
        context.getMatrices().push();
        context.getMatrices().translate(0,0,800);
        int width = 230, height = 48;
        int x = (context.getScaledWindowWidth() - width) / 2;
        // Sit below the server's boss bars and announcements, leaving the crosshair unobstructed.
        int y = 52;
        context.fill(x, y, x+width, y+height, 0xE6101720);
        context.fill(x, y, x+width, y+2, 0xFFFFD383);
        context.fill(x, y+height-1, x+width, y+height, 0xFF756B57);
        context.fill(x, y+2, x+1, y+height-1, 0xFF756B57);
        context.fill(x+width-1, y+2, x+width, y+height-1, 0xFF756B57);
        PlayerListEntry entry = client.getNetworkHandler() == null ? null : client.getNetworkHandler().getPlayerListEntry(playerName);
        if (entry != null) PlayerSkinDrawer.draw(context, entry.getSkinTextures(), x+8, y+8, 32);
        else if (TrackedPlayerSkins.get(playerName)!=null) PlayerSkinDrawer.draw(context,TrackedPlayerSkins.get(playerName),x+8,y+8,32);
        else context.drawItem(Items.PLAYER_HEAD.getDefaultStack(), x+12, y+12);

        context.drawTextWithShadow(client.textRenderer, Text.literal(playerName), x+49, y+10, 0xFFFFD383);
        context.drawTextWithShadow(client.textRenderer, Text.translatable(preview?"craftaria_utils.tracker.preview_message":"craftaria_utils.tracker.joined"), x+49, y+26, 0xFFF0E9DA);
        int remaining = (int)Math.clamp((expiresAt-System.currentTimeMillis())*100/5500, 0, 100);
        context.fill(x+49, y+40, x+width-9, y+42, 0xFF45454B);
        context.fill(x+49, y+40, x+49+(width-58)*remaining/100, y+42, 0xFFFFD383);
        context.draw();
        context.getMatrices().pop();
    }
}
