package fr.craftaria.utils.screen;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.MultiplayerServerListPinger;
import net.minecraft.client.network.ServerInfo;
import net.minecraft.network.NetworkingBackend;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Vanilla status protocol, with DNS resolution off the render thread. */
public final class ServerStatusPanel {
    private static final ExecutorService EXECUTOR = Executors.newSingleThreadExecutor(task -> {
        Thread thread = new Thread(task, "Craftaria server status");
        thread.setDaemon(true);
        return thread;
    });
    private MultiplayerServerListPinger pinger;
    private ServerInfo server;
    private boolean closed = true;
    private long startedAt;
    private long nextRefresh;

    public void open() {
        closed = false;
        refresh();
    }

    private void refresh() {
        if (pinger != null) pinger.cancel();
        MultiplayerServerListPinger current = new MultiplayerServerListPinger();
        ServerInfo info = new ServerInfo("Craftaria", CraftariaTitleScreen.SERVER, ServerInfo.ServerType.OTHER);
        info.setStatus(ServerInfo.Status.PINGING);
        info.ping = -1;
        pinger = current;
        server = info;
        startedAt = System.nanoTime();
        nextRefresh = startedAt + 30_000_000_000L;
        EXECUTOR.execute(() -> {
            try {
                current.add(info, () -> { }, () -> MinecraftClient.getInstance().execute(() -> {
                    if (!closed && pinger == current) info.setStatus(ServerInfo.Status.SUCCESSFUL);
                }), NetworkingBackend.remote(true));
            } catch (Exception exception) {
                MinecraftClient.getInstance().execute(() -> {
                    if (!closed && pinger == current) info.setStatus(ServerInfo.Status.UNREACHABLE);
                });
            } finally {
                MinecraftClient.getInstance().execute(() -> {
                    if (closed || pinger != current) current.cancel();
                });
            }
        });
    }

    public void tick() {
        if (closed) return;
        pinger.tick();
        long now = System.nanoTime();
        if (server.getStatus() == ServerInfo.Status.PINGING && now - startedAt > 10_000_000_000L) {
            pinger.cancel();
            server.setStatus(ServerInfo.Status.UNREACHABLE);
        }
        if (now >= nextRefresh) refresh();
    }

    public void close() {
        closed = true;
        if (pinger != null) pinger.cancel();
    }

    public void render(DrawContext context, int screenWidth) {
        if (server == null) return;
        var font = MinecraftClient.getInstance().textRenderer;
        int right = screenWidth - 16, top = 18;
        boolean pending = server.getStatus() == ServerInfo.Status.PINGING;
        boolean online = server.getStatus() == ServerInfo.Status.SUCCESSFUL;
        Text heading = Text.literal(CraftariaTitleScreen.SERVER);
        Text players = online && server.players != null
                ? Text.translatable("craftaria_utils.server.players", server.players.online(), server.players.max())
                : Text.translatable(pending ? "craftaria_utils.server.checking" : online
                    ? "craftaria_utils.server.players_unknown" : "craftaria_utils.server.offline");
        Text latency = Text.literal(online ? Math.max(0, server.ping) + " ms" : pending ? "…" : "—");
        int panelWidth = Math.max(146, Math.max(font.getWidth(heading), font.getWidth(players)) + 20);
        context.fill(right-panelWidth-10, top-8, right+8, top+44, 0x650A1017);
        context.drawTextWithShadow(font, heading, right-font.getWidth(heading), top, 0xFFF7F4EA);
        context.drawTextWithShadow(font, players, right-font.getWidth(players), top+14, online ? 0xFFDDD9CC : 0xFFB9BDC6);
        int color = server.ping < 150 ? 0xFF69E27C : server.ping < 300 ? 0xFFB6DB66
                : server.ping < 600 ? 0xFFFFD16A : server.ping < 1000 ? 0xFFFFA45A : 0xFFFF6F6F;
        int barsX = right-16, barsY = top+29;
        if (online) {
            int bars = server.ping < 150 ? 5 : server.ping < 300 ? 4 : server.ping < 600 ? 3 : server.ping < 1000 ? 2 : 1;
            for (int i = 0; i < 5; i++) {
                int h = 2 + i*2;
                context.fill(barsX+i*3, barsY+10-h, barsX+i*3+2, barsY+10, i < bars ? color : 0xFF545862);
            }
        } else {
            int frame = (int)((System.nanoTime()-startedAt)/100_000_000L % 8);
            if (frame > 4) frame = 8-frame;
            Identifier sprite = Identifier.ofVanilla(pending ? "server_list/pinging_"+(frame+1) : "server_list/unreachable");
            context.drawGuiTexture(RenderPipelines.GUI_TEXTURED, sprite, barsX, barsY, 15, 10);
        }
        context.drawTextWithShadow(font, latency, barsX-7-font.getWidth(latency), top+29,
                online ? color : pending ? 0xFFB9BDC6 : 0xFFFF7777);
    }
}
